"""Hash sampling of complete original spectra; retain ICs and binary arrays verbatim."""
import collections,gzip,hashlib,heapq,json,sys,time
from pathlib import Path
from lxml import etree as E
ROOT=Path(__file__).resolve().parent
NS='http://psi.hupo.org/ms/mzml'; Q='{'+NS+'}'
def prepare(r):
 out=ROOT/'data'/(r['id']+'.mzML'); meta=ROOT/'provenance'/(r['id']+'.json')
 if out.exists() and meta.exists():return
 source=ROOT/'raw'/(r['id']+('.mzML.gz' if r['url'].endswith('.gz') else '.mzML'))
 if not source.exists():source=Path('/tmp/prose-benchmark-downloads')/(r['id']+'.mzML')
 if not source.exists():return
 start=time.monotonic(); heap=[]; headers=[]; counts=collections.Counter(); activ=collections.Counter(); configs=collections.Counter(); charges=collections.Counter(); attrs={}; runattrs={}; slattrs={}; instruments=[]
 with (gzip.open(source,'rb') if source.suffix=='.gz' else source.open('rb')) as f:
  for ev,e in E.iterparse(f,events=('start','end'),huge_tree=True):
   tag=E.QName(e).localname
   if ev=='start':
    if tag=='mzML':attrs=dict(e.attrib)
    elif tag=='run':runattrs=dict(e.attrib)
    elif tag=='spectrumList':slattrs=dict(e.attrib)
    continue
   if tag=='spectrum':
    cv={v.get('accession'):v for v in e.iter(Q+'cvParam')}
    level=int(cv['MS:1000511'].get('value')); counts['MS'+str(level)]+=1
    if level==2:
     ch=int(cv['MS:1000041'].get('value')) if 'MS:1000041' in cv else 0; charges[str(ch)]+=1
     act=[v.get('name') for a in e.iter(Q+'activation') for v in a.iter(Q+'cvParam') if 'dissociation' in v.get('name','')]
     activ[';'.join(act)]+=1
     ic=next(e.iter(Q+'scan')).get('instrumentConfigurationRef',runattrs.get('defaultInstrumentConfigurationRef','')); configs[ic]+=1
     counts['profile_MS2' if 'MS:1000128' in cv else 'centroid_MS2']+=1
     if 2<=ch<=5 and int(e.get('defaultArrayLength','0'))>0 and 'MS:1000744' in cv and 'MS:1000128' not in cv:
      counts['eligible']+=1
      native=e.get('id'); key=int.from_bytes(hashlib.sha256((r['id']+'\0'+native).encode()).digest(),'big')
      if len(heap)<r['max_spectra'] or key < -heap[0][0]:
       rt=cv['MS:1000016']; sec=float(rt.get('value'))*(60 if rt.get('unitAccession')=='UO:0000031' else 1)
       d=dict(native_id=native,scan=int(native.split('=')[-1]),charge=ch,precursor_mz=float(cv['MS:1000744'].get('value')),rt=sec,ic=ic,activation=act)
       item=(-key,native,E.tostring(e),d)
       if len(heap)<r['max_spectra']:heapq.heappush(heap,item)
       else:heapq.heapreplace(heap,item)
    e.clear()
    while e.getprevious() is not None:del e.getparent()[0]
   elif e.getparent() is not None and E.QName(e.getparent()).localname=='mzML' and tag!='run':
    headers.append(E.tostring(e)); instruments.extend(dict(v.attrib) for v in e.iter(Q+'cvParam') if tag in ['referenceableParamGroupList','instrumentConfigurationList']);e.clear()
 selected=sorted(heap,key=lambda a:a[3]['rt']); root=E.Element(Q+'mzML',attrib=attrs,nsmap={None:NS,'xsi':'http://www.w3.org/2001/XMLSchema-instance'})
 for b in headers:root.append(E.fromstring(b))
 run=E.SubElement(root,Q+'run',attrib=runattrs);slattrs['count']=str(len(selected));sl=E.SubElement(run,Q+'spectrumList',attrib=slattrs)
 scans=[]
 for i,(_,native,b,d) in enumerate(selected):
  e=E.fromstring(b);e.set('index',str(i))
  if 'scan=' not in native:
   d['benchmark_native_id']='scan='+str(d['scan']);e.set('id',d['benchmark_native_id'])
  for activation in e.iter(Q+'activation'):
   for user in list(activation):
    if E.QName(user).localname=='userParam' and user.get('name')=='CID':
     E.SubElement(activation,Q+'cvParam',cvRef='PSI-MS',accession='MS:1000133',name='collision-induced dissociation',value='')
     d['activation_normalization']='Exporter userParam CID represented as standard CV MS:1000133 for both engines'
  sl.append(e);scans.append(d)
 if any('benchmark_native_id' in d for d in scans):
  for source_file in root.iter(Q+'sourceFile'):
   for cv in source_file.iter(Q+'cvParam'):
    if 'nativeID format' in cv.get('name',''):
     cv.set('accession','MS:1000776');cv.set('name','scan number only nativeID format')
 E.ElementTree(root).write(str(out)+'.part',encoding='utf-8',xml_declaration=True);Path(str(out)+'.part').rename(out)
 info=dict(id=r['id'],source=r['url'],selection='8000 lowest SHA256(dataset_id + NUL + native_id), eligible centroid MS2 charge 2..5, nonempty; original peak arrays and instrument references preserved; non-scan native IDs normalized to scan=number for both engines, original ID retained in provenance',counts=dict(counts),source_activations=dict(activ),source_instrument_configs=dict(configs),source_charges=dict(charges),instrument_metadata=instruments,selected=len(scans),scans=scans,sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),seconds=time.monotonic()-start)
 meta.write_text(json.dumps(info,indent=2));print(r['id'],dict(counts),dict(activ),dict(configs),'selected',len(scans),flush=True)
if __name__=='__main__':
 rows=json.loads((ROOT/'manifest.json').read_text())
 for r in rows:
  if len(sys.argv)<2 or r['id'] in sys.argv[1:]:prepare(r)
