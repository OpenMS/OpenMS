# ProSE–ANDES: erweiterter Instrument- und Messungsbenchmark

Stand: 29. September 2026. **20 zusätzliche LC-MS-Messungen, sechs Instrumentmodelle, sieben Messungs-/Protokollgruppen und 160.000 MS2-Spektren.** Pro Messung wurden vor der Suche 8.000 Spektren deterministisch ausgewählt. Alle Primärarme wurden mit denselben Spektren und denselben Target-Decoy-Sequenzen verglichen.

Auto erhält bei allen 14 hochauflösenden Kontrollen den vollständigen bisherigen HyperScore/single-Output. Bei Ion-Trap-CID steigt die mittlere Ausbeute auf Velos um 8,8% und bei Lumos-TMT um 2,2%. Die größte verbleibende ProSE-Lücke liegt bei den kurzen Astral-Messungen mit 50 ng: 31,6% weniger akzeptierte PSMs als ANDES auto. Lokale Evidenzmerkmale helfen dort, liefern aber nicht in jeder Messungsgruppe einen Gewinn.

## Ergebnis nach Percolator

PSMs bei nominal q ≤ 0,01, Mittel pro Messung über Seeds 1, 42 und 137. Die Werte messen Identifikationsausbeute bei dieser statistischen Schwelle, nicht die unabhängig verifizierte wahre Fehlerrate. „Legacy“ bezeichnet hier explizit HyperScore/single im gleichen ProSE-Code, keinen vollständigen Vergleich mit einer älteren OpenMS-Version.

| Messungsgruppe | n | ProSE Legacy | ProSE auto | + lokale Evidenz | ANDES auto | Auto vs. Legacy | Auto vs. ANDES |
|---|---:|---:|---:|---:|---:|---:|---:|
| Velos · CID · UPS1/Hefe | 3 | 2557.6 | 2782.6 | 2829.6 | 3000.6 | +8.8% | -7.3% |
| HF-X · HCD · HYE | 3 | 4328.0 | 4328.0 | 4372.2 | 4703.9 | +0.0% | -8.0% |
| Astral · HCD · HYE, 50 ng | 3 | 2103.9 | 2103.9 | 2381.3 | 3073.8 | +0.0% | -31.6% |
| Lumos · HCD · LFQ | 3 | 5462.9 | 5462.9 | 5467.8 | 5616.2 | +0.0% | -2.7% |
| Lumos · CID · TMT | 3 | 2319.2 | 2369.4 | 2367.4 | 2468.9 | +2.2% | -4.0% |
| Exploris 480 · HCD · TMTpro | 3 | 2238.4 | 2238.4 | 2263.4 | 2502.6 | +0.0% | -10.6% |
| timsTOF HT · CID · Plasma | 2 | 1038.5 | 1038.5 | 1025.2 | 964.0 | +0.0% | +7.7% |

![Gruppenvergleich](ProSE_ANDES_Benchmark.png)

## Auto-Regression und Kontrollen

Bei **14 von 20 Messungen** sind die vollständigen ProSE-PIN-Dateien von auto und explizitem HyperScore/single byteidentisch. Das sind die hochauflösenden MS2-Suchen mit 20 ppm. Für diese identischen Kontrollen wurden Percolator-Ergebnisse teilweise wiederverwendet; die beiden nativen Suchen wurden jeweils tatsächlich durchgeführt.

Die sechs Ion-Trap-CID-Messungen wählen calibrated/multiple. Die pro Messung über drei Seeds gemittelte Änderung reicht von −0,23% (`lumos_tmt_5059`) bis +11,45% (`velos_125_R1`). Der kleine Rückgang im TMT-Lauf liegt innerhalb der beobachteten Seed-Streuung; aus drei Seeds wird hier keine formale Signifikanz abgeleitet. In allen 20 Messungen lässt die Zuschaltung lokaler Evidenzmerkmale den nativen TSV-Output unverändert; Veränderungen nach Percolator stammen deshalb aus den zusätzlichen Merkmalen.

Die C++-Tests für ProSEAlgorithm, FragmentIndex und HyperScore bestanden 3/3. Der Testharness kompiliert diese relevanten Quellen gegen eine festgehaltene pyOpenMS-Supportbibliothek; dies ersetzt keinen vollständigen OpenMS-Build oder eine produktive Pipeline-Validierung.

## Verbleibende Lücke: Kandidaten oder Ranking?

Für Seed 42 wurden ANDES-akzeptierte Peptidsequenzen mit den ProSE-Kandidaten verglichen (I/L gleichgesetzt; Modifikationslokalisierungen nicht als getrennte Sequenz). ANDES-Treffer sind hier eine Vergleichsmenge, keine Ground Truth.

| Gruppe | Gleiche Sequenz akzeptiert | Kein ProSE-Kandidat | Sequenz fehlt in ProSE-Top-10 | In Top-10 unter Rang 1 | ProSE-Rang 1, aber nicht gleich akzeptiert |
|---|---:|---:|---:|---:|---:|
| Velos · CID · UPS1/Hefe | 7576 | 1 | 101 | 259 | 995 |
| HF-X · HCD · HYE | 12175 | 789 | 389 | 316 | 537 |
| Astral · HCD · HYE, 50 ng | 5884 | 628 | 1122 | 567 | 1165 |
| Lumos · HCD · LFQ | 15602 | 447 | 278 | 300 | 224 |
| Lumos · CID · TMT | 6515 | 1 | 72 | 134 | 749 |
| Exploris 480 · HCD · TMTpro | 5969 | 222 | 232 | 426 | 650 |
| timsTOF HT · CID · Plasma | 1777 | 44 | 7 | 2 | 58 |

## Astral: gezielte native Diagnose

Auf `astral_A2` wurden vier zusätzliche Einstellungen mit unveränderter Datenbank und Spektrenauswahl geprüft. Die ersten drei ändern jeweils einen Faktor. Der vierte Test ergänzt mehrfach geladene theoretische Fragmente bei abgeschalteter Deisotopierung. Diese explorativen Tests wurden nach Sichtung der Lücke gewählt; sie sind keine unabhängige Validierung neuer Defaults.

| Einstellung | PSMs nach Percolator, Mittel | Seed-Spanne | Gegenüber auto | Native PSMs |
|---|---:|---|---:|---:|
| Auto | 1852.3 | 1768–1977 | +0.0% | 1450 |
| Mindestens 3 statt 5 passende Ionen | 1930.3 | 1867–2007 | +4.2% | 1450 |
| Auch b1/b2/y1/y2 im Fragmentindex | 2044.7 | 2001–2075 | +10.4% | 1464 |
| Deisotopierung aus | 2005.0 | 1963–2041 | +8.2% | 1576 |
| Deisotopierung aus + mehrere Fragmentladungen | 2042.3 | 2026–2065 | +10.3% | 1148 |
| Auto + lokale Evidenz | 2184.3 | 2082–2256 | +17.9% | 1450 |
| ANDES auto | 2839.0 | 2809–2890 | +53.3% | 1117 |

Der Fragmentindex und die Deisotopierung tragen messbar zur Lücke bei. Mehrfache Fragmentladungen liefern gegenüber ausgeschalteter Deisotopierung allein nur einen kleinen zusätzlichen Gewinn. Keine dieser einzelnen Einstellungen schließt die Lücke zu ANDES. Lokale Evidenz verbessert den nachgelagerten Klassifikator; sie verändert die native Kandidatenliste nicht. Ein nächster Codeversuch sollte kurze Index-Ionen und den Umgang mit schwacher Isotopenevidenz gezielt untersuchen und anschließend auf anderen Messungen einschließlich CID/TMT validieren. Die hier geprüften Defaults wurden aufgrund dieser einzelnen Diagnose nicht verändert.


Die Kandidatenanalyse trennt zwei Arbeitsrichtungen: Kandidatenfilter/Fragmentindex für fehlende Sequenzen sowie natives Ranking und Evidenzmerkmale für bereits vorhandene Kandidaten. Ohne unabhängige Referenz lässt sich daraus nicht ableiten, welche einzelne widersprüchliche Zuordnung richtig ist.

## timsTOF: automatisch gewähltes Modell

ANDES erkennt nach Normalisierung des CID-Metadatums den TOF-Analysator, findet im geprüften Modellbestand aber kein passendes CID/TOF-Modell. Der Fallback ist `cid_lowres_tryp`: 0,5 Da und LowRes-Ranking. ProSE auto verwendet bei der vorgegebenen hochauflösenden Toleranz HyperScore/single. Der Primärvergleich enthält damit bewusst das tatsächliche ANDES-Autoverhalten; die Fragmentauflösung ist in dieser Gruppe nicht harmonisiert.

| Messung | ProSE auto | ANDES auto, LowRes-Fallback | ANDES explizites HighRes-Modell |
|---|---:|---:|---:|
| tims_plasma_30min | 1042.3 | 1013.0 | 1076.0 |
| tims_plasma_50min | 1034.7 | 915.0 | 982.0 |

Der explizite Test nutzt `hcd_qexactive_tryp` mit 20 ppm. Das ist ein diagnostischer Vergleich mit einem geliehenen hochauflösenden Modell, keine validierte Empfehlung für ein timsTOF-Produktionsmodell. Die Spektren/Proteinsequenzen/Percolator-Seeds bleiben identisch. Gegenüber dem Auto-Fallback gewinnt ANDES damit 6,2% bzw. 7,3% PSMs. Zusammen mit dem Modell wechseln auch Ranking und Kandidatengewinnung; der Effekt lässt sich nicht allein der Fragmenttoleranz zuschreiben. Das quantitative Follow-up steht in [Issue #97](https://github.com/bigbio/andes/issues/97#issuecomment-5895251831).

Zwei Fehler wurden mit kleinen realen Beispielen reproduziert und gemeldet:

- [ANDES #96](https://github.com/bigbio/andes/issues/96): `index=N` geht im PIN-ScanNr verloren und wird zu 0. Percolator gruppiert nach Scan **und** experimenteller Masse; deshalb ist dies kein Beleg, dass alle Spektren zu einem einzigen Treffer kollabieren. Für den Benchmark wurden IDs für beide Engines auf `scan=N` normalisiert, die Original-IDs bleiben dokumentiert.
- [ANDES #97](https://github.com/bigbio/andes/issues/97): TOF fällt auf LowRes/0,5 Da zurück; die Parameteranzeige bezeichnet das substituierte LowRes anschließend irreführend als erkannt.

Die tdf2mzml-Dateien hinterlegen CID als `userParam`. Für beide Engines wurde dieselbe Information zusätzlich als regulärer CV-Term `MS:1000133` dargestellt. Peaks, Vorläufer, Ladungen und Auswahl wurden dabei nicht verändert.

## Bekannte Probenzusammensetzung: UPS1/Hefe

Für die drei Velos-Messungen wurde geprüft, ob akzeptierte Sequenzen in irgendeinem Hefe-, UPS1- oder enthaltenen Kontaminantenprotein vorkommen (I/L gleichgesetzt). Unerklärte Sequenzen sind ein Warnsignal, aber kein automatisch kalibrierter FDP-Schätzer: nicht aufgeführte Kontamination und Sequenzvarianten bleiben möglich.

| Arm | Akzeptierte PSMs, Summe über 3 Läufe und 3 Seeds | Nicht durch bekannte Proteine erklärbar | Anteil |
|---|---:|---:|---:|
| prose_legacy | 23018 | 155 | 0.67% |
| prose_auto | 25043 | 162 | 0.65% |
| prose_evidence | 25466 | 158 | 0.62% |
| andes | 27005 | 191 | 0.71% |

## Daten- und Vergleichsqualität

- Die HYE-FASTA im wiederhergestellten früheren Material war abgeschnitten. Die vollständige Referenz wurde neu geladen und gegen Git-Blob `d832aa92d3f3869ab17ba24a0a8b190b38e64858` geprüft: 16.670.994 Bytes, 31.889 Targets. Alle sechs HYE-Suchen wurden verworfen und wiederholt. Die abgeleiteten Human/Hefe- und Human-Datenbanken waren sequenzidentisch und blieben gültig. Dieser Bericht verwendet ausschließlich die überprüften Läufe.
- Der Archivordner „OrbitrapEclipse/PXD054559“ ist irreführend: Alle drei mzML-Dateien nennen **Orbitrap Exploris 480**. Es wird daher keine Eclipse-Abdeckung behauptet.
- ANDES-Modellbestand und ProSE-Code wurden vor den Suchen festgehalten. Bekannte Benchmark-Überlappung: ANDES verwendet bereits Studien PXD001819/PXD007683 und die Astral-Messungsserie; `a05058` ist dort auch eine Benchmarkdatei. Unabhängigkeit von sämtlichen Trainingsdaten lässt sich daraus nicht zusichern.
- Ressourcen: 4 Suchthreads pro Prozess, ANDES mmap-Index, begrenzter Fenstercache und kleine Fragmentindex-Scheiben. Die Modell-/Score-Auswahl bleibt auto. Laufzeiten unter parallelen Jobs sind diagnostisch und kein kontrollierter Geschwindigkeitsbenchmark.

## Einzelmessungen

| Messung | ProSE Legacy | ProSE auto | + Evidenz | ANDES auto | ProSE auto, Seed-Spanne |
|---|---:|---:|---:|---:|---|
| velos_125_R1 | 2480.7 | 2764.7 | 2840.7 | 3035.0 | 2710–2825 |
| velos_5000_R2 | 2658.3 | 2878.0 | 2852.3 | 3002.7 | 2830–2920 |
| velos_25000_R3 | 2533.7 | 2705.0 | 2795.7 | 2964.0 | 2685–2721 |
| hfx_A2 | 4435.0 | 4435.0 | 4481.3 | 4689.7 | 4414–4449 |
| hfx_B1 | 4233.7 | 4233.7 | 4252.0 | 4722.3 | 4218–4260 |
| hfx_B3 | 4315.3 | 4315.3 | 4383.3 | 4699.7 | 4285–4336 |
| astral_A2 | 1852.3 | 1852.3 | 2184.3 | 2839.0 | 1768–1977 |
| astral_B1 | 2310.7 | 2310.7 | 2548.3 | 3175.0 | 2263–2368 |
| astral_B3 | 2148.7 | 2148.7 | 2411.3 | 3207.3 | 2120–2165 |
| lumos_lfq_5192 | 5463.0 | 5463.0 | 5481.0 | 5590.7 | 5457–5467 |
| lumos_lfq_5194 | 5448.7 | 5448.7 | 5444.3 | 5640.0 | 5448–5450 |
| lumos_lfq_5199 | 5477.0 | 5477.0 | 5478.0 | 5618.0 | 5476–5478 |
| lumos_tmt_5058 | 2247.7 | 2297.3 | 2254.3 | 2440.3 | 2267–2318 |
| lumos_tmt_5059 | 2321.3 | 2316.0 | 2340.7 | 2393.3 | 2306–2335 |
| lumos_tmt_5066 | 2388.7 | 2495.0 | 2507.3 | 2573.0 | 2485–2511 |
| eclipse_tmtpro_10855 | 2392.0 | 2392.0 | 2385.3 | 2686.3 | 2354–2420 |
| eclipse_tmtpro_10858 | 2132.7 | 2132.7 | 2184.0 | 2370.0 | 2085–2168 |
| eclipse_tmtpro_10863 | 2190.7 | 2190.7 | 2221.0 | 2451.3 | 2171–2201 |
| tims_plasma_30min | 1042.3 | 1042.3 | 1033.3 | 1013.0 | 1030–1052 |
| tims_plasma_50min | 1034.7 | 1034.7 | 1017.0 | 915.0 | 1010–1069 |

## Native Identifikationsausbeute ohne Percolator

Konservative Target-Decoy-Auswertung des besten nativen Kandidaten pro Spektrum, Score-Ties gemeinsam, (D+1)/T ≤ 1%. Für ANDES wird bei Strong-Ranking `RawScore` und bei LowRes-Rank-Ranking `RankScore + EdgeScore` verwendet; diese Wahl folgt dem tatsächlichen nativen Queue-Score und wurde gegen die ausgegebene Kandidatenreihenfolge geprüft. Ein Wert von 0 bedeutet, dass kein globaler Rohscore-Grenzwert die konservative 1%-Schwelle erreicht. Die zusätzlichen lokalen Evidenzmerkmale verändern diesen nativen Output nicht.

| Messung | ProSE Legacy | ProSE auto | ANDES auto |
|---|---:|---:|---:|
| velos_125_R1 | 1822 | 2374 | 0 |
| velos_5000_R2 | 1916 | 2407 | 1625 |
| velos_25000_R3 | 1820 | 2251 | 1455 |
| hfx_A2 | 3870 | 3870 | 3762 |
| hfx_B1 | 3688 | 3688 | 3805 |
| hfx_B3 | 3859 | 3859 | 3835 |
| astral_A2 | 1450 | 1450 | 1117 |
| astral_B1 | 1730 | 1730 | 1236 |
| astral_B3 | 1657 | 1657 | 1100 |
| lumos_lfq_5192 | 5383 | 5383 | 5261 |
| lumos_lfq_5194 | 5306 | 5306 | 5145 |
| lumos_lfq_5199 | 5349 | 5349 | 5266 |
| lumos_tmt_5058 | 1745 | 2038 | 1635 |
| lumos_tmt_5059 | 1843 | 2011 | 1424 |
| lumos_tmt_5066 | 1983 | 2258 | 1655 |
| eclipse_tmtpro_10855 | 1989 | 1989 | 2500 |
| eclipse_tmtpro_10858 | 1770 | 1770 | 2327 |
| eclipse_tmtpro_10863 | 1833 | 1833 | 2306 |
| tims_plasma_30min | 850 | 850 | 426 |
| tims_plasma_50min | 780 | 780 | 0 |

## Protokoll und Grenzen

Gemeinsamer Suchraum: vollständig tryptisch (Trypsin/P-äquivalent), zwei Missed Cleavages, 7–40 Aminosäuren, Ladung 2–5, fixes CAM an C, maximal eine M-Oxidation; bei markierten Proben zusätzlich fixes TMT/TMTpro an K und Peptid-N-Terminus. Vorläufertoleranz 20 ppm, bei TMTpro 50 ppm; entsprechende Isotopenfehlerfenster mit korrekter Vorzeichenumrechnung. Vorläuferkalibration deaktiviert. Nativer Peakfilter, Kandidatenalgorithmus und Evidenzmerkmale der Engines bleiben unterschiedlich. Retentionszeit-Prädiktionsmerkmale wurden für beide Seiten aus dem PIN entfernt.

Die Stichprobe erfasst über den gesamten Lauf verteilte, nichtleere centroidierte MS2 mit bekannter Ladung 2–5. MS1, MS3, Profile, andere Ladungen und nicht angegebene Ladungen gehören nicht zu diesem Vergleich. SPS-MS3-Quantifizierung wird nicht getestet. Das Protokoll untersucht eine gemeinsame einfache Closed Search und optimiert nicht jede Studie auf ihre maximale Ausbeute.

Nicht abgedeckt: echte Eclipse-Daten, SCIEX/Waters-Suchläufe, ETD/EThcD, DIA, alternative Proteasen, semi-/unspezifische Suchen, Glyko-/Phosphoproteomik und vollständige Rohdaten-Workflows. Passende TripleTOF-DDA-Profildaten in PXD020785 wurden identifiziert; vor ihrer Einbeziehung braucht es eine kontrollierte gemeinsame Centroidierung. Mehr q≤1%-Treffer allein belegen keine allgemein bessere Fehlerkontrolle.

## Quellen und Reproduktion

- [OpenMS Testdatenarchiv](https://archive.openms.de/openms/benchmarks/pride-benchmarks/)
- [quantms Testdatensätze und Beschreibungen](https://github.com/bigbio/quantms-test-datasets/tree/quantms/benchmarks)
- [PXD028735, HYE/Instrumentvergleich](https://www.ebi.ac.uk/pride/archive/projects/PXD028735)
- [PXD001819, UPS1/Hefe](https://www.ebi.ac.uk/pride/archive/projects/PXD001819)
- [PXD007683, LFQ/TMT](https://www.ebi.ac.uk/pride/archive/projects/PXD007683)
- [PXD054559, TMTpro](https://www.ebi.ac.uk/pride/archive/projects/PXD054559)
- [PXD053748, timsTOF HT/Sage-Plasma-Benchmark](https://www.ebi.ac.uk/pride/archive/projects/PXD053748)
- [ProSE PR #10335](https://github.com/OpenMS/OpenMS/pull/10335)

Die Begleitarchive enthalten die exakten ausgewählten mzML-Dateien, Target-Decoy-Datenbanken, Parameter, Eingangsprüfungen, Auswertungen, Logs, Reproduktionsskripte und Diagnostik. Vollständige Rohdateien lassen sich über die aufgezeichneten URLs und SHA-256-Prüfsummen wiederbeschaffen. Siehe `README_reproduce.md`.
