import hashlib,json
from pathlib import Path
import pyopenms as p
R=Path(__file__).resolve().parent;W=R.parent
records={}
for db in ['hy','hye','human']:
 src=R/'data/hye_targets.fasta'
 entries=p.FASTAFile().load(str(src))
 if db=='hy':entries=[e for e in entries if e.identifier.endswith(('_HUMAN','_YEAST')) or 'Cont_' in e.identifier]
 if db=='human':entries=[e for e in entries if e.identifier.endswith('_HUMAN') or 'Cont_' in e.identifier]
 out=R/'data'/(db+'_td.fasta')
 with out.open('w') as f:
  for e in entries:f.write('>'+e.identifier+' '+e.description+'\n'+e.sequence+'\n')
  for e in entries:f.write('>DECOY_'+e.identifier+'\n'+e.sequence[::-1]+'\n')
 records[db]=dict(targets=len(entries),decoys=len(entries),source=str(src.relative_to(W)),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),decoy_method='full sequence reversal once, identical target-decoy FASTA supplied to both engines')
for label in ['none','TMT6plex','TMTpro']:
 mods=[('Carbamidomethyl (C)','C','fix','any'),('Oxidation (M)','M','opt','any')]
 if label!='none':mods += [(label+' (K)','K','fix','any'),(label+' (N-term)','*','fix','N-term')]
 lines=['NumMods=1']
 for name,aa,typ,loc in mods:lines.append(f'{p.ModificationsDB().getModification(name).getDiffMonoMass():.9f},{aa},{typ},{loc},{name}')
 (R/'data'/('mods_'+label+'.txt')).write_text('\n'.join(lines)+'\n')
(R/'provenance/databases.json').write_text(json.dumps(records,indent=2));print(records)
