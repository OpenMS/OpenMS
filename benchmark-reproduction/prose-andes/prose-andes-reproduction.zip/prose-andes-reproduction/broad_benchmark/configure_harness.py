"""Update the generated test-data path when unpacking into another directory."""
import re
from pathlib import Path
W=Path(__file__).resolve().parents[1]
p=W/'native_cid/include/OpenMS/test_config.h'
s=p.read_text();s=re.sub(r'"[^"]*/OpenMS/src/tests/class_tests/openms/data/"', '"'+str(W/'OpenMS/src/tests/class_tests/openms/data')+'/"',s)
p.write_text(s)
print('Configured test-data path:',W/'OpenMS/src/tests/class_tests/openms/data')
