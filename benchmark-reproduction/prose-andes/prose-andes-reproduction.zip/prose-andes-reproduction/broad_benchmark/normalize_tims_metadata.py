"""Canonicalize exporter metadata, without changing the selected spectra or peaks."""
import hashlib,json
from pathlib import Path
from lxml import etree as E
R=Path(__file__).resolve().parent;Q='{http://psi.hupo.org/ms/mzml}'
for id in ['tims_plasma_30min','tims_plasma_50min']:
 p=R/'data'/(id+'.mzML');m=R/'provenance'/(id+'.json');tree=E.parse(str(p));meta=json.load(open(m));n=0
 for spec,d in zip(tree.iter(Q+'spectrum'),meta['scans']):
  for act in spec.iter(Q+'activation'):
   if any(x.get('name')=='CID' for x in act if x.tag==Q+'userParam') and not any(x.get('accession')=='MS:1000133' for x in act):
    E.SubElement(act,Q+'cvParam',cvRef='PSI-MS',accession='MS:1000133',name='collision-induced dissociation',value='');d['activation_normalization']='Exporter userParam CID represented as standard CV MS:1000133 for both engines';n+=1
 tree.write(str(p),encoding='utf-8',xml_declaration=True);meta['metadata_normalizations']=['Original index=N native IDs canonicalized to scan=N for both engines; original IDs retained','Activation userParam CID also represented by standard CV MS:1000133 for both engines; analyzer remains TOF from original header'];meta['sha256']=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();m.write_text(json.dumps(meta,indent=2));print(id,n)
