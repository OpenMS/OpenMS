import hashlib,json
from pathlib import Path
import pyopenms as p
R=Path(__file__).resolve().parent;report=[]
for r in json.load(open(R/'manifest.json')):
 path=R/'data'/(r['id']+'.mzML');m=R/'provenance'/(r['id']+'.json')
 if not path.exists():continue
 d=json.load(open(m));e=p.MSExperiment();p.MzMLFile().load(str(path),e);assert len(e)==d['selected']
 for s,scan in zip(e,d['scans']):
  assert s.getMSLevel()==2 and s.getNativeID()==scan.get('benchmark_native_id',scan['native_id'])
  assert len(s.getPrecursors())==1 and s.getPrecursors()[0].getCharge()==scan['charge']
  assert abs(s.getPrecursors()[0].getMZ()-scan['precursor_mz'])<1e-8
  assert len(s)>0
 report.append(dict(dataset=r['id'],loaded=len(e),unique_native_ids=len({s.getNativeID() for s in e}),selected_sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()))
 print(r['id'],len(e),flush=True)
(R/'provenance/input_validation.json').write_text(json.dumps(report,indent=2))
