"""Per-run yield, paired seed deltas, native TDC and spectrum-level agreement."""
import collections,csv,gzip,json,math,re,statistics
from pathlib import Path
R=Path(__file__).resolve().parent
ARMS=['prose_legacy','prose_auto','prose_evidence','andes','andes_highres','prose_min3','prose_all_index_ions','prose_no_deisotope','prose_multiple_raw']
def sequence(s):
 if s.count('.')>=2:s=s.split('.',1)[1].rsplit('.',1)[0]
 return re.sub('[^A-Z]','',re.sub(r'\([^)]*\)|\[[^]]*\]|[+-]\d+\.\d+','',s)).replace('L','I')
def read_accepted(folder,seed):
 p=folder/f's{seed}'/'target.tsv'
 if not p.exists():return {}
 with p.open() as f:rows=[d for d in csv.DictReader(f,delimiter='\t') if float(d['q-value'])<=.01]
 result={int(d['PSMId'].rsplit('_',2)[-2]):(sequence(d['peptide']),d) for d in rows}
 assert len(result)==len(rows), (folder,seed,'multiple accepted candidates for one observed spectrum')
 return result
def native(folder):
 # native rank-one competition, score ties handled together, conservative +1.
 path=folder/'input.pin'
 if not path.exists():return None
 is_andes=folder.name.startswith('andes')
 strong=is_andes and 'score mode: strong' in (folder/'search.log').read_text()
 score=('RawScore' if strong else 'RankScore + EdgeScore') if is_andes else None
 winners={}
 with path.open() as f:
  for d in csv.DictReader(f,delimiter='\t'):
   if score is None:score=next((k for k in ['hyperscore','calibrated_score','score'] if k in d),None)
   if score is None:return None
   scan=int(d['ScanNr']);v=(float(d['RankScore'])+float(d['EdgeScore'])) if score=='RankScore + EdgeScore' else float(d[score]);label=int(d['Label'])
   if scan not in winners or (v,-label)>(winners[scan][0],-winners[scan][1]):winners[scan]=(v,label)
 bins=collections.defaultdict(lambda:[0,0])
 for v,lab in winners.values():bins[v][lab==-1]+=1
 t=d=best=0
 for v,(nt,nd) in sorted(bins.items(),reverse=True):
  t+=nt;d+=nd
  if (d+1)/max(t,1)<=.01:best=t
 return dict(psms=best,feature=score,scored_spectra=len(winners))
def main():
 rows=[];agreement=[];regression=[]
 for r in json.load(open(R/'manifest.json')):
  d=r['id'];base=R/'results'/d
  for arm in ARMS:
   f=base/arm;vals=[];peps=[]
   for seed in [1,42,137]:
    a=read_accepted(f,seed)
    if (f/f's{seed}/result.json').exists():vals.append(len(a));peps.append(len({v[0] for v in a.values()}))
   if vals:
    rec=dict(dataset=d,arm=arm,seed_psms=vals,mean_psms=statistics.mean(vals),min_psms=min(vals),max_psms=max(vals),mean_distinct_sequences=statistics.mean(peps),native=native(f));rows.append(rec)
  if all((base/a/'input_checks.json').exists() for a in ['prose_legacy','prose_auto']):
   checks={a:json.load(open(base/a/'input_checks.json')) for a in ['prose_legacy','prose_auto']}
   regression.append(dict(dataset=d,same_pin=checks['prose_legacy']['sha256']==checks['prose_auto']['sha256'],resolved=checks['prose_auto']['resolved']))
  for seed in [1,42,137]:
   a=read_accepted(base/'prose_auto',seed);b=read_accepted(base/'andes',seed)
   if a and b:
    shared=a.keys()&b.keys();agree=sum(a[k][0]==b[k][0] for k in shared)
    agreement.append(dict(dataset=d,seed=seed,prose=len(a),andes=len(b),shared_spectra=len(shared),same_sequence=agree,conflicting_sequences=len(shared)-agree,prose_only=len(a.keys()-b.keys()),andes_only=len(b.keys()-a.keys())))
 (R/'summary.json').write_text(json.dumps(dict(yield_results=rows,agreement=agreement,auto_regression=regression),indent=2))
 with (R/'summary.tsv').open('w') as f:
  w=csv.writer(f,delimiter='\t');w.writerow(['dataset']+ARMS+['auto_vs_legacy_pct','auto_vs_andes_pct'])
  for d in dict.fromkeys(x['dataset'] for x in rows):
   a={x['arm']:x['mean_psms'] for x in rows if x['dataset']==d};w.writerow([d]+[round(a[x],2) if x in a else '' for x in ARMS]+[round(100*(a['prose_auto']/a[x]-1),2) if x in a and 'prose_auto' in a else '' for x in ['prose_legacy','andes']])
 print((R/'summary.tsv').read_text())

if __name__=='__main__':main()
