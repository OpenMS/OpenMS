import csv,gzip,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'broad_benchmark'
ENV=dict(os.environ,OMP_NUM_THREADS='4',OPENMS_DATA_PATH=str(ROOT/'nightly/pyopenms/share/OpenMS'),PYTHONPATH=str(ROOT/'nightly')+os.pathsep+str(ROOT/'deps'))
ARMS={'prose_auto':{},'prose_legacy':{'scoring:method':'hyperscore','scoring:fragment_charges':'single'},'prose_evidence':{'annotate:local_fragment_evidence':'true'}}
def command(cmd,folder,name):
 cmd=[str(x) for x in cmd];start=time.monotonic()
 with (folder/(name+'.log')).open('w') as f:
  process=subprocess.Popen(cmd,stdout=f,stderr=f,env=ENV,cwd=ROOT);_,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
 record=dict(command=cmd,returncode=process.returncode,seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime)
 (folder/(name+'.command.json')).write_text(json.dumps(record,indent=2))
 if process.returncode:raise RuntimeError((cmd,process.returncode,(folder/(name+'.log')).read_text()[-2000:]))
 return record

def search(r,arm):
 folder=OUT/'results'/r['id']/arm;folder.mkdir(parents=True,exist_ok=True)
 if (folder/'input_checks.json').exists():
  check=json.load(open(folder/'input_checks.json'))
  assert check.get('database_sha256')==json.load(open(OUT/'provenance/databases.json'))[r['database']]['sha256'], 'stale FASTA result'
  assert check.get('mzml_sha256')==json.load(open(OUT/'provenance'/(r['id']+'.json')))['sha256'], 'stale mzML result'
  if arm.startswith('andes'):return folder
  old=json.load(open(folder/'params.json'))
  if old['fragment:mass_tolerance']==r['fragment_tolerance'] and old['fragment:mass_tolerance_unit']==r['fragment_unit']:return folder
  for target in folder.glob('s*'):
   if target.is_dir() and target.name[1:].isdigit():shutil.rmtree(target)
  (folder/'input_checks.json').unlink()
 mzml=OUT/'data'/(r['id']+'.mzML');fasta=OUT/'data'/(r['database']+'_td.fasta');prec=50 if r['label']=='TMTpro' else 20
 if arm.startswith('andes'):
  cmd=[ROOT/'andes/target/release/andes','--spectrum',mzml,'--database',fasta,'--output-pin',folder/'native.pin','--output-tsv',folder/'native.tsv','--threads','4','--candidate-index','mmap','--mmap-window-cache-candidates','200000','--fragment-index-slice-da','10','--decoy-strategy','none','--decoy-prefix','DECOY','--precursor-tol',f'{prec}ppm','--charge','2..5','--top-n','10','--max-missed-cleavages','2','--min-length','7','--max-length','40','--max-mods','1','--mods',OUT/'data'/('mods_'+r['label']+'.txt'),'--precursor-cal','off','--isotope-error=-1..2','--protocol','standard' if r['label']=='none' else 'TMT']
  if arm=='andes_highres':cmd += ['--model','hcd_qexactive_tryp']
 else:
  params=json.loads((ROOT/'native_cid/params/baseline.json').read_text());params.update({'fragment:mass_tolerance':float(r['fragment_tolerance']),'fragment:mass_tolerance_unit':r['fragment_unit'],'precursor:mass_tolerance_lower':float(prec),'precursor:mass_tolerance_upper':float(prec),'peptide:missed_cleavages':2})
  for k in ['scoring:method','scoring:fragment_charges','annotate:local_fragment_evidence']:params.pop(k,None)
  if r['label']!='none':params['modifications:fixed'] += [r['label']+' (K)',r['label']+' (N-term)']
  params.update(ARMS[arm]);(folder/'params.json').write_text(json.dumps(params,indent=2))
  cmd=[ROOT/'native_cid/build/prose',mzml,fasta,folder/'params.json',folder/'native.tsv',folder/'search.idXML']
 rec=command(cmd,folder,'search');command(['python3',OUT/'export.py',r['id'],arm],folder,'export')
 for name in ['search.idXML','native.pin']:
  path=folder/name
  if path.exists():
   with path.open('rb') as src,gzip.open(str(path)+'.gz','wb',compresslevel=1) as dst:shutil.copyfileobj(src,dst)
   path.unlink()
 print(dict(event='search',dataset=r['id'],arm=arm,seconds=rec['seconds']),flush=True)
 return folder

def rescore(folder,seed):
 target=folder/f's{seed}';target.mkdir(exist_ok=True)
 if (target/'result.json').exists():return json.loads((target/'result.json').read_text())
 rec=command([ROOT/'percolator/usr/bin/percolator','-Y','-U','--seed',seed,'--results-psms',target/'target.tsv','--decoy-results-psms',target/'decoy.tsv',folder/'input.pin'],target,'percolator')
 count=json.loads((folder/'input_checks.json').read_text())['candidate_rows'];assert f'Found {count} PSMs' in (target/'percolator.log').read_text()
 with (target/'target.tsv').open() as f:accepted=sum(float(x['q-value'])<=.01 for x in csv.DictReader(f,delimiter='\t'))
 result=dict(dataset=folder.parent.name,arm=folder.name,seed=seed,accepted=accepted,seconds=rec['seconds']);(target/'result.json').write_text(json.dumps(result,indent=2));print(dict(event='percolator',**result),flush=True);return result
if __name__=='__main__':
 rows=json.loads((OUT/'manifest.json').read_text());mode=sys.argv[1] if len(sys.argv)>1 else 'all';selected=sys.argv[2:]
 folders=[]
 for r in rows:
  if selected and r['id'] not in selected:continue
  if not (OUT/'data'/(r['id']+'.mzML')).exists():continue
  for arm in list(ARMS)+['andes']:
   folder=OUT/'results'/r['id']/arm
   if mode!='rescore':search(r,arm)
   if (folder/'input_checks.json').exists():folders.append(folder)
 if mode!='search':
  with ThreadPoolExecutor(2) as ex:
   for f in as_completed([ex.submit(rescore,x,s) for x in folders for s in [1,42,137]]):f.result()
