"""Recompute the Astral seed-42 sequence-assignment categories used in the PR."""
import argparse,collections,csv,gzip,json,sys
from pathlib import Path
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W/'broad_benchmark'))
from analyze import sequence
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-root',type=Path,default=W/'reruns');p.add_argument('--stage',default='native_dedup');p.add_argument('--arm',default='mass7_evidence');a=p.parse_args()
def read(path):return path.open() if path.exists() else gzip.open(str(path)+'.gz','rt')
def accepted(folder):
 with read(folder/'s42/target.tsv') as f:return {int(r['PSMId'].rsplit('_',2)[-2]):sequence(r['peptide']) for r in csv.DictReader(f,delimiter='\t') if float(r['q-value'])<=.01}
total=collections.Counter()
for d in ['astral_A2','astral_B1','astral_B3']:
 folder=a.output_root/a.stage/d/a.arm;prose=accepted(folder);andes=accepted(a.output_root/'broad_benchmark'/d/'andes');cands=collections.defaultdict(list)
 with read(folder/'input.pin') as f:
  for r in csv.DictReader(f,delimiter='\t'):cands[int(r['ScanNr'])].append(sequence(r['Peptide']))
 cats=collections.Counter()
 for scan,seq in andes.items():
  if prose.get(scan)==seq:key='same_sequence_accepted'
  elif scan not in cands:key='no_candidate'
  elif seq not in cands[scan]:key='absent_top10'
  elif cands[scan][0]==seq:key='native_rank1_not_accepted'
  else:key='below_rank1'
  cats[key]+=1
 total.update(cats);print(json.dumps(dict(dataset=d,categories=cats)))
print(json.dumps(dict(total=total)))
