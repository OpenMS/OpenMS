# ProSE: Deduplikation vor der Kandidatenauswahl

Stand: 29. September 2026. [Pull Request #10335](https://github.com/OpenMS/OpenMS/pull/10335).
Öffentlicher Commit: `0af4cf62dc9e0ab944102a0647df1ecd431e32bb`. Getesteter Tree: `3ffb32ea9ac43d3e0a833863d6b6c38e602fcb72`.
Kontrolle: `48dc1c22adc25ca2656448676f0ba2a663ccb6fe`; ANDES: `b7eaece219ef45198eb233030cf9d69075988f72`.

## Ergebnis

Identische modifizierte Peptide aus mehreren Proteinen konnten bisher mehrfach das Kandidatenlimit belegen und den Abstand zum zweitbesten Kandidaten sowie die Kandidatenstatistik verzerren. ProSE dedupliziert jetzt vor Fragmentindexierung und Kandidatenauswahl. In den drei bisherigen Astral-Mass-Accuracy-PINs waren 12.362 Zeilen redundant, darunter identische erste und zweite Hypothesen in 1.793 Spektren. In allen 26 neuen PINs bleiben **null redundante Hypothesen** nach dem dokumentierten Identitätsschlüssel.

Die Korrektur verbessert die Percolator-Ausbeute in allen sieben Instrument-/Messartgruppen im Mittel. Die nativen TDC-Trefferzahlen des Standardmodus sind in allen 20 Messungen unverändert. Das ist somit überwiegend ein Gewinn durch bessere native Kandidatenlisten und Merkmale für Percolator, kein gleich großer Gewinn des nativen Hauptscores.

Auf Astral mit raw retrieval und Mass Accuracy steigt die Summe der mittleren PSM-Zahlen durch Deduplikation **7.551,7 → 7.818,0 (+3,53%)**; nativ **6.571 → 6.595 (+0,37%)**. Die bestehenden optionalen lokalen Merkmale erhöhen anschließend auf **8.337,3 (+6,64%)**; nativ unverändert. ANDES erreicht 9.221,3. Der relative Rückstand sinkt so **18,11% → 15,22% → 9,59%**. Gegenüber dem ursprünglichen Auto/Auto-Stand `bcbc2f1` sind das **+32,09%** bzw. **69,62% der ursprünglichen Ausbeutelücke geschlossen**. Die kombinierte Einstellung ist nur auf den drei Astral-Läufen geprüft und bleibt opt-in.

## Native Änderungen und Kompatibilität

- `peptide:deduplicate=true` ist der neue ProSE-Standard. Identität ist die vollständige modifizierte Sequenz; Modifikationspositionen und tatsächliche I/L-Sequenzen bleiben verschieden. Die erste ursprüngliche Proteinposition dient nur der Rekonstruktion. Vollständige Proteinzuordnungen und Target/Decoy-Einstufung erfolgen weiterhin per PeptideIndexing gegen die komplette FASTA. Eine geteilte Target/Decoy-Sequenz behält `target+decoy`; reine Decoys bleiben Decoys.
- Kompakte Hashwerte gruppieren mögliche Duplikate; bei gleichem Hash wird immer die vollständige Sequenz verglichen. Hashkollisionen können deshalb keine unterschiedlichen Peptide zusammenlegen. Die Reihenfolge der verbleibenden Vertreter bleibt erhalten.
- Bei Datenbank-Chunks wird jede Peptid/Ladungs/Isotopen-Hypothese nur einmal gescort und gezählt. Die dafür gespeicherten vollständigen Schlüssel benötigen zusätzlichen Speicher pro Spektrum. Das weiterhin pro Chunk angewandte Kandidatenlimit kann andere Kandidatenpools ergeben als eine ungechunkte Suche.
- `peptide:deduplicate=false` stellt das vorherige Verhalten wieder her. Die eigenständige FragmentIndex-API behält standardmäßig false. SNES-Mutterindizes werden nicht dedupliziert. Score-Auto, raw retrieval und lokale Merkmale behalten ihre bisherigen Einstellungen.
- Zusätzlich behoben: Ein zweiter `FragmentIndex::build()` addierte vorher alte Peptide erneut. Der isolierte Nachweis liefert vorher **1 → 2**, jetzt **1 → 1**. Neubau ersetzt die vorherigen Puffer; nach einem fehlgeschlagenen Aufbau ist `isBuild()` false. Die Messmatrix nutzt frische Indexobjekte und war von diesem separaten Fehler nicht betroffen.

## Breite gepaarte Prüfung des neuen Standards

20 Messungen × 8.000 MS2 = 160.000 MS2, sechs Instrumentmodelle und sieben Gruppen. Mittelwerte akzeptierter PSMs pro Messung über Seeds 1/42/137, Percolator 3.09.0 `-Y -U`, q≤0,01. Vorher ist der bisherige Standard ohne Deduplikation; beide Arme verwenden dieselben Inputs und sonstigen Parameter. Die FDR wird je Datei ausgewertet; die Zahlen sind Mittel solcher getrennten Auswertungen.

| Instrument / Messart | n | Vorher | Dedupliziert | Änderung | ANDES |
|---|---:|---:|---:|---:|---:|
| Velos CID | 3 | 2782.6 | 2876.6 | +3.38% | 3000.6 |
| HF-X HCD | 3 | 4365.9 | 4383.3 | +0.40% | 4703.9 |
| Astral HCD | 3 | 2146.1 | 2162.1 | +0.75% | 3073.8 |
| Lumos HCD/LFQ | 3 | 5477.8 | 5479.4 | +0.03% | 5616.2 |
| Lumos CID/TMT | 3 | 2369.4 | 2398.9 | +1.24% | 2468.9 |
| Exploris 480 HCD/TMTpro | 3 | 2229.4 | 2247.4 | +0.81% | 2502.6 |
| timsTOF HT Plasma | 2 | 1029.8 | 1038.0 | +0.79% | 964.0 |

Die größte einzelne Standard-Regression ist Astral B1 **−1,27%** (Seed-Differenzen +62 / −45 / −105). Weitere Verluste: Exploris 10855 −0,76%, timsTOF 30 min −0,64%, Lumos LFQ 5199 −0,08%. Die Daten belegen keine generelle Regressionsfreiheit. Alle neun gepaarten Velos-Seed-Vergleiche sind positiv. Alle neun zusätzlichen Astral-Vergleiche für lokale Merkmale gegen die bereits deduplizierte Mass-Accuracy-Kontrolle sind positiv.

## Verbleibende Lücke

| Kategorie, ANDES Seed 42 | Vor Deduplikation | Dedupliziert + lokale Merkmale |
|---|---:|---:|
| Gleiche Sequenz akzeptiert | 6717 | 7304 |
| Kein Kandidat | 23 | 23 |
| Sequenz fehlt in Top 10 | 426 | 402 |
| In Top 10, unter Rang 1 | 718 | 679 |
| Rang 1, nicht als gleiche Sequenz akzeptiert | 1482 | 958 |

Verglichen werden 9.366 ANDES-akzeptierte Astral-Sequenzzuordnungen bei Seed 42, ohne Modifikationen und mit I/L-Äquivalenz. ANDES ist kein Wahrheitsstandard. Von 2.062 verbleibenden abweichenden Zuordnungen haben 425 keine passende Sequenz in der ProSE-Top-10-Liste; **1.637 (79,4%)** betreffen Rangfolge/Akzeptanz bei bereits vorhandenem Kandidaten. Das grenzt die weitere native Arbeit auf die Qualität der Fragment-Evidenz und Kandidatenbewertung ein. Die Fehlerursache einer einzelnen Zuordnung ist damit noch nicht bewiesen. Die optionalen lokalen Merkmale ändern den Hauptscore und die native Reihenfolge nicht.

## Validierung und Ressourcen

**26 Suchläufe und 78 Percolator-Läufe abgeschlossen; 8 von 8 finalen Vergleichsläufen dokumentiert.** Die endgültige kompakte Implementierung wird gegen die eingefrorene Deduplikationsvariante und den Legacy-Modus bytegenau geprüft (native Tabellen und normalisierte PINs). Bei gleichen PINs sind neue Percolator-Läufe unnötig.

Drei C++-Tests bestanden: HyperScore, ProSEAlgorithm, FragmentIndex. Neue Regressionstests prüfen Kandidatenlimit, sämtliche Proteinzugänge, Target+Decoy und reine Decoys, PTM-Positionen und Protein-N-Termini, Ladungs-/Isotopenhypothesen sowie Statistiken in Single-, Chunk- und Multi-File-Pfaden mit Auto und Mass Accuracy. Ein gesonderter Test prüft wiederholten/fehlgeschlagenen Indexaufbau. Changed-line clang-format 20.1.8 und `git diff --check` bestanden.

Build-Scope: ProSEAlgorithm, FragmentIndex, HyperScore und TheoreticalSpectrumGenerator aus aktuellem C++23/OpenMP-Source; unveränderter Support aus offiziellem pyOpenMS 3.6.0.dev20260928, GCC 13.3. Kein vollständiger Clean-Build aller OpenMS-Komponenten; Python-Erweiterung in diesem Schritt nicht neu gebaut. Keine neuen öffentlichen Funktionssignaturen oder Binding-Änderungen.

Serielle abschließende Läufe, vier OpenMP-Threads, dasselbe endgültige Binary:

| Messung | Deduplikation | Sekunden | Max. RSS (MiB) |
|---|---|---:|---:|
| astral_A2 | aus | 22.63 | 3032.2 |
| astral_A2 | an | 26.11 | 2664.3 |
| velos_125_R1 | aus | 31.80 | 2539.7 |
| velos_125_R1 | an | 35.09 | 2408.7 |

Jeweils eine Beobachtung pro Konfiguration, keine belastbare Laufzeitstatistik. Der erste Vollstring-Prototyp erreichte auf Astral A2 3.568,7 MiB unter paralleler Last; die endgültige Version verwendet kompakte Fingerprints. Die Deduplikation kostet zusätzliche Indexaufbau-Arbeit. Chunked-Suchen behalten zusätzliche Identitätsschlüssel; maximale Speicher- und Laufzeitkosten auf sehr großen Datenbanken sind nicht etabliert.

## Reproduzierbarkeit und Grenzen

Das Testpaket enthält alle neuen nativen/PIN- und Target/Decoy-Percolator-Tabellen, Parameter, Binär-/Input-Hashes, Befehle, Logs, Analyseprogramme, finale Verifikationen und Quellcode-Patches. Unveränderte Messdaten bleiben in den zuvor gelieferten `ProSE_ANDES_Testinputs_01.zip` und `_02.zip`. `REPRODUCE.md` erläutert die Schritte.

Die [OpenMS-Archivquellen](https://archive.openms.de/openms/benchmarks/pride-benchmarks/) stehen einzeln im Manifest; timsTOF stammt aus [PXD053748](https://www.ebi.ac.uk/pride/archive/projects/PXD053748). Die vollständige HYE-FASTA enthält 31.889 Targets (SHA256 `d9ac434d88492c10c8e9a587ee7dbc9480fa0995fa07a6ba35a7da8abf39aa25`). Frühere unvollständige HYE-Tabellen sind ungültig und werden nicht verwendet. Der Archivordner „Eclipse“ enthält laut Metadaten Exploris-480-Daten. ANDES Auto verwendet für timsTOF den bereits gemeldeten LowRes-Fallback; der engineübergreifende Vergleich dort ist nicht auf gleiche Auflösung abgestimmt.

Feste Suchbedingungen: Trypsin/P, zwei missed cleavages, Länge 7–40, CAM(C), maximal eine Oxidation(M), passende Label-Modifikationen, bekannte Ladungen 2–5, 20 ppm Precursor (TMTpro 50 ppm), 20 ppm oder 0,5 Da Fragmente, äquivalente Isotopenhypothesen, Kalibrierung aus, 50 Kandidaten und Top 10. PIN-Massen sind einheitlich normalisiert; keine extern vorhergesagten RT-/Intensitätsmerkmale. Native TDC verwendet einen Gewinner je Spektrum, Decoy-Vorrang bei Score-Gleichheit und vollständige Score-Gruppen mit `(D+1)/T≤0,01`.

Nominale q-Werte belegen keine unabhängig gemessene tatsächliche FDR. Seeds sind keine biologischen Replikate. A2 diente auch explorativen Entscheidungen; die übrigen Messungen sind breitere Prüfung, kein verblindeter Test. SCIEX, Waters, ETD und DIA wurden hier nicht hinsichtlich Identifikationsausbeute validiert.

## Alle neuen Experimente

Für `default` ist die Kontrolle der vorherige Standard; für `mass7_raw` der bisherige Raw/Mass-Accuracy-Stand; für `mass7_evidence` der neue deduplizierte Raw/Mass-Accuracy-Stand ohne lokale Merkmale.

| Messung | Modus | Seeds 1 / 42 / 137 | Mittel | Gepaarte Änderung | Nativ vorher → nachher |
|---|---|---:|---:|---:|---:|
| astral_A2 | default | 2002 / 2018 / 1915 | 1978.3 | +1.56% | 1465 → 1465 |
| astral_A2 | mass7_evidence | 2549 / 2574 / 2605 | 2576.0 | +7.01% | 2011 → 2011 |
| astral_A2 | mass7_raw | 2373 / 2438 / 2411 | 2407.3 | +6.19% | 2009 → 2011 |
| astral_B1 | default | 2327 / 2255 / 2276 | 2286.0 | -1.27% | 1745 → 1745 |
| astral_B1 | mass7_evidence | 2887 / 2954 / 2877 | 2906.0 | +6.01% | 2318 → 2318 |
| astral_B1 | mass7_raw | 2757 / 2706 / 2761 | 2741.3 | +0.22% | 2301 → 2318 |
| astral_B3 | default | 2203 / 2215 / 2248 | 2222.0 | +2.16% | 1668 → 1668 |
| astral_B3 | mass7_evidence | 2856 / 2832 / 2878 | 2855.3 | +6.97% | 2266 → 2266 |
| astral_B3 | mass7_raw | 2710 / 2652 / 2646 | 2669.3 | +4.71% | 2261 → 2266 |
| eclipse_tmtpro_10855 | default | 2342 / 2387 / 2363 | 2364.0 | -0.76% | 1998 → 1998 |
| eclipse_tmtpro_10858 | default | 2116 / 2146 / 2124 | 2128.7 | +0.82% | 1782 → 1782 |
| eclipse_tmtpro_10863 | default | 2269 / 2237 / 2243 | 2249.7 | +2.49% | 1846 → 1846 |
| hfx_A2 | default | 4477 / 4520 / 4486 | 4494.3 | +0.31% | 3924 → 3924 |
| hfx_B1 | default | 4317 / 4319 / 4277 | 4304.3 | +0.84% | 3773 → 3773 |
| hfx_B3 | default | 4359 / 4328 / 4367 | 4351.3 | +0.07% | 3936 → 3936 |
| lumos_lfq_5192 | default | 5481 / 5479 / 5469 | 5476.3 | +0.07% | 5366 → 5366 |
| lumos_lfq_5194 | default | 5444 / 5470 / 5466 | 5460.0 | +0.11% | 5290 → 5290 |
| lumos_lfq_5199 | default | 5494 / 5503 / 5509 | 5502.0 | -0.08% | 5362 → 5362 |
| lumos_tmt_5058 | default | 2352 / 2349 / 2286 | 2329.0 | +1.38% | 2038 → 2038 |
| lumos_tmt_5059 | default | 2352 / 2304 / 2369 | 2341.7 | +1.11% | 2011 → 2011 |
| lumos_tmt_5066 | default | 2519 / 2519 / 2540 | 2526.0 | +1.24% | 2258 → 2258 |
| tims_plasma_30min | default | 1020 / 1035 / 1036 | 1030.3 | -0.64% | 842 → 842 |
| tims_plasma_50min | default | 1047 / 1045 / 1045 | 1045.7 | +2.25% | 865 → 865 |
| velos_125_R1 | default | 2927 / 2848 / 2946 | 2907.0 | +5.15% | 2374 → 2374 |
| velos_25000_R3 | default | 2757 / 2812 / 2762 | 2777.0 | +2.66% | 2251 → 2251 |
| velos_5000_R2 | default | 2944 / 2956 / 2937 | 2945.7 | +2.35% | 2407 → 2407 |

