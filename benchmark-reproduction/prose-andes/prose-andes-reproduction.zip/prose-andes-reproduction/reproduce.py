"""Pinned benchmark reconstruction. Run --help; every search uses saved parameters."""
import argparse,collections,gzip,hashlib,json,os,shutil,subprocess,sys,urllib.request
from pathlib import Path
W=Path(__file__).resolve().parent;B=W/'broad_benchmark'
JOBS=json.loads((W/'jobs.json').read_text());VERSIONS=json.loads((W/'versions.json').read_text());INPUTS=json.loads((W/'inputs.json').read_text())
ENV=dict(os.environ,OMP_NUM_THREADS='4',OPENMS_DATA_PATH=str(W/'nightly/pyopenms/share/OpenMS'),PYTHONPATH=str(W/'nightly')+os.pathsep+str(W/'deps'))
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def call(cmd,**kw):return subprocess.run(list(map(str,cmd)),check=True,env=ENV,cwd=W,**kw)
def fetch(url,path,sha,size=None):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists():
  if digest(path)!=sha:raise ValueError(f'Existing file has wrong checksum: {path}')
  return
 temp=Path(str(path)+'.part')
 call(['curl','-fL','--retry','3','--connect-timeout','30',url,'-o',temp])
 if size is not None and temp.stat().st_size!=size:raise ValueError(f'Incomplete download: {path}')
 if digest(temp)!=sha:raise ValueError(f'Download checksum mismatch: {path}')
 temp.rename(path)
def verify_inputs(ids):
 for d in ids:
  p=B/'data'/(d+'.mzML')
  if digest(p)!=INPUTS[d]['selected_sha256']:raise ValueError(f'Selected mzML mismatch: {d}')
  m=json.load(open(B/'provenance'/(d+'.json')))
  assert m['sha256']==INPUTS[d]['selected_sha256'] and len(m['scans'])==8000
 for name,info in json.load(open(W/'databases.json')).items():
  if digest(B/'data'/(name+'_td.fasta'))!=info['sha256']:raise ValueError(f'FASTA mismatch: {name}')
 print('Verified selected inputs and all three FASTAs:',len(ids),flush=True)
def prepare(ids,keep_raw):
 (B/'data').mkdir(exist_ok=True);(B/'raw').mkdir(exist_ok=True)
 f=json.load(open(B/'provenance/fasta_integrity_correction.json'))
 fetch(f['source'],B/'data/hye_targets.fasta',f['complete_sha256'],f['complete_bytes'])
 call(['python3',B/'prepare_databases.py'])
 for d in ids:
  s=INPUTS[d]['source'];raw=B/'raw'/(d+('.mzML.gz' if s['url'].endswith('.gz') else '.mzML'))
  if not (B/'data'/(d+'.mzML')).exists():
   fetch(s['url'],raw,s['sha256'],s['bytes']);call(['python3',B/'prepare.py',d])
  verify_inputs([d])
  if not keep_raw and raw.exists():raw.unlink()
def build(key):
 cfg=VERSIONS[key]
 if key=='andes':
  source=W/'andes'
  if not source.exists():call(['git','clone','https://github.com/bigbio/andes.git',source])
  head=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
  if head!=cfg['commit']:
   if subprocess.check_output(['git','-C',source,'status','--porcelain'],text=True).strip():raise RuntimeError('ANDES checkout is dirty')
   call(['git','-C',source,'checkout','--detach',cfg['commit']])
  subprocess.run(['cargo','build','--release','--locked','--bin','andes','-j2'],cwd=source,env=ENV,check=True)
  return
 repo=W/'OpenMS';source=W/'sources'/key
 if not repo.exists():call(['git','clone','--filter=blob:none','https://github.com/OpenMS/OpenMS.git',repo])
 expected=dict(cfg)
 if cfg.get('patch'):expected['patch_sha256']=digest(W/cfg['patch'])
 stamp=W/'builds'/(key+'.source.json');stamp.parent.mkdir(exist_ok=True)
 if not source.exists():
  source.parent.mkdir(exist_ok=True);call(['git','-C',repo,'worktree','add','--detach',source,cfg['commit']])
  if cfg.get('patch'):call(['git','-C',source,'apply',W/cfg['patch']])
  stamp.write_text(json.dumps(expected,indent=2))
 else:
  if not stamp.exists() or json.load(open(stamp))!=expected:raise RuntimeError(f'Unrecognized source worktree: {source}')
 # The shared test-data fixtures are read from the selected source checkout.
 p=W/'native_cid/include/OpenMS/test_config.h'
 import re
 p.write_text(re.sub(r'"[^"]*/src/tests/class_tests/openms/data/"','"'+str(source/'src/tests/class_tests/openms/data')+'/"',p.read_text()))
 cmake=W/'deps/cmake/data/bin/cmake';dest=W/'builds'/key
 call([cmake,'-S',W/'native_cid','-B',dest,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-13','-DOPENMS='+str(source)])
 call([cmake,'--build',dest,'--target','prose','-j2'])
 (W/'bin').mkdir(exist_ok=True);shutil.copy2(dest/'prose',W/'bin'/key)
def run(job,binary,output_root):
 overridden=binary is not None
 d=job['dataset'];arm=job['arm'];verify_inputs([d]);out=output_root/job['stage']/d/arm
 if out.exists() and any(out.iterdir()):raise RuntimeError(f'Refusing to overwrite prior output: {out}; select a fresh --output-root')
 out.mkdir(parents=True,exist_ok=True)
 sys.path.insert(0,str(B));from run import command,rescore
 binary=binary or (W/'andes/target/release/andes' if job['build']=='andes' else W/'bin'/job['build'])
 if job['build']=='andes':
  cmd=list(job['original_command']);cmd[0]=str(binary)
  for i,s in enumerate(cmd[1:],1):
   if '/broad_benchmark/data/' in s:cmd[i]=str(B/'data'/Path(s).name)
  cmd[cmd.index('--output-pin')+1]=str(out/'native.pin');cmd[cmd.index('--output-tsv')+1]=str(out/'native.tsv')
 else:
  (out/'params.json').write_text(json.dumps(job['parameters'],indent=2))
  fasta=next(x for x in job['original_command'] if x.endswith('.fasta'))
  cmd=[binary,B/'data'/(d+'.mzML'),B/'data'/Path(fasta).name,out/'params.json',out/'native.tsv',out/'search.idXML']
 command(cmd,out,'search');command(['python3',W/'native_dedup/export.py',d,arm,out],out,'export')
 actual=json.load(open(out/'input_checks.json'));reference=job['expected_input_checks']
 result=dict(job=job['id'],expected_source=VERSIONS[job['build']],binary_sha256=digest(binary),binary_override=overridden,pin_sha256=actual['sha256'],expected_pin_sha256=reference['sha256'],pin_identical=actual['sha256']==reference['sha256'])
 result['seed_psms']=[rescore(out,s)['accepted'] for s in [1,42,137]];result['expected_seed_psms']=job['expected_seed_psms']
 from analyze import native
 result['native']=native(out);result['expected_native']=job['expected_native']
 expected_native=job['expected_native'];expected_native=expected_native.get('psms') if isinstance(expected_native,dict) else expected_native
 result['native_count_identical']=expected_native is None or result['native']['psms']==expected_native
 result['seed_counts_identical']=result['seed_psms']==result['expected_seed_psms']
 (out/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 if not result['pin_identical'] or not result['seed_counts_identical'] or not result['native_count_identical']:raise RuntimeError('Reproduction differs; see comparison.json. Do not replace expected values.')
def main():
 parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='action',required=True)
 for name in ['list','run']:
  p=sub.add_parser(name);p.add_argument('--stage',choices=['broad_benchmark','native_gap','native_rank','native_dedup']);p.add_argument('--dataset');p.add_argument('--arm');p.add_argument('--job')
  if name=='run':p.add_argument('--binary',type=Path);p.add_argument('--output-root',type=Path,default=W/'reruns')
 for name in ['inputs','check-inputs']:
  p=sub.add_parser(name);p.add_argument('datasets',nargs='*');
  if name=='inputs':p.add_argument('--keep-raw',action='store_true')
 p=sub.add_parser('build');p.add_argument('key',choices=list(VERSIONS))
 a=parser.parse_args()
 if a.action=='build':return build(a.key)
 if a.action in ['inputs','check-inputs']:
  ids=a.datasets or list(INPUTS)
  for d in ids:
   if d not in INPUTS:raise ValueError('Unknown dataset: '+d)
  return prepare(ids,a.keep_raw) if a.action=='inputs' else verify_inputs(ids)
 jobs=[j for j in JOBS if (not a.stage or j['stage']==a.stage) and (not a.dataset or j['dataset']==a.dataset) and (not a.arm or j['arm']==a.arm) and (not a.job or j['id']==a.job)]
 if not jobs:raise ValueError('No matching jobs')
 if a.action=='list':
  for j in jobs:print(j['id'],j['build'],j['expected_seed_psms'])
  return
 if a.binary and len({j['build'] for j in jobs})!=1:raise ValueError('--binary requires jobs from one source variant')
 for j in jobs:run(j,a.binary.resolve() if a.binary else None,a.output_root.resolve())
if __name__=='__main__':main()
