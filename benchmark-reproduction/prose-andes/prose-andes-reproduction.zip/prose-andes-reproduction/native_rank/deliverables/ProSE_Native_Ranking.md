# ProSE: native Massenfehler-Gewichtung und verbleibende Ranking-Lücke

Stand: 29. September 2026. PR [OpenMS/OpenMS#10335](https://github.com/OpenMS/OpenMS/pull/10335), veröffentlichter Commit `48dc1c22adc25ca2656448676f0ba2a663ccb6fe`, geprüfter Git-Baum `45b600076bdfc25aac867ef8022e82051ec96430`.

## Ergebnis

Eine native Massenfehler-Gewichtung verbessert auf den drei Astral-Messungen die akzeptierten PSMs nach Percolator um **10,86%** gegenüber der bereits verbesserten Originalpeak-Suche. Die native Auswertung steigt von **5.332 auf 6.571 PSMs (+23,24%)**. Der relative PSM-Rückstand zu ANDES sinkt von **26,13% auf 18,11%**; damit werden **30,70% der noch bestehenden Ausbeutelücke** geschlossen. Gegenüber dem früheren ProSE-Stand `bcbc2f1` beträgt der kumulierte Percolator-Gewinn **19,65%**; ungefähr **42,62%** der damaligen Ausbeutelücke sind geschlossen.

Die Änderung ist implementiert und als **explizite Option** veröffentlicht. Auto bleibt beim bisherigen Scorer. Auf anderen Instrumenten ist die Percolator-Wirkung klein und teils negativ, obwohl die native Auswertung häufig gewinnt. Ein separater Versuch mit lokaler Evidenz als Hauptscore wurde wegen deutlicher CID-Verluste verworfen.

## Implementierung und Bezug zu ANDES

Neue Einstellungen:

```text
scoring:method = mass_accuracy
scoring:mass_error_sd = 7.0
```

Der feste Vergleich nutzt zusätzlich `fragment:query_spectrum=raw`, wie bereits der passende Kontrollarm. `annotate:local_fragment_evidence=false`, die Standardannotation, bleibt in der Hauptmatrix unverändert. Die neue Gewichtung funktioniert auch mit verarbeiteten Kandidatenspektren; die vollständige Instrumentenmatrix untersucht jedoch die Kombination mit Raw-Retrieval.

Für einen Fragmenttreffer mit Fehler e in ppm ist das Gewicht `w = exp(-0.5 * (e / sigma)^2)`. Die Gewichtung betrifft sowohl das Intensitätsprodukt als auch die Anzahl erklärter N- und C-terminaler Fragmente. Der Score ist:

```text
log1p(sum(w * I_observed * I_theoretical))
+ max(0, lgamma(1 + sum(w_prefix)))
+ max(0, lgamma(1 + sum(w_suffix)))
```

Bei exakten Treffern ergibt sich der bisherige HyperScore. Der Clamp verhindert negative Gamma-Belohnungen bei Bruchteilen unter einem Treffer. Matchtoleranz und tatsächliche, ungewichtete Trefferzahlen bleiben unverändert. Die Breite ist unabhängig von der Matchtoleranz und wird bei der Vorläuferkalibrierung nicht neu angepasst. Das Verfahren setzt um null zentrierte Fragmentfehler voraus; systematische Fragment-Massenverschiebungen können schaden. Es ist ein Rankingmaß, kein kalibrierter PSM-p-Wert.

Der neue Scorer wird sowohl in der Vorläuferkalibrierung als auch in der finalen Suche verwendet, einschließlich Chunking und Mehrdateisuche. Methode und Breite werden in den Suchparametern gespeichert. Die C++-API `HyperScore::computeMassAccuracy` liefert zusätzlich ungewichtete Matchzahlen und den mittleren absoluten Fehler in den Matching-Einheiten; das Python-Binding gibt diese Werte als Tupel zurück.

ANDES-Quellstand: `b7eaece219ef45198eb233030cf9d69075988f72`. In `crates/search/src/match_engine.rs` berechnet ANDES das Merkmal `ppm_gaussian_score` mit sigma = 7 ppm. Diese bereits vorgegebene Breite motiviert den hier über alle Messungen festen Wert; sie wurde nicht je Messung optimiert. ANDES' native Funktion `fuse_strong_score` in `crates/scoring/src/scoring/strong_score.rs` kombiniert Intensitätssignal, lokale Zufallstreffer-Evidenz, Fragmentkonkurrenz, Kandidatenentropie und Scoreabstand. Der ppm-Gaußterm ist dort **kein direkter Summand**. Die hier verwendete gewichtete HyperScore-Formel ist eine eigene native Umsetzung; ANDES-Modelle oder deren Vorhersagen wurden nicht übernommen.

Für 47.381 gemeinsame eindeutige Kandidaten in Astral A2 sind sämtliche PIN-Spalten außer `SpecId`, `score`, `hyperscore_zscore` und `delta_score` identisch. Die Änderung betrifft also das native Ranking und davon abgeleitete Merkmale, ohne neue Percolator-Eingangsmerkmale hinzuzufügen. Durch das andere Ranking ändern sich allerdings die ausgegebenen Top-10-Kandidaten.

## Fester Vergleich auf 14 hochauflösenden Messungen

Mittelwerte akzeptierter PSMs je Messung über drei Percolator-Seeds. Die native Änderung basiert auf der Summe der separat ausgewerteten Messungen. Keine gemeinsame FDR-Schätzung über alle Dateien.

| Gruppe | Messungen | Bisher: Raw + HyperScore | Raw + Mass Accuracy | Änderung | Native Änderung | ANDES |
|---|---:|---:|---:|---:|---:|---:|
| Astral HCD | 3 | 2270.7 | 2517.2 | +10.86% | +23.24% | 3073.8 |
| HF-X HCD | 3 | 4385.1 | 4389.1 | +0.09% | +0.10% | 4703.9 |
| Lumos HCD/LFQ | 3 | 5519.0 | 5518.3 | -0.01% | +1.37% | 5616.2 |
| Exploris 480 HCD/TMTpro | 3 | 2219.4 | 2212.8 | -0.30% | +10.95% | 2502.6 |
| timsTOF HT Plasma | 2 | 1031.2 | 1046.5 | +1.49% | +3.27% | 964.0 |


| Messung | Bisher | Neu | Änderung | PSMs pro Seed (1 / 42 / 137) | Native PSMs bisher → neu |
|---|---:|---:|---:|---|---:|
| astral_A2 | 2091.0 | 2267.0 | +8.42% | 2252 / 2249 / 2300 | 1642 → 2009 |
| astral_B1 | 2406.7 | 2735.3 | +13.66% | 2701 / 2769 / 2736 | 1852 → 2301 |
| astral_B3 | 2314.3 | 2549.3 | +10.15% | 2434 / 2621 / 2593 | 1838 → 2261 |
| eclipse_tmtpro_10855 | 2360.7 | 2307.3 | -2.26% | 2277 / 2315 / 2330 | 2006 → 2228 |
| eclipse_tmtpro_10858 | 2099.0 | 2119.7 | +0.98% | 2174 / 2061 / 2124 | 1793 → 2023 |
| eclipse_tmtpro_10863 | 2198.7 | 2211.3 | +0.58% | 2208 / 2195 / 2231 | 1909 → 2082 |
| hfx_A2 | 4486.3 | 4469.0 | -0.39% | 4489 / 4469 / 4449 | 3928 → 3932 |
| hfx_B1 | 4297.7 | 4303.7 | +0.14% | 4324 / 4312 / 4275 | 3768 → 3755 |
| hfx_B3 | 4371.3 | 4394.7 | +0.53% | 4447 / 4371 / 4366 | 3940 → 3961 |
| lumos_lfq_5192 | 5515.7 | 5501.3 | -0.26% | 5489 / 5511 / 5504 | 5371 → 5400 |
| lumos_lfq_5194 | 5507.0 | 5497.3 | -0.18% | 5485 / 5501 / 5506 | 5293 → 5410 |
| lumos_lfq_5199 | 5534.3 | 5556.3 | +0.40% | 5561 / 5564 / 5544 | 5368 → 5441 |
| tims_plasma_30min | 1059.0 | 1053.7 | -0.50% | 1072 / 1036 / 1053 | 842 → 889 |
| tims_plasma_50min | 1003.3 | 1039.3 | +3.59% | 1018 / 1038 / 1062 | 903 → 913 |


Alle neun gepaarten Astral-Seedvergleiche sind positiv. Größter einzelner Percolator-Verlust der Hauptmatrix: **−2,26%** auf Exploris/TMTpro 10855, konsistent in allen drei Seeds. HF-X und Lumos LFQ ändern sich im Gruppenmittel kaum. Auf timsTOF verbessert sich vor allem die 50-Minuten-Messung. ANDES verwendet dort den bereits gemeldeten LowRes-Fallback; die tabellierte Engine-Gegenüberstellung ist deshalb nicht auf gleiche Fragmentauflösung abgestimmt. Die gepaarten ProSE-Vergleiche sind davon unabhängig.

## Weitere Versuche und verworfene Varianten

| Messung / Variante | Vergleich | PSMs | Änderung | Native PSMs |
|---|---|---:|---:|---:|
| astral_A2 / local | window_fixed | 2180.3 | +11.93% | 940 |
| astral_A2 / local_raw | raw_query | 2058.3 | -1.56% | 760 |
| astral_A2 / mass14_raw | raw_query | 2172.7 | +3.91% | 1926 |
| astral_A2 / mass7 | window_fixed | 2019.7 | +3.68% | 1826 |
| astral_A2 / mass7_evidence | raw_query_evidence | 2410.0 | +6.56% | 2009 |
| lumos_tmt_5058 / local_cid | window_fixed | 993.0 | -56.78% | 0 |
| velos_125_R1 / local_cid | window_fixed | 1713.0 | -38.04% | 0 |


`mass7` verwendet die verarbeitete Kandidatenabfrage. `mass14_raw` prüft eine doppelt so breite Gewichtung; der schwächere A2-Gewinn begründet keine Änderung der vorab gewählten 7 ppm. `mass7_evidence` aktiviert zusätzlich die schon vorhandenen lokalen Percolator-Merkmale. Dafür wird korrekt gegen **Raw plus dieselben lokalen Merkmalen** verglichen: 2.261,7 → 2.410,0, **+6,56%**. Diese Kombination ist nur explorativ auf A2 geprüft.

`local` und `local_raw` ersetzen den Hauptscore durch lokale Zufallstreffer- plus Konkurrenz-Evidenz und nutzen zum Scoring die Peaks vor der Fensterfilterung. `local_cid` verwendet zusätzlich mehrere Fragmentladungen. Dieser Prototyp ist **nicht im finalen Code**: Die native Auswertung fiel auf beiden CID-Kontrollen auf null akzeptierte PSMs bei der konservativen Schwelle; auch Percolator verlor deutlich. Der höhere A2-Percolator-Wert mit verarbeitetem Retrieval allein rechtfertigt diese Regressionen nicht. Patch, Prototyp-Binary und negative Ergebnisse bleiben im Testpaket erhalten.

## Verbleibende Lücke

Vergleich mit den 9.366 von ANDES akzeptierten Astral-Sequenzzuweisungen bei Seed 42. Modifikationen werden für diese Diagnose entfernt, I/L werden gleichgesetzt. ANDES-Zuweisungen dienen als Vergleich, **nicht als Ground Truth**.

| Kategorie | Raw + HyperScore | Raw + Mass Accuracy |
|---|---:|---:|
| Dieselbe Sequenz von ProSE akzeptiert | 6.089 | 6.717 |
| Kein ProSE-Kandidat | 23 | 23 |
| ANDES-Sequenz nicht in ProSE Top 10 | 497 | 426 |
| Vorhanden, aber unterhalb Rang 1 | 1.041 | 718 |
| Nativer Rang 1, nicht als dieselbe Sequenz akzeptiert | 1.716 | 1.482 |

Die Gewichtung verbessert damit tatsächlich die Reihenfolge und die Übereinstimmung der akzeptierten Zuordnungen. Der größte Rest liegt weiterhin bei Akzeptanz und Ranking; eine bloße Vergrößerung des Kandidatenlimits erklärt ihn nicht.

Zusätzlich sind identische Peptidkandidaten mehrfach in den Top 10 enthalten:

| Messung | Redundante Top-10-Zeilen | Betroffene Spektren | Identische erste zwei Kandidaten |
|---|---:|---:|---:|
| astral_A2 | 4092 | 2209 | 604 |
| astral_B1 | 4059 | 2237 | 582 |
| astral_B3 | 4211 | 2204 | 607 |


Identität hier: Scan, modifiziertes PIN-Peptid einschließlich Flanken, Isotopenfehler, Label, Ladung und theoretische Masse. Die Zählung verschmilzt keine Targets und Decoys. Der ProSE-Quellcode indiziert Protein-Vorkommen separat und dedupliziert im normalen Scoring nicht nach Peptidoform; die vorhandene SNES-Deduplikation betrifft einen anderen Fall. ANDES führt in `dedup_pepseq_score` explizit Peptidoform-/Score-Deduplikation mit getrennten Target-/Decoy-Gruppen durch.

Das ist eine konkrete nächste algorithmische Baustelle: redundante Kandidaten belegen Listenplätze und identische Spitzenkandidaten machen den Scoreabstand null. Der kausale Anteil an der verbleibenden Ausbeutelücke ist **noch nicht quantifiziert**. Eine saubere Korrektur muss das Kandidatenlimit vor dem Scoring, Isotopen-/Ladungshypothesen, Proteinzuordnungen, Target-/Decoy-Trennung sowie Kandidatenstatistiken über Datenbank-Chunks konsistent behandeln. Eine rein nachträgliche PIN-Deduplikation wäre dafür kein vollständiger Test.

## Daten und Auswertung

Fortsetzung des bereits archivierten Vergleichs: insgesamt 20 Messungen à 8.000 MS2 aus sechs Instrumentmodellen und sieben Erwerbsgruppen. Neue Hauptmatrix: 14 HCD-/hochauflösende Dateien; zusätzliche lokale-Score-Screens auf Velos CID und Lumos CID/TMT. Quellen: [OpenMS-Archiv](https://archive.openms.de/openms/benchmarks/pride-benchmarks/) und [PXD053748](https://www.ebi.ac.uk/pride/archive/projects/PXD053748). Die Dateien im Eclipse-Archivordner sind laut mzML-Metadaten Exploris 480.

Kontrollstand für diese Ergänzung: ProSE `46e3f6573fc70877e863bb3fa8a87af89a13ac50`. Gleiche mzML-Ausschnitte und Target-/Decoy-FASTA je Paar; Trypsin/P, zwei verpasste Spaltungen, Peptidlänge 7–40, fixes CAM(C), höchstens eine Oxidation(M), passende Label-Modifikationen, bekannte Ladungen 2–5. Vorläufertoleranz 20 ppm, bei TMTpro 50 ppm. Fragmenttoleranz 20 ppm bzw. 0,5 Da bei CID; äquivalente Isotopenhypothesen, Kalibrierung im Benchmark aus. Keine extern vorhergesagten RT-/Intensitätsmerkmale; PIN-Massen einheitlich normalisiert.

HYE verwendet die korrigierte vollständige FASTA mit 31.889 Targets, SHA256 `d9ac434d88492c10c8e9a587ee7dbc9480fa0995fa07a6ba35a7da8abf39aa25`; frühere Ergebnisse mit unvollständiger HYE-FASTA sind keine gültige Kontrolle. Datei- und Datenbankhashes stehen bei jedem Experiment.

Percolator 3.09.0, `-Y -U`, Seeds 1/42/137, nominal q≤0,01. Native Auswertung: ein Gewinner je Scan, Decoy gewinnt exakte Scoreties; vollständige Scoregruppen und `(D+1)/T ≤ 0,01`. Nominale q-Werte sind kein unabhängig gemessener wahrer FDR. Seeds messen Rescorer-Variabilität, keine biologische Replikation. A2 war explorativ; die anderen bereits bekannten Benchmarkdateien erweitern die Prüfung, sind aber keine verblindeten Testdaten. Aussagen über SCIEX/Waters, ETD und DIA sind hier weiterhin nicht belegt.

## Validierung und Grenzen des Builds

- **21 neue Suchläufe + 63 Percolator-Läufe**, davon 14 in der festen Hauptmatrix. Alle PINs vollständig gelesen und auf endliche Merkmale geprüft.
- **3/3 C++-Testprogramme bestanden:** HyperScore, ProSEAlgorithm und FragmentIndex. Neue Tests prüfen exakte/verschobene Massen, analytische Gewichte, Da-/ppm-Einheiten, ungewichtete Matchzahlen, leere/ungültige Eingaben, Scorer-Auswahl in Einzel-/Chunk-/Mehrdateisuche und Erhalt der Kernelbreite bei Kalibrierung.
- Sechs zusätzliche finale Suchläufe: gewichtetes Astral A2 exakt reproduziert; Defaults auf Velos CID, Lumos CID/TMT, HF-X, Exploris/TMTpro und timsTOF liefern **bytegleiche native Tabellen und normalisierte PINs** zum bisherigen Stand. Für identische PINs wurden keine redundanten Percolator-Läufe gestartet.
- C++23/OpenMP, GCC 13.3: ProSEAlgorithm, FragmentIndex, HyperScore und TheoreticalSpectrumGenerator aus dem geprüften Quellbaum, mit unverändertem Support aus offizieller pyOpenMS 3.6.0.dev20260928. **Kein vollständiger Clean-Build aller OpenMS-Komponenten.**
- Das geänderte gesamte Binding-Modul besteht den C++-Syntaxcheck mit nanobind 3.1.0. Der Python-Test wurde ergänzt und syntaktisch geprüft; die vollständige Python-Erweiterung wurde nicht neu gebaut, daher kein Lauf dieses Tests gegen die neue Python-API.
- Geänderte C++-Zeilen formatiert, `git diff --check` sauber. Veröffentlichter Baum exakt gleich dem getesteten Baum. Keine Zusammenführung des PR.

## Testpaket

`ProSE_Native_Ranking_Testpaket.zip` enthält sämtliche neuen komprimierten PINs, native Tabellen, Target-/Decoy-Ausgaben aller Seeds, Parameter, vollständige Befehle/Logs, Ergebniszusammenfassungen, Skripte, Prototypen und finale Binary, Patches und Commit-/Baum-/Dateihashes. Die großen unveränderten mzML-/FASTA-Eingaben sowie früheren Kontrollausgaben werden aus den bereits bereitgestellten Testdatenpaketen wiederverwendet; das neue Paket dokumentiert diese Abhängigkeiten in `REPRODUCE.md`.
