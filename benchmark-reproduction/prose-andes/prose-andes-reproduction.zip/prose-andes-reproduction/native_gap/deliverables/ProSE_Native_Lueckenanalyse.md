# ProSE: native Verbesserungen gegenüber ANDES

Veröffentlichter Commit: `46e3f6573fc70877e863bb3fa8a87af89a13ac50`.

Weiterentwicklung von PR [OpenMS/OpenMS#10335](https://github.com/OpenMS/OpenMS/pull/10335). Vergleichsbasis: ProSE `bcbc2f13052bbfb90b9441bed1e298a67b0981c7`; ANDES `b7eaece219ef45198eb233030cf9d69075988f72`.

## Ergebnis und Entscheidung

Die getrennte Kandidatensuche schließt einen nachgewiesenen Teil der Astral-Lücke. ProSE sucht dabei mit `fragment:query_spectrum=raw` auf den ursprünglichen positiven Peaks vor Deisotopierung und Filterung; die Bewertung verwendet weiterhin die verarbeiteten Spektren. Diese Trennung folgt einer im ANDES-Quellcode beobachteten Architektur, ohne dessen Scoringmodelle zu übernehmen.

Über drei Astral-Messungen steigt die Ausbeute nach Percolator um **7,93 %**, ohne Percolator um **10,23 %**. Bei gleichem nominalem Schwellenwert werden damit **17,2 % der bisherigen PSM-Ausbeutelücke** zu ANDES geschlossen; ProSE liegt weiterhin rund **26,1 %** darunter. ANDES wird nicht als Ground Truth behandelt.

Zusätzlich korrigiert ein neuer lokaler Peakfilter das Verhalten kurzer letzter m/z-Fenster: Die bisherige anteilige Peakquote kann dort sogar einen starken einzelnen Peak vollständig entfernen. `peaks:window_type=auto` nutzt bei ≤0,1 Da bzw. ≤100 ppm die volle Quote pro 100-Da-Fenster (`jump_full`), sonst weiterhin `jump`. Datenarrays und Peakreihenfolge bleiben ausgerichtet; Intensitätsgleichstände werden deterministisch behandelt. Explizites `jump` stellt die bisherige Filterung wieder her.

Die Originalpeak-Suche bleibt **optional** (`processed` ist der Default): TMTpro und eine timsTOF-Messung verlieren PSMs. Sie erfordert außerdem zusätzliche Peaklisten und mehr Sucharbeit. Pauschal gelockerte Kandidatenschwellen, ein anderer Fragmentladungsdeckel und kalibriertes High-resolution-Scoring wurden nach den gemischten bzw. schlechten Ergebnissen nicht übernommen.

## Breiter Vergleich

20 Messungen, sechs tatsächliche Instrumentmodelle, sieben Gruppen, je 8.000 MS2-Spektren. Werte sind Mittelwerte akzeptierter PSMs pro Messung und über Percolator-Seeds 1/42/137, jeweils q ≤ 0,01. Gruppensummen werden nicht als gemeinsame FDR-Auswertung interpretiert. Der reine Filtertest umfasst alle 20 Messungen; Originalpeak-Suche wurde auf allen 14 hochauflösenden Messungen geprüft.

| Gruppe | n | Bisher | Neuer Filter | + Originalpeak-Suche | Änderung Originalpeaks | ANDES |
|---|---:|---:|---:|---:|---:|---:|
| Velos CID | 3 | 2782.6 | 2782.6 | — | — | 3000.6 |
| HF-X HCD | 3 | 4328.0 | 4365.9 | 4385.1 | +1.32 % | 4703.9 |
| Astral HCD | 3 | 2103.9 | 2146.1 | 2270.7 | +7.93 % | 3073.8 |
| Lumos HCD/LFQ | 3 | 5462.9 | 5477.8 | 5519.0 | +1.03 % | 5616.2 |
| Lumos CID/TMT | 3 | 2369.4 | 2369.4 | — | — | 2468.9 |
| Exploris 480 HCD/TMTpro | 3 | 2238.4 | 2229.4 | 2219.4 | -0.85 % | 2502.6 |
| timsTOF HT Plasma | 2 | 1038.5 | 1029.8 | 1031.2 | -0.71 % | 964.0 |

Die sechs niedrigauflösenden CID-Messungen (Velos und Lumos-TMT) sind mit dem neuen Defaultfilter in allen PIN-Werten und allen drei Percolator-Ergebnissen exakt unverändert. Der Filter allein verbessert Astral um 2,01 %, HF-X um 0,88 % und Lumos-LFQ um 0,27 %; Exploris-TMTpro verliert 0,40 %, timsTOF 0,83 %. Größter einzelner Rückgang des Filtertests: timsTOF 50 min, −1,16 %.

Mit Originalpeak-Suche beträgt der größte einzelne Rückgang −3,03 % auf timsTOF 50 min (955/1.006/1.049 gegenüber 1.010/1.069/1.025 PSMs; maßgeblich sind die vollständigen Seedwerte in der folgenden Tabelle). Das rechtfertigt derzeit keinen globalen Defaultwechsel dieser Option.

## Ergebnisse pro Messung

| Messung | Bisher | Filter | Originalpeaks | Δ Originalpeaks | Native bisher → Originalpeaks |
|---|---:|---:|---:|---:|---:|
| velos_125_R1 | 2764.7 | 2764.7 | — | — | unverändert |
| velos_5000_R2 | 2878.0 | 2878.0 | — | — | unverändert |
| velos_25000_R3 | 2705.0 | 2705.0 | — | — | unverändert |
| hfx_A2 | 4435.0 | 4480.7 | 4486.3 | +1.16 % | 3870 → 3928 |
| hfx_B1 | 4233.7 | 4268.7 | 4297.7 | +1.51 % | 3688 → 3768 |
| hfx_B3 | 4315.3 | 4348.3 | 4371.3 | +1.30 % | 3859 → 3940 |
| astral_A2 | 1852.3 | 1948.0 | 2091.0 | +12.88 % | 1450 → 1642 |
| astral_B1 | 2310.7 | 2315.3 | 2406.7 | +4.15 % | 1730 → 1852 |
| astral_B3 | 2148.7 | 2175.0 | 2314.3 | +7.71 % | 1657 → 1838 |
| lumos_lfq_5192 | 5463.0 | 5472.7 | 5515.7 | +0.96 % | 5383 → 5371 |
| lumos_lfq_5194 | 5448.7 | 5454.0 | 5507.0 | +1.07 % | 5306 → 5293 |
| lumos_lfq_5199 | 5477.0 | 5506.7 | 5534.3 | +1.05 % | 5349 → 5368 |
| lumos_tmt_5058 | 2297.3 | 2297.3 | — | — | unverändert |
| lumos_tmt_5059 | 2316.0 | 2316.0 | — | — | unverändert |
| lumos_tmt_5066 | 2495.0 | 2495.0 | — | — | unverändert |
| eclipse_tmtpro_10855 | 2392.0 | 2382.0 | 2360.7 | -1.31 % | 1989 → 2006 |
| eclipse_tmtpro_10858 | 2132.7 | 2111.3 | 2099.0 | -1.58 % | 1770 → 1793 |
| eclipse_tmtpro_10863 | 2190.7 | 2195.0 | 2198.7 | +0.37 % | 1833 → 1909 |
| tims_plasma_30min | 1042.3 | 1037.0 | 1059.0 | +1.60 % | 850 → 842 |
| tims_plasma_50min | 1034.7 | 1022.7 | 1003.3 | -3.03 % | 780 → 903 |

### Seedwerte der Originalpeak-Suche

| Messung | Seeds 1 / 42 / 137 | Differenz zu bisherigen Seeds |
|---|---|---|
| hfx_A2 | 4491 / 4463 / 4505 | +77 / +14 / +63 |
| hfx_B1 | 4357 / 4277 / 4259 | +97 / +54 / +41 |
| hfx_B3 | 4453 / 4321 / 4340 | +117 / +36 / +15 |
| astral_A2 | 2068 / 2041 / 2164 | +256 / +64 / +396 |
| astral_B1 | 2454 / 2381 / 2385 | +153 / +13 / +122 |
| astral_B3 | 2313 / 2347 / 2283 | +152 / +182 / +163 |
| lumos_lfq_5192 | 5507 / 5524 / 5516 | +50 / +59 / +49 |
| lumos_lfq_5194 | 5510 / 5501 / 5510 | +62 / +51 / +62 |
| lumos_lfq_5199 | 5527 / 5528 / 5548 | +50 / +50 / +72 |
| eclipse_tmtpro_10855 | 2345 / 2353 / 2384 | -57 / -1 / -36 |
| eclipse_tmtpro_10858 | 2150 / 2061 / 2086 | +5 / -24 / -82 |
| eclipse_tmtpro_10863 | 2205 / 2170 / 2221 | +5 / -31 / +50 |
| tims_plasma_30min | 1055 / 1062 / 1060 | +25 / +10 / +15 |
| tims_plasma_50min | 955 / 1006 / 1049 | -55 / -63 / +24 |

## Wo die Astral-Lücke verbleibt

Für die 9.366 von ANDES bei Seed 42 akzeptierten Sequenzzuordnungen über alle drei Astral-Läufe (I/L vereinheitlicht, Vergleich der unmodifizierten Sequenz):

| Kategorie | Bisher | Originalpeak-Suche |
|---|---:|---:|
| Gleiche Sequenz auch von ProSE akzeptiert | 5.884 | 6.089 |
| Überhaupt kein ProSE-Kandidat | 628 | 23 |
| ANDES-Sequenz fehlt in ProSE Top 10 | 1.122 | 497 |
| Sequenz in Top 10, aber unter Rang 1 | 567 | 1.041 |
| Sequenz auf nativem Rang 1, nicht als gleiche Sequenz akzeptiert | 1.165 | 1.716 |

Damit sinken fehlende Kandidaten/Top-10-Sequenzen von 1.750 auf 520 (−70,3 %). Die verbleibende Differenz betrifft nun überwiegend Rangfolge und Akzeptanz, nicht mehr das vollständige Fehlen von Kandidaten. Die Kategorien beschreiben Unterschiede zwischen Suchmaschinen und belegen keine Richtigkeit einzelner ANDES-Zuordnungen.

## Explorative Varianten auf Astral A2

Gleiche Daten und FDR-Auswertung, keine Änderung der externen Percolator-Methode. Die A2-Messung wurde zur Auswahl von Ansätzen verwendet und ist kein unabhängiger Testsatz. Gewinne verschiedener Varianten sind nicht additiv.

| Variante | PSMs (Mittel) | Änderung | Native PSMs |
|---|---:|---:|---:|
| `calibrated_single` | 1824.7 | -1.49 % | 1262 |
| `charge_bound` | 1857.7 | +0.29 % | 1431 |
| `dense` | 2025.3 | +9.34 % | 922 |
| `dense_short` | 1977.3 | +6.75 % | 922 |
| `expanded` | 1914.3 | +3.35 % | 1450 |
| `expanded_dense` | 2059.7 | +11.19 % | 922 |
| `expanded_raw` | 1942.7 | +4.88 % | 1576 |
| `expanded_raw_dense` | 2094.3 | +13.06 % | 1100 |
| `raw_dense_short` | 2122.7 | +14.59 % | 1100 |
| `raw_query` | 2091.0 | +12.88 % | 1642 |
| `raw_query_evidence` | 2261.7 | +22.10 % | 1642 |
| `raw_query_expanded` | 2026.0 | +9.38 % | 1617 |
| `raw_query_short` | 2112.7 | +14.05 % | 1672 |
| `window_evidence` | 2216.0 | +19.63 % | 1465 |
| `window_fixed` | 1948.0 | +5.16 % | 1465 |
| `window_short` | 2046.0 | +10.46 % | 1479 |
| `window_short_evidence` | 2245.7 | +21.23 % | 1479 |

Die exakten Parameter stehen pro Experiment in `params.json` und `experiment.json`. `window_*` verwendet den neuen Filter; `raw_query*` zusätzlich Originalpeaks zur Kandidatensuche. `short` setzt min_ion_index=0; `expanded` kombiniert kurze Ionen, mindestens drei Treffer und 100 bewertete Kandidaten; `dense` erhöht die Peakquoten; `evidence` aktiviert die schon zuvor vorhandenen lokalen Evidenzmerkmale. `expanded_raw`/`raw_dense_short` bedeuten ausgeschaltete Deisotopierung und sind von der neuen, getrennten Originalpeak-Suche zu unterscheiden. `charge_bound` begrenzt experimentell die Deisotopierungsladung; diese Änderung wurde verworfen.

## Methodik, Tests und Grenzen

- Gefrorene Eingabedaten des vorherigen vollständigen Benchmarks; identische mzML-Spektren, FASTA-Datenbanken, Targets/Decoys, Modifikationen und Massentoleranzen innerhalb jedes Vergleichs. HYE-FASTA vollständig verifiziert (31.889 Targets); ältere HF-X-Ergebnisse mit einer unvollständigen FASTA sind überholt und werden hier nicht verwendet.
- Trypsin/P, zwei verpasste Spaltungen, Länge 7–40, fixes CAM(C), höchstens eine Oxidation(M), Label-Modifikationen passend zur Messung; bekannte Ladungen 2–5; Precursor 20 ppm (TMTpro 50 ppm); Fragmente 20 ppm bzw. CID 0,5 Da; ProSE-Isotopenhypothesen −2…1, ANDES −1…2 mit entgegengesetzter Vorzeichenkonvention. Mass calibration im Benchmark ausgeschaltet.
- Percolator 3.09.0, `-Y -U`, Seeds 1/42/137, vollständige Kandidatenlisten, q ≤ 0,01. Konsistente beobachtete neutrale Masse je Spektrum und berechnete Peptidmasse; keine extern vorhergesagten RT-/Intensitätsmerkmale. Native Auswertung: bester Treffer pro Spektrum, Decoy gewinnt Gleichstand; ganze Scoregruppen und `(D+1)/T ≤ 0,01`.
- 49 neue native Experimentläufe und 147 Percolator-Läufe; dazu vier abschließende native Reproduktions-/Kompatibilitätsprüfungen ohne redundantes Rescoring bei identischen PIN-Dateien.
- Gezielter C++23/OpenMP-Build von ProSEAlgorithm, FragmentIndex, HyperScore und TheoreticalSpectrumGenerator gegen unveränderten Supportcode aus pyOpenMS 3.6.0.dev20260928. HyperScore_test, ProSEAlgorithm_test und FragmentIndex_test bestehen. Dies ist kein vollständiger Clean-Build aller OpenMS-Komponenten.
- Tests decken kurze Endfenster, Einzelpeaks, Ladungs-/Isotopen-Erhalt für Retrieval, RT-/Datenarray-Ausrichtung, Rohpeak-Kandidaten trotz strenger Score-Peakfilterung, Kalibration sowie Einzeldatei- und blockweise Mehrdateisuche ab. Geänderte Zeilen mit clang-format 20.1.8 formatiert; git diff --check.
- Nominale q-Werte beweisen keine experimentell bekannte tatsächliche FDR. Seeds beschreiben Trainingsvariation auf denselben Daten und sind keine zusätzlichen biologischen Replikate. Keine validierte Aussage für SCIEX/Waters, ETD oder DIA.
- Archivpfad `Eclipse` enthält hier tatsächlich Exploris-480-Messungen laut mzML. ANDES auto verwendet bei den timsTOF-Daten den bereits berichteten CID/Low-resolution-Fallback; deshalb ist dieser primäre Enginevergleich nicht auf gleiche Fragmentauflösung abgestimmt. Der innerhalb von ProSE betrachtete Vorher-nachher-Vergleich bleibt unverändert.
- Beispielhafte A2-Laufzeiten: rund 22 s für den korrigierten Filter gegenüber 47 s für zusätzliche Originalpeak-Suche, jeweils mit vier Threads unter konkurrierender Last. Dies zeigt Mehrarbeit, ist kein kontrollierter Laufzeitbenchmark.

## Reproduktion

Das begleitende ZIP enthält Runner, Parameter, Binär-/Eingabe-Hashes, Source-Patches der verworfenen und behaltenen Ansätze, native Kandidatentabellen, normalisierte PIN-Dateien sowie sämtliche Percolator-Ausgaben. Die bestehenden Testinput- und Ergebnis-Pakete bleiben die Referenz für Baseline/ANDES. Siehe `native_gap/README.md` im Paket.
