"""Export native evidence with shared spectrum-level metadata for Percolator TDC."""
import collections,csv,hashlib,json,math,re,sys
from pathlib import Path
import pyopenms as p
R=Path(__file__).resolve().parents[1]/'broad_benchmark'
dataset,arm=sys.argv[1:3];folder=Path(sys.argv[3])
if not arm.startswith('andes'):
 proteins=[];ids=p.PeptideIdentificationList();p.IdXMLFile().load(str(folder/'search.idXML'),proteins,ids)
 sp=proteins[0].getSearchParameters();extra=sp.getMetaValue('extra_features').split(',')
 std=['SpecId','Label','ScanNr','ExpMass','CalcMass','mass','peplen']+[f'charge{i}' for i in range(2,6)]+['enzN','enzC','enzInt','dm','absdm']
 p.PercolatorInfile.store(str(folder/'native.pin'),ids,std+extra+['Peptide','Proteins'],'Trypsin/P',2,5)
 resolved={k:sp.getMetaValue(k) for k in ['scoring:method_resolved','scoring:fragment_charges_resolved','peaks:window_type_resolved','fragment:query_spectrum'] if sp.metaValueExists(k)}
else:resolved={}
meta=json.loads((R/'provenance'/(dataset+'.json')).read_text());spectra={s['scan']:s for s in meta['scans']}
with (folder/'native.pin').open() as f:
 rr=csv.reader(f,delimiter='\t');header=next(rr);rows=[]
 for raw in rr:
  d=dict(zip(header,raw));d['Proteins']=';'.join(raw[header.index('Proteins'):]);rows.append(d)
removed=[x for x in header if 'RT' in x or x.lower()=='retentiontime'];header=[x for x in header if x not in removed]
counts=collections.Counter();labels=collections.Counter()
for d in rows:
 scan=int(d['ScanNr']);s=spectra[scan];z=s['charge'];peptide=d['Peptide'].split('.',1)[1].rsplit('.',1)[0]
 if arm.startswith('andes'):peptide=re.sub(r'([+-]\d+\.\d+)',r'[\1]',peptide)
 seq=p.AASequence.fromString(peptide);calc=seq.getMonoWeight();obs=(s['precursor_mz']-1.007276466771)*z
 iso=int(float(d.get('isotope_error',0)));corrected=obs+(-1 if arm.startswith('andes') else 1)*iso*1.0033548378
 d.update(SpecId=f'{dataset}_{scan}_{counts[scan]}',ExpMass=obs,CalcMass=calc,mass=obs,peplen=seq.size(),enzInt=sum(a in 'KR' for a in seq.toUnmodifiedString()[:-1]),dm=(corrected-calc)/z,absdm=abs(corrected-calc)/z)
 counts[scan]+=1;labels[d['Label']]+=1
 assert all(math.isfinite(float(d[k])) for k in header if k not in ['SpecId','Peptide','Proteins'])
with (folder/'input.pin').open('w') as f:
 w=csv.DictWriter(f,fieldnames=header,delimiter='\t',extrasaction='ignore');w.writeheader();w.writerows(rows)
info=dict(dataset=dataset,arm=arm,candidate_rows=len(rows),spectra=len(counts),labels=dict(labels),removed=removed,resolved=resolved,sha256=hashlib.file_digest((folder/'input.pin').open('rb'),'sha256').hexdigest())
assert len(labels)==2,info
manifest_row=next(r for r in json.load(open(R/'manifest.json')) if r['id']==dataset)
info['database_sha256']=json.load(open(R/'provenance/databases.json'))[manifest_row['database']]['sha256']
info['mzml_sha256']=meta['sha256']
(folder/'input_checks.json').write_text(json.dumps(info,indent=2));print(info)
