// Diagnostic caller of the actual native implementation; not part of the PR.
#include <OpenMS/ANALYSIS/ID/ProSEAlgorithm.h>
#include <OpenMS/CHEMISTRY/TheoreticalSpectrumGenerator.h>
#include <OpenMS/FORMAT/MzMLFile.h>
#include <OpenMS/FORMAT/IdXMLFile.h>
#include <OpenMS/METADATA/PeptideIdentificationList.h>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>

struct Probe : OpenMS::ProSEAlgorithm
{
  using ProSEAlgorithm::localPeakDensities_;
  using ProSEAlgorithm::localFragmentEvidence_;
  using ProSEAlgorithm::preprocessSpectra_;
};

int main(int argc, char** argv)
{
  if (argc != 4) return 2;
  OpenMS::PeakMap raw;
  OpenMS::MzMLFile().load(argv[1], raw);
  auto filtered = raw;
  Probe::preprocessSpectra_(filtered, 0.5, false, false, 0, 20);
  std::map<std::string, const OpenMS::MSSpectrum*> filtered_by_id;
  for (const auto& s : filtered) filtered_by_id[s.getNativeID()] = &s;
  std::map<std::string, const OpenMS::MSSpectrum*> raw_by_id;
  for (auto& s : raw)
  {
    s.erase(std::remove_if(s.begin(), s.end(), [](const auto& p) {return p.getIntensity() <= 0.0;}), s.end());
    s.sortByPosition();
    raw_by_id[s.getNativeID()] = &s;
  }
  std::vector<OpenMS::ProteinIdentification> proteins;
  OpenMS::PeptideIdentificationList peptides;
  OpenMS::IdXMLFile().load(argv[2], proteins, peptides);
  OpenMS::TheoreticalSpectrumGenerator tsg;
  auto params = tsg.getParameters();
  params.setValue("add_first_prefix_ion", "true");
  params.setValue("add_metainfo", "true");
  tsg.setParameters(params);
  std::ofstream out(argv[3]);
  out << std::setprecision(17) << "scan\tpeptide\tcharge";
  for (const auto& name : {"filtered_single", "filtered_multi", "raw_single", "raw_multi"})
    out << '\t' << name << "_surprise\t" << name << "_competition";
  out << '\n';
  for (const auto& pid : peptides)
  {
    const auto& sparse = *filtered_by_id.at(pid.getSpectrumReference());
    const auto& dense = *raw_by_id.at(pid.getSpectrumReference());
    const auto sparse_density = Probe::localPeakDensities_(sparse);
    const auto dense_density = Probe::localPeakDensities_(dense);
    for (const auto& hit : pid.getHits())
    {
      OpenMS::MSSpectrum single, multi;
      tsg.getSpectrum(single, hit.getSequence(), 1, 1);
      tsg.getSpectrum(multi, hit.getSequence(), 1, std::max(1, std::min(2, hit.getCharge() - 1)));
      out << pid.getSpectrumReference() << '\t' << hit.getSequence().toUniModString() << '\t' << hit.getCharge();
      for (const auto& evidence : {
        Probe::localFragmentEvidence_(sparse, single, sparse_density, 0.5, false),
        Probe::localFragmentEvidence_(sparse, multi, sparse_density, 0.5, false),
        Probe::localFragmentEvidence_(dense, single, dense_density, 0.5, false),
        Probe::localFragmentEvidence_(dense, multi, dense_density, 0.5, false)})
      {
        out << '\t' << evidence.chance_match_surprise << '\t' << evidence.mass_competition_evidence;
      }
      out << '\n';
    }
  }
}
