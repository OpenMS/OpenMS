// IMPORTANT:
// This is test_config.h / test_config.h.in
// Please do ONLY change test_config.h.in, as test_config.h is automagically
// created by CMAKE from test_config.h.in
// 
// Use appropriate options to configure instead of changing test_config.h.
// Changes made in test_config.h will be lost as soon as you call CMAKE again.
//
// Copyright (c) 2002-present, OpenMS Inc. -- EKU Tuebingen, ETH Zurich, and FU Berlin
// SPDX-License-Identifier: BSD-3-Clause
// --------------------------------------------------------------------------
// $Maintainer: Stephan Aiche $
// $Authors: $
// --------------------------------------------------------------------------

#ifndef OPENMS_TEST_CONFIG_H
#define OPENMS_TEST_CONFIG_H

// Macro to construct a c string containing the complete path to the test data
#define OPENMS_GET_TEST_DATA_PATH(filename) (std::string("/workspace/scratch/a48adcadba6d/OpenMS/src/tests/class_tests/openms/data/") + filename).c_str()
#define OPENMS_GET_TEST_DATA_PATH_MESSAGE(prefix,filename,suffix) (prefix + std::string("/workspace/scratch/a48adcadba6d/OpenMS/src/tests/class_tests/openms/data/") + filename + suffix).c_str()

#endif // OPENMS_TEST_CONFIG_H
