"""Print the per-file PSM means used in the PR, from reruns or frozen expectations."""
import argparse,json,statistics
from pathlib import Path
W=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--expected',action='store_true');p.add_argument('--output-root',type=Path,default=W/'reruns');a=p.parse_args()
jobs=json.load(open(W/'jobs.json'));observed={}
for j in jobs:
 if a.expected:values=j['expected_seed_psms']
 else:
  f=a.output_root/j['stage']/j['dataset']/j['arm']/'comparison.json'
  if not f.exists():continue
  c=json.load(open(f));values=c['seed_psms']
  if not c['pin_identical'] or not c['seed_counts_identical']:print('MISMATCH',j['id'])
 observed[j['stage'],j['dataset'],j['arm']]=statistics.mean(values)
columns=[('broad_benchmark','prose_legacy'),('broad_benchmark','prose_auto'),('broad_benchmark','andes'),('native_gap','window_fixed'),('native_gap','raw_query'),('native_rank','mass7_raw'),('native_dedup','default'),('native_dedup','mass7_raw'),('native_dedup','mass7_evidence')]
print('group\t'+'\t'.join(s+'/'+arm for s,arm in columns))
for prefix in ['velos','hfx','astral','lumos_lfq','lumos_tmt','eclipse','tims']:
 cells=[]
 for stage,arm in columns:
  required=[j['dataset'] for j in jobs if j['stage']==stage and j['arm']==arm and j['dataset'].startswith(prefix)]
  vals=[observed[stage,d,arm] for d in required if (stage,d,arm) in observed]
  cells.append(f'{statistics.mean(vals):.4f} (n={len(vals)})' if vals and len(vals)==len(required) else 'incomplete/not run')
 print(prefix+'\t'+'\t'.join(cells))
