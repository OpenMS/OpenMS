"""Validate saved Sage output and compare with frozen ProSE/ANDES counts."""

import argparse, csv, hashlib, json, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent / "prose-andes-reproduction"
GROUPS = [
    ("velos", "Velos CID"),
    ("hfx", "HF-X HCD"),
    ("astral", "Astral HCD"),
    ("lumos_lfq", "Lumos HCD LFQ"),
    ("lumos_tmt", "Lumos CID TMT"),
    ("eclipse", "Exploris 480 TMTpro"),
    ("tims", "timsTOF HT"),
]


def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def collect(root):
    manifest = json.loads((BUNDLE / "broad_benchmark/manifest.json").read_text())
    old = json.loads((BUNDLE / "jobs.json").read_text())
    old = {j["id"]: j for j in old}
    rows = []
    for d in manifest:
        name = d["id"]
        path = root / name / "summary.json"
        if not path.exists():
            continue
        x = json.loads(path.read_text())
        checks = x["input_checks"]
        assert digest(root / name / "input.pin") == checks["sha256"]
        assert x["resolved"]["database"]["enzyme"]["restrict"] is None
        assert x["resolved"]["isotope_errors"] == [-1, 2]
        assert x["resolved"]["report_psms"] == 10 and x["resolved"]["chimera"] is False
        assert x["resolved"]["predict_rt"] is False
        assert x["resolved"]["fragment_tol"] == x["config"]["fragment_tol"]
        assert x["resolved"]["precursor_tol"] == x["config"]["precursor_tol"]
        counts = []
        for seed in [1, 42, 137]:
            p = root / name / f"s{seed}"
            res = json.loads((p / "result.json").read_text())
            assert digest(p / "target.tsv") == res["target_sha256"]
            assert digest(p / "decoy.tsv") == res["decoy_sha256"]
            with (p / "target.tsv").open() as f:
                accepted = [
                    r
                    for r in csv.DictReader(f, delimiter="\t")
                    if float(r["q-value"]) <= 0.01
                ]
            assert len(accepted) == res["accepted"]
            assert len(set(r["PSMId"].rsplit("_", 2)[-2] for r in accepted)) == len(
                accepted
            )
            counts.append(len(accepted))
        assert counts == x["seed_psms"] and statistics.mean(counts) == x["mean_psms"]
        prose = old[f"native_dedup:{name}:default"]
        andes = old[f"broad_benchmark:{name}:andes"]
        for ref in [prose, andes]:
            assert checks["mzml_sha256"] == ref["expected_input_checks"]["mzml_sha256"]
            assert (
                checks["database_sha256"]
                == ref["expected_input_checks"]["database_sha256"]
            )
        rows.append(
            {
                "dataset": name,
                "group": next(g for p, g in GROUPS if name.startswith(p)),
                "sage_seed_psms": counts,
                "sage_mean": statistics.mean(counts),
                "prose_mean": statistics.mean(prose["expected_seed_psms"]),
                "andes_mean": statistics.mean(andes["expected_seed_psms"]),
                "sage_native": x["native"]["psms"],
                "sage_builtin_q_rows": x["native"][
                    "sage_builtin_spectrum_q_target_rows"
                ],
                "sage_builtin_q_unique_scans": x["native"][
                    "sage_builtin_spectrum_q_unique_scans"
                ],
                "sage_spectra": checks["spectra"],
                "candidate_rows": checks["candidate_rows"],
                "pin_sha256": checks["sha256"],
                "search_seconds": x["search"]["seconds"],
                "search_peak_rss_kib": x["search"]["max_rss_kib"],
            }
        )
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-root", type=Path, default=ROOT / "results")
    ap.add_argument("--require-complete", action="store_true")
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    rows = collect(a.output_root)
    reference_path = ROOT / "reference/jobs.json"
    if reference_path.exists():
        reference = {x["dataset"]: x for x in json.loads(reference_path.read_text())}
        for row in rows:
            expected = reference[row["dataset"]]
            assert row["sage_seed_psms"] == expected["seed_psms"], row["dataset"]
            assert row["pin_sha256"] == expected["input_checks"]["sha256"], row[
                "dataset"
            ]
            assert row["sage_native"] == expected["native"]["psms"], row["dataset"]
        print(f"Reference checks passed for {len(rows)} files")
    if a.require_complete:
        assert len(rows) == 20, len(rows)
    groups = []
    for prefix, g in GROUPS:
        part = [r for r in rows if r["group"] == g]
        if not part:
            continue
        means = {
            k: statistics.mean(r[k] for r in part)
            for k in ["prose_mean", "andes_mean", "sage_mean"]
        }
        groups.append(
            {
                "group": g,
                "n": len(part),
                **means,
                "sage_vs_prose_pct": 100
                * (means["sage_mean"] / means["prose_mean"] - 1),
                "sage_vs_andes_pct": 100
                * (means["sage_mean"] / means["andes_mean"] - 1),
            }
        )
    print("group\tn\tProSE\tANDES\tSage\tSage_vs_ProSE_pct\tSage_vs_ANDES_pct")
    for g in groups:
        print(
            "\t".join(
                str(g[k]) if k in ["group", "n"] else f"{g[k]:.2f}"
                for k in [
                    "group",
                    "n",
                    "prose_mean",
                    "andes_mean",
                    "sage_mean",
                    "sage_vs_prose_pct",
                    "sage_vs_andes_pct",
                ]
            )
        )
    if a.write:
        (ROOT / "summary.json").write_text(
            json.dumps({"files": rows, "groups": groups}, indent=2)
        )
        for label, data in [("per_file", rows), ("per_group", groups)]:
            with (ROOT / (label + ".tsv")).open("w") as f:
                writer = csv.DictWriter(
                    f, fieldnames=list(data[0]), delimiter="\t", lineterminator="\n"
                )
                writer.writeheader()
                writer.writerows(data)


if __name__ == "__main__":
    main()
