"""Resume the two manifest-pinned PRIDE files with verified HTTP ranges."""

import concurrent.futures
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / "prose-andes-reproduction"
INPUTS = json.loads((BUNDLE / "inputs.json").read_text())
RAW = BUNDLE / "broad_benchmark/raw"
CHUNKS = ROOT / "sage-benchmark/downloads"
CHUNKS.mkdir(parents=True, exist_ok=True)


def fetch(task):
    name, url, start, end, size = task
    dest = CHUNKS / f"{name}.{start}-{end}"
    header = Path(str(dest) + ".headers")
    if not dest.exists() or dest.stat().st_size != end - start + 1:
        subprocess.run(
            [
                "curl",
                "-fsSL",
                "--retry",
                "4",
                "--connect-timeout",
                "30",
                "--max-time",
                "600",
                "-r",
                f"{start}-{end}",
                "-D",
                str(header),
                url,
                "-o",
                str(dest),
            ],
            check=True,
        )
    assert dest.stat().st_size == end - start + 1, dest
    assert re.search(
        rf"content-range:\s*bytes {start}-{end}/{size}", header.read_text(), re.I
    ), header.read_text()
    print(f"Range verified: {name} {start}-{end}", flush=True)
    return dest


for name in ["tims_plasma_30min", "tims_plasma_50min"]:
    selected = BUNDLE / "broad_benchmark/data" / f"{name}.mzML"
    if selected.exists():
        subprocess.run(
            ["python", "reproduce.py", "check-inputs", name], cwd=BUNDLE, check=True
        )
        continue
    source = INPUTS[name]["source"]
    final = RAW / f"{name}.mzML"
    if not final.exists():
        partial = Path(str(final) + ".part")
        prefix_size = partial.stat().st_size if partial.exists() else 0
        tasks = [
            (
                name,
                source["url"],
                start,
                min(start + 64 * 1024 * 1024, source["bytes"]) - 1,
                source["bytes"],
            )
            for start in range(prefix_size, source["bytes"], 64 * 1024 * 1024)
        ]
        print(
            f"Downloading {name}: retaining {prefix_size} existing bytes; {len(tasks)} ranges",
            flush=True,
        )
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            parts = list(pool.map(fetch, tasks))
        assembled = CHUNKS / f"{name}.assembled"
        with assembled.open("wb") as out:
            for part in ([partial] if prefix_size else []) + parts:
                with part.open("rb") as src:
                    shutil.copyfileobj(src, out, 1024 * 1024)
        assert assembled.stat().st_size == source["bytes"]
        with assembled.open("rb") as f:
            digest = hashlib.file_digest(f, "sha256").hexdigest()
        assert digest == source["sha256"], (name, digest)
        assembled.rename(final)
        for part in parts:
            part.unlink()
        if prefix_size:
            partial.unlink()
        print(f"Full source SHA256 verified: {name} {digest}", flush=True)
    subprocess.run(["python", "reproduce.py", "inputs", name], cwd=BUNDLE, check=True)
    print(f"Selected 8,000-spectrum input verified: {name}", flush=True)
