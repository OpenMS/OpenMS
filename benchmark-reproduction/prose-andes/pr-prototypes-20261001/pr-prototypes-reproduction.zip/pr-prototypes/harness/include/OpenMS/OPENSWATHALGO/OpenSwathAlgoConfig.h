#pragma once
#define OPENSWATHALGO_DLLAPI __attribute__((visibility("default")))
#define OPENSWATHALGO_NO_EXPORT __attribute__((visibility("hidden")))
