#pragma once
#define OPENMS_DLLAPI __attribute__((visibility("default")))
#define OPENMS_NO_EXPORT __attribute__((visibility("hidden")))
