#include <OpenMS/ANALYSIS/ID/ProSEAlgorithm.h>
#include <OpenMS/FORMAT/MzMLFile.h>
#include <OpenMS/FORMAT/IdXMLFile.h>
#include <OpenMS/METADATA/PeptideIdentificationList.h>
#include <OpenMS/DATASTRUCTURES/Param.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#include <iomanip>
int main(int argc, char** argv)
{
  if (argc != 5 && argc != 6) { std::cerr << "mzML fasta parameters.json output.tsv [output.idXML]\n"; return 2; }
  OpenMS::ProSEAlgorithm algo;
  OpenMS::Param param = algo.getParameters();
  nlohmann::json j; std::ifstream in(argv[3]); in >> j;
  for (auto it=j.begin();it!=j.end();++it)
  {
    // A key this source tree does not define would only be carried along with a warning;
    // skip it explicitly so each replay records exactly which requested settings applied.
    if(!param.exists(it.key())) { std::cerr << "[harness] ignored parameter unknown to this build: " << it.key() << "\n"; continue; }
    if(it.value().is_boolean()) param.setValue(it.key(),it.value().get<bool>() ? "true" : "false");
    else if(it.value().is_string()) param.setValue(it.key(),it.value().get<std::string>());
    else if(it.value().is_number_float()) param.setValue(it.key(),it.value().get<double>());
    else if(it.value().is_number_integer()) param.setValue(it.key(),it.value().get<int>());
    else if(it.value().is_array())
    {
      if(it.value().empty() || it.value()[0].is_string()) param.setValue(it.key(),it.value().get<std::vector<std::string>>());
      else param.setValue(it.key(),it.value().get<std::vector<int>>());
    }
  }
  algo.setParameters(param);
  std::vector<OpenMS::ProteinIdentification> proteins;
  OpenMS::PeptideIdentificationList peptides;
  auto rc=algo.search(argv[1],argv[2],proteins,peptides);
  if (rc != OpenMS::ProSEAlgorithm::ExitCodes::EXECUTION_OK) return static_cast<int>(rc);
  if (argc == 6) OpenMS::IdXMLFile().store(argv[5], proteins, peptides);
  std::ofstream out(argv[4]); out << "scan\tlabel\tscore\tpeptide\tcharge\n" << std::setprecision(17);
  for(const auto& pid:peptides) for(const auto& hit:pid.getHits())
  {
    const std::string td=hit.getMetaValue("target_decoy").toString();
    out << pid.getSpectrumReference() << '\t' << (td=="decoy" ? -1 : 1) << '\t' << hit.getScore() << '\t' << hit.getSequence().toString() << '\t' << hit.getCharge() << '\n';
  }
  return static_cast<int>(rc);
}
