#!/bin/sh
# Follow-up arm, started once the main prototype run has finished (no CPU oversubscription).
cd "$(dirname "$0")"
while [ ! -f pipeline_proto.done ]; do sleep 30; done
python3 run.py --arms m_shift_frag --workers 2 --resume >> run_proto2.log 2>&1
echo "run rc=$?" >> run_proto2.log
python3 evaluate.py > evaluate_proto.log 2>&1
echo proto2-done > pipeline_proto2.done
