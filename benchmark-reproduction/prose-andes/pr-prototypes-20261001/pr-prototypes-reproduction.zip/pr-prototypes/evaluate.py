"""Summarise the untangled-PR benchmark: per-file and per-group yields plus isolation checks.

Yield = target PSMs at Percolator q <= 0.01, mean over seeds 1/42/137 within a file, then mean
over files within an instrument group. Native = rank-one TDC count (analyze.native).
"""

import argparse
import csv
import gzip
import hashlib
import io
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent / "prose-andes-reproduction"
MANIFEST = json.loads((BUNDLE / "broad_benchmark/manifest.json").read_text())
from run import ARMS, selected  # noqa: E402

GROUPS = [("velos", "Velos CID"), ("hfx", "HF-X HCD"), ("astral", "Astral HCD"), ("lumos_lfq", "Lumos HCD LFQ"),
          ("lumos_tmt", "Lumos CID TMT"), ("eclipse_tmtpro", "Exploris 480 TMTpro"), ("tims", "timsTOF HT")]


def group_of(dataset):
    return next(name for prefix, name in GROUPS if dataset.startswith(prefix))


def pin_without(path, drop_prefix):
    """PIN text with the columns starting with drop_prefix removed (for the #10366 isolation check)."""
    rows = list(csv.reader(path.open(), delimiter="\t"))
    keep = [i for i, name in enumerate(rows[0]) if not name.startswith(drop_prefix)]
    out = io.StringIO()
    w = csv.writer(out, delimiter="\t", lineterminator="\n")
    for row in rows:
        w.writerow([row[i] for i in keep if i < len(row)] + row[len(rows[0]):])
    return hashlib.sha256(out.getvalue().encode()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--results", type=Path, default=ROOT / "results")
    ap.add_argument("--require-complete", action="store_true")
    args = ap.parse_args()
    summaries = {}
    missing = []
    for row in MANIFEST:
        for arm, (_, _, files) in ARMS.items():
            if not selected(row, files):
                continue
            path = args.results / row["id"] / arm / "summary.json"
            if path.exists():
                summaries[(row["id"], arm)] = json.loads(path.read_text())
            else:
                missing.append((row["id"], arm))
    if args.require_complete and missing:
        raise SystemExit(f"incomplete: {len(missing)} missing, e.g. {missing[:5]}")

    per_file = []
    checks = []
    for row in MANIFEST:
        d = row["id"]
        base = summaries.get((d, "base"))
        for arm in ARMS:
            s = summaries.get((d, arm))
            if not s:
                continue
            # reference arm for deltas: base, except the kernel isolation pair compares fitted with fixed kernel
            ref = summaries.get((d, "pr65s_mass_cal")) if arm == "pr65_mass_cal" else base
            r = s["resolved"]
            rec = dict(dataset=d, group=group_of(d), arm=arm, seed_1=s["seed_psms"][0], seed_42=s["seed_psms"][1],
                       seed_137=s["seed_psms"][2], mean_psms=round(s["mean_psms"], 3),
                       reference_arm="pr65s_mass_cal" if arm == "pr65_mass_cal" else "base",
                       delta_mean=round(s["mean_psms"] - ref["mean_psms"], 3) if ref else "",
                       delta_pct=round(100 * (s["mean_psms"] / ref["mean_psms"] - 1), 2) if ref else "",
                       native_psms=s["native"]["psms"], native_delta=(s["native"]["psms"] - ref["native"]["psms"]) if ref else "",
                       precursor_tolerance=r.get("precursor_mass_tolerance"), fragment_tolerance=r.get("fragment_mass_tolerance"),
                       kernel=r.get("scoring:mass_error_kernel", ""), kernel_sd=r.get("scoring:mass_error_sd_resolved", ""),
                       kernel_shift=r.get("scoring:mass_error_shift_resolved", ""),
                       ion_prior_training_psms=r.get("ion_prior:training_psms", ""),
                       ignored_parameters=",".join(s.get("ignored_parameters", [])),
                       pin_sha256=s["input_checks"]["sha256"], candidate_rows=s["input_checks"]["candidate_rows"],
                       search_seconds=round(s["search"]["seconds"], 1), max_rss_mib=round(s["search"]["max_rss_kib"] / 1024))
            per_file.append(rec)
        if base:
            if (d, "pr68") in summaries:
                checks.append(dict(dataset=d, check="pr68 PIN identical to develop",
                                   ok=summaries[(d, "pr68")]["input_checks"]["sha256"] == base["input_checks"]["sha256"]))
            if (d, "pr66_priors") in summaries:
                p66 = summaries[(d, "pr66_priors")]
                same_native = p66["native_tsv_sha256"] == base["native_tsv_sha256"]
                same_pin = pin_without(args.results / d / "pr66_priors" / "input.pin", "ion_prior_") == \
                    pin_without(args.results / d / "base" / "input.pin", "ion_prior_")
                checks.append(dict(dataset=d, check="pr66 native TSV identical to develop", ok=same_native))
                checks.append(dict(dataset=d, check="pr66 PIN identical to develop without ion_prior_* columns", ok=same_pin))
            if (d, "pr65s_mass_cal") in summaries and (d, "pr65_mass_cal") in summaries:
                a, b = summaries[(d, "pr65s_mass_cal")]["resolved"], summaries[(d, "pr65_mass_cal")]["resolved"]
                same = all(a.get(k) == b.get(k) for k in ["precursor_mass_tolerance", "fragment_mass_tolerance"])
                checks.append(dict(dataset=d, check="kernel pair: identical calibrated tolerances", ok=same))

    groups = []
    for _, gname in GROUPS:
        for arm in ARMS:
            rows = [x for x in per_file if x["group"] == gname and x["arm"] == arm]
            if not rows:
                continue
            ref_arm = "pr65s_mass_cal" if arm == "pr65_mass_cal" else "base"
            refs = [x for x in per_file if x["group"] == gname and x["arm"] == ref_arm and x["dataset"] in {r["dataset"] for r in rows}]
            mean = statistics.mean(x["mean_psms"] for x in rows)
            ref_mean = statistics.mean(x["mean_psms"] for x in refs) if len(refs) == len(rows) else None
            groups.append(dict(group=gname, arm=arm, n=len(rows), mean_psms=round(mean, 1), reference_arm=ref_arm,
                               delta_pct=round(100 * (mean / ref_mean - 1), 2) if ref_mean else "",
                               native_mean=round(statistics.mean(x["native_psms"] for x in rows), 1),
                               native_delta=round(statistics.mean(x["native_psms"] for x in rows) - statistics.mean(x["native_psms"] for x in refs), 1) if ref_mean else ""))
    for name, rows in [("per_file.tsv", per_file), ("per_group.tsv", groups), ("checks.tsv", checks)]:
        if rows:
            with (ROOT / name).open("w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter="\t")
                w.writeheader()
                w.writerows(rows)
    (ROOT / "summary.json").write_text(json.dumps(dict(missing=missing, groups=groups, checks=checks), indent=2))
    print(f"{len(summaries)} jobs, {len(missing)} missing; failed checks:", [c for c in checks if not c["ok"]])
    for g in groups:
        print(g)


if __name__ == "__main__":
    main()
