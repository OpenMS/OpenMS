"""Compare the prototype arms of the #10378 / #10379 fixes with develop and with the PR heads.

Reads results/<dataset>/<arm>/summary.json. For every arm and instrument group: mean Percolator PSMs
at q <= 0.01 (mean over seeds per file, then over the files the arm ran on), the change against develop
and against the PR head the arm modifies, both on the same files, and the native TDC change.
"""

import csv
import json
import statistics
from pathlib import Path

from evaluate import GROUPS, MANIFEST, group_of
from run import ARMS, selected

ROOT = Path(__file__).resolve().parent
# arm: PR-head reference arm
REFERENCE = {
    "c_default": "pr65_default", "h_prec": "pr65_default", "h_frag": "pr65_default", "h_prec_robust": "pr65_default",
    "h_prec_robust_stride": "pr65_default",
    "m_full_noapply": "pr65_mass_cal", "m_shift_noapply": "pr65_mass_cal", "m_shift_prec_robust_stride": "pr65_mass_cal", "m_shift_frag": "pr65_mass_cal",
    "p_default": "pr66_priors", "p_zauto": "pr66_priors", "p_residue": "pr66_priors", "p_zauto_residue": "pr66_priors",
}
EXTRA_REFERENCES = {"m_full_noapply": "pr65s_mass", "m_shift_noapply": "pr65s_mass", "m_shift_prec_robust_stride": "pr65s_mass", "m_shift_frag": "pr65s_mass"}


def load(dataset, arm):
    path = ROOT / "results" / dataset / arm / "summary.json"
    return json.loads(path.read_text()) if path.exists() else None


def pct(a, b):
    return round(100 * (a / b - 1), 2)


def main():
    rows, files = [], []
    for arm, ref in REFERENCE.items():
        for _, gname in GROUPS:
            ds = [r["id"] for r in MANIFEST if group_of(r["id"]) == gname and selected(r, ARMS[arm][2])]
            got = {d: load(d, arm) for d in ds}
            ds = [d for d in ds if got[d]]
            if not ds:
                continue
            base = {d: load(d, "base") for d in ds}
            refs = {d: load(d, ref) for d in ds}
            extra = EXTRA_REFERENCES.get(arm)
            extras = {d: load(d, extra) for d in ds} if extra else {}
            mean = statistics.mean(got[d]["mean_psms"] for d in ds)
            mbase = statistics.mean(base[d]["mean_psms"] for d in ds)
            mref = statistics.mean(refs[d]["mean_psms"] for d in ds)
            rec = dict(arm=arm, group=gname, n=len(ds), mean_psms=round(mean, 1), develop=round(mbase, 1),
                       vs_develop_pct=pct(mean, mbase), pr_head=ref, pr_head_psms=round(mref, 1), vs_pr_head_pct=pct(mean, mref),
                       native_vs_develop=round(statistics.mean(got[d]["native"]["psms"] - base[d]["native"]["psms"] for d in ds), 1),
                       native_vs_pr_head=round(statistics.mean(got[d]["native"]["psms"] - refs[d]["native"]["psms"] for d in ds), 1))
            if extra:
                mex = statistics.mean(extras[d]["mean_psms"] for d in ds)
                rec.update(extra_reference=extra, vs_extra_pct=pct(mean, mex))
            rows.append(rec)
            for d in ds:
                r = got[d]["resolved"]
                files.append(dict(arm=arm, dataset=d, seeds=got[d]["seed_psms"], mean_psms=round(got[d]["mean_psms"], 1),
                                  vs_develop_pct=pct(got[d]["mean_psms"], base[d]["mean_psms"]),
                                  vs_pr_head_pct=pct(got[d]["mean_psms"], refs[d]["mean_psms"]),
                                  native=got[d]["native"]["psms"],
                                  precursor_tolerance=r.get("precursor_mass_tolerance"), fragment_tolerance=r.get("fragment_mass_tolerance"),
                                  kernel_sd=r.get("scoring:mass_error_sd_resolved", ""), kernel_shift=r.get("scoring:mass_error_shift_resolved", ""),
                                  ignored=",".join(got[d].get("ignored_parameters", []))))
    for name, data in [("proto_per_group.tsv", rows), ("proto_per_file.tsv", files)]:
        with (ROOT / name).open("w", newline="") as f:
            keys = list(dict.fromkeys(k for r in data for k in r))
            w = csv.DictWriter(f, fieldnames=keys, delimiter="\t")
            w.writeheader()
            w.writerows(data)
    for r in rows:
        print("\t".join(str(r.get(k, "")) for k in ["arm", "group", "n", "mean_psms", "vs_develop_pct", "vs_pr_head_pct", "vs_extra_pct", "native_vs_develop", "native_vs_pr_head"]))


if __name__ == "__main__":
    main()
