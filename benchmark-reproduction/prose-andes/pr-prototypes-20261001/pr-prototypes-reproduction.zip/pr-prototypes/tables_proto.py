"""Markdown tables of the prototype arms: group means, % vs develop (and vs a reference arm), native TDC deltas."""
import json
import statistics
from evaluate import GROUPS, MANIFEST, group_of
from run import ARMS, selected


def load(d, a):
    try:
        return json.load(open(f"results/{d}/{a}/summary.json"))
    except FileNotFoundError:
        return None


def cell(arm, gname, ref="base", native=False):
    ds = [r["id"] for r in MANIFEST if group_of(r["id"]) == gname and selected(r, ARMS[arm][2]) and load(r["id"], arm)]
    if not ds:
        return "–"
    m = statistics.mean(load(d, arm)["mean_psms"] for d in ds)
    b = statistics.mean(load(d, "base")["mean_psms"] for d in ds)
    txt = f"{100 * (m / b - 1):+.2f}%"
    if ref != "base":
        rm = statistics.mean(load(d, ref)["mean_psms"] for d in ds)
        txt += f" ({100 * (m / rm - 1):+.2f})"
    if native:
        nd = statistics.mean(load(d, arm)["native"]["psms"] - load(d, "base")["native"]["psms"] for d in ds)
        txt += f" / {nd:+.0f}"
    return txt


def table(title, groups, rows, ref="base", native=True):
    out = [f"**{title}**", "", "| Arm | " + " | ".join(groups) + " |", "| --- |" + " --- |" * len(groups)]
    for label, arm in rows:
        out.append(f"| {label} | " + " | ".join(cell(arm, g, ref, native) for g in groups) + " |")
    return "\n".join(out) + "\n"


hi = [g for _, g in GROUPS if g not in ("Velos CID", "Lumos CID TMT")]
alln = [g for _, g in GROUPS]
base_row = "| develop (PSMs) | " + " | ".join(f"{statistics.mean(load(r['id'], 'base')['mean_psms'] for r in MANIFEST if group_of(r['id']) == g):.1f}" for g in hi) + " |"
print(table("A. #10379 windows, HyperScore. % vs develop / native TDC delta vs develop", hi, [
    ("#10379 head: `auto` = precursor + fragment windows", "c_default"),
    ("precursor window only", "h_prec"),
    ("fragment window only", "h_frag"),
    ("robust precursor window only (ANDES-style)", "h_prec_robust"),
    ("robust precursor window, stride sample", "h_prec_robust_stride"),
]))
print(base_row.replace("| develop", "| (develop PSMs") .replace(" (PSMs) |", ") |"))
print()
print(table("B. Mass-accuracy scorer. % vs develop (vs scorer with fixed 7 ppm kernel, no calibration) / native TDC delta vs develop", hi, [
    ("scorer, fixed 7 ppm kernel, no calibration", "pr65s_mass"),
    ("#10379 head: fitted kernel + both windows", "pr65_mass_cal"),
    ("fitted kernel (center + width), windows unchanged", "m_full_noapply"),
    ("fitted center only, windows unchanged", "m_shift_noapply"),
    ("fitted center only + fragment window", "m_shift_frag"),
    ("fitted center only + robust precursor window, stride", "m_shift_prec_robust_stride"),
], ref="pr65s_mass"))
print(table("C. #10378 ion priors. % vs develop (vs #10378 head)", alln, [
    ("#10378 head (fragment charge 1)", "pr66_priors"),
    ("fragment charges `auto`", "p_zauto"),
    ("cleavage-residue context", "p_residue"),
    ("both", "p_zauto_residue"),
], ref="pr66_priors", native=False))
