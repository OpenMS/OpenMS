#!/bin/sh
cd "$(dirname "$0")"
python3 run.py --arms m_shift_frag --workers 2 --resume >> run_proto2.log 2>&1
echo "run rc=$?" >> run_proto2.log
python3 evaluate.py > evaluate_proto.log 2>&1
echo proto2-done > pipeline_proto2.done
