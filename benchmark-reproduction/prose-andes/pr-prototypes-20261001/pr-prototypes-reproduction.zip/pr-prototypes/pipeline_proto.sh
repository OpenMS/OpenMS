#!/bin/sh
# Prototype arms for the #10378 / #10379 fixes, detached from the session's task timeouts.
cd "$(dirname "$0")"
python3 run.py --arms c_default h_prec h_frag h_prec_robust h_prec_robust_stride m_full_noapply m_shift_noapply \
  m_shift_prec_robust_stride p_default p_zauto p_residue p_zauto_residue --workers 2 --resume >> run_proto.log 2>&1
echo "run rc=$?" >> run_proto.log
python3 evaluate.py > evaluate_proto.log 2>&1
echo proto-done > pipeline_proto.done
