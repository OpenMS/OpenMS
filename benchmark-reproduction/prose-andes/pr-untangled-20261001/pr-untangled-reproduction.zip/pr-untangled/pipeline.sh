#!/bin/sh
# Remaining benchmark pipeline, detached from the session's task timeouts.
cd "$(dirname "$0")"
python3 run.py velos_125_R1 velos_5000_R2 velos_25000_R3 hfx_A2 hfx_B1 hfx_B3 astral_A2 astral_B1 astral_B3 lumos_lfq_5192 lumos_lfq_5194 lumos_lfq_5199 lumos_tmt_5058 lumos_tmt_5059 lumos_tmt_5066 eclipse_tmtpro_10855 eclipse_tmtpro_10858 eclipse_tmtpro_10863 --workers 2 --resume >> run_main.log 2>&1
while pgrep -x -f "python3 reproduce.py inputs" >/dev/null; do sleep 30; done
python3 run.py tims_plasma_30min tims_plasma_50min --workers 2 --resume > run_tims.log 2>&1
PYTHONPATH=../prose-andes-reproduction/nightly:../prose-andes-reproduction/deps OPENMS_DATA_PATH=../prose-andes-reproduction/nightly/pyopenms/share/OpenMS python3 intensity_control.py run > intensity_run.log 2>&1
python3 intensity_control.py evaluate > intensity_eval.log 2>&1
python3 evaluate.py > evaluate.log 2>&1
echo pipeline-done > pipeline.done
