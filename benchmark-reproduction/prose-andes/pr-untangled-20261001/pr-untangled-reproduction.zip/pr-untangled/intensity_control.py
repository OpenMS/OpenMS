"""Exercise the standalone #10368 port with scale-equivalent real CID and TMTpro spectra (derived as in the 2026-09-30 ablation)."""

import argparse
import base64
import gzip
import json
import shutil
import statistics
import sys
import zlib
from pathlib import Path

from run import BUNDLE, DATA, ENV, INPUTS, MANIFEST, ROOT, command, native, rescore, sha

DATASETS = ["velos_125_R1", "eclipse_tmtpro_10855"]
CONTROL = ROOT / "intensity-control"


def prepare():
    sys.path[:0] = [str(BUNDLE / "nightly"), str(BUNDLE / "deps")]
    import numpy as np
    import pyopenms as p
    from lxml import etree

    CONTROL.mkdir(exist_ok=True)
    for dataset in DATASETS:
        source = DATA / (dataset + ".mzML")
        assert sha(source) == INPUTS[dataset]["selected_sha256"]
        dest = CONTROL / (dataset + ".mzML")
        record_path = CONTROL / (dataset + ".json")
        if record_path.exists():
            record = json.loads(record_path.read_text())
            assert sha(dest) == record["derived_sha256"]
            continue
        original = p.MSExperiment()
        p.MzMLFile().load(str(source), original)
        # Edit only intensity binary arrays. A load/store mzML round trip can
        # round decimal RT metadata, which would introduce an unnecessary change.
        tree = etree.parse(str(source))
        ns = {"m": "http://psi.hupo.org/ms/mzml"}
        xml_spectra = tree.xpath("//m:spectrum", namespaces=ns)
        assert len(xml_spectra) == len(original)
        exponents, peaks, above_cutoff = [], 0, 0
        for i in range(len(original)):
            spec = original[i]
            mz, intensity = spec.get_peaks()
            assert np.isfinite(intensity).all() and (intensity >= 0).all()
            maximum = float(intensity.max()) if len(intensity) else 0.0
            exponent = 1 - int(np.frexp(maximum)[1]) if maximum else 0
            scaled = np.ldexp(intensity, exponent)
            assert np.isfinite(scaled).all()
            if maximum:
                assert 1 <= float(scaled.max()) < 2
                assert np.array_equal(np.ldexp(scaled, -exponent), intensity)
            arrays = xml_spectra[i].xpath(
                "m:binaryDataArrayList/m:binaryDataArray[m:cvParam[@accession='MS:1000515']]",
                namespaces=ns,
            )
            assert len(arrays) == 1
            array = arrays[0]
            accessions = {c.get("accession") for c in array.findall("m:cvParam", ns)}
            assert "MS:1000574" in accessions
            dtype = "<f4" if "MS:1000521" in accessions else "<f8"
            assert "MS:1000521" in accessions or "MS:1000523" in accessions
            binary = array.find("m:binary", ns)
            stored = np.frombuffer(
                zlib.decompress(base64.b64decode(binary.text)), dtype=dtype
            )
            assert np.array_equal(stored.astype(np.float32), intensity)
            encoded = base64.b64encode(
                zlib.compress(np.ldexp(stored, exponent).tobytes())
            ).decode()
            binary.text = encoded
            array.set("encodedLength", str(len(encoded)))
            exponents.append(exponent)
            peaks += len(scaled)
            above_cutoff += int((scaled >= 0.05).sum())
        tree.write(str(dest), encoding="UTF-8", xml_declaration=True)
        del tree, xml_spectra
        check = p.MSExperiment()
        p.MzMLFile().load(str(dest), check)
        assert len(check) == len(original) == 8000
        for i in range(len(check)):
            a, b = original[i], check[i]
            assert a.getNativeID() == b.getNativeID() and a.getRT() == b.getRT()
            assert a.getMSLevel() == b.getMSLevel()
            assert a.getPrecursors() == b.getPrecursors()
            amz, ai = a.get_peaks()
            bmz, bi = b.get_peaks()
            assert np.array_equal(amz, bmz)
            assert np.array_equal(np.ldexp(ai, exponents[i]), bi)
        record = dict(
            dataset=dataset,
            source_sha256=sha(source),
            derived_sha256=sha(dest),
            transformation="Per-spectrum ldexp(I, 1-frexp(max(float32(I))).exponent); preserve stored precision; max in [1,2)",
            exponents=exponents,
            spectra=len(original),
            peaks=peaks,
            peaks_at_or_above_absolute_005=above_cutoff,
            unchanged_mz_rt_precursors_native_ids=True,
            exact_float32_reversibility=True,
        )
        record_path.write_text(json.dumps(record, indent=2))
        print(dataset, record["derived_sha256"], peaks, above_cutoff, flush=True)


def run():
    for dataset in DATASETS:
        derived = CONTROL / (dataset + ".mzML")
        provenance = json.loads((CONTROL / (dataset + ".json")).read_text())
        assert sha(derived) == provenance["derived_sha256"]
        for arm, build in [("base", "base"), ("pr68", "pr10368")]:
            out = CONTROL / "results" / dataset / arm
            if (out / "summary.json").exists():
                continue
            assert not out.exists(), "Refusing to overwrite partial control"
            out.mkdir(parents=True)
            raw = json.loads(
                (ROOT / "results" / dataset / arm / "summary.json").read_text()
            )
            assert (
                sha(ROOT / "builds" / build / "prose") == raw["build"]["binary_sha256"]
            )
            row = next(r for r in MANIFEST if r["id"] == dataset)
            db = DATA / (row["database"] + "_td.fasta")
            assert sha(db) == raw["input_checks"]["database_sha256"]
            (out / "params.json").write_text(json.dumps(raw["parameters"], indent=2))
            search = command(
                [
                    ROOT / "builds" / build / "prose",
                    derived,
                    db,
                    out / "params.json",
                    out / "native.tsv",
                    out / "search.idXML",
                ],
                out,
                "search",
            )
            command(
                ["python3", ROOT / "export.py", dataset, arm, out, derived],
                out,
                "export",
            )
            checks = json.loads((out / "input_checks.json").read_text())
            assert checks["mzml_sha256"] == provenance["derived_sha256"]
            assert checks["source_mzml_sha256"] == provenance["source_sha256"]
            seeds = [rescore(out, seed, checks) for seed in [1, 42, 137]]
            summary = dict(
                dataset=dataset,
                arm=arm,
                build=raw["build"],
                parameters=raw["parameters"],
                resolved=json.loads((out / "resolved.json").read_text()),
                input_checks=checks,
                seed_results=seeds,
                seed_psms=[s["accepted"] for s in seeds],
                mean_psms=statistics.mean(s["accepted"] for s in seeds),
                native=native(out),
                search=search,
                native_tsv_sha256=sha(out / "native.tsv"),
                native_pin_sha256=sha(out / "native.pin"),
                identical_to_unscaled_pin=checks["sha256"]
                == raw["input_checks"]["sha256"],
                identical_to_unscaled_seed_counts=[s["accepted"] for s in seeds]
                == raw["seed_psms"],
            )
            for name in ["search.idXML", "native.pin", "native.tsv"]:
                with (out / name).open("rb") as src, gzip.open(
                    out / (name + ".gz"), "wb", compresslevel=1
                ) as dst:
                    shutil.copyfileobj(src, dst)
                (out / name).unlink()
            (out / "summary.json").write_text(json.dumps(summary, indent=2))
            print(
                dataset,
                arm,
                summary["seed_psms"],
                "identical PIN",
                summary["identical_to_unscaled_pin"],
                flush=True,
            )


def evaluate():
    results = []
    for dataset in DATASETS:
        provenance = json.loads((CONTROL / (dataset + ".json")).read_text())
        reference = json.loads((ROOT.parent / "pr-ablation-20260930/pr-ablation/reference/intensity-control" / (dataset + ".json")).read_text())
        for arm in ["base", "pr68"]:
            x = json.loads((CONTROL / "results" / dataset / arm / "summary.json").read_text())
            raw = json.loads((ROOT / "results" / dataset / arm / "summary.json").read_text())
            results.append(dict(dataset=dataset, arm=arm, seed_psms=x["seed_psms"], mean_psms=x["mean_psms"], native=x["native"],
                                unscaled_seed_psms=raw["seed_psms"], identical_to_unscaled_pin=x["identical_to_unscaled_pin"],
                                derived_input_identical_to_2026_09_30=provenance["derived_sha256"] == reference["derived_sha256"]))
    (CONTROL / "summary.json").write_text(json.dumps(results, indent=2))
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("action", choices=["prepare", "run", "evaluate"])
    args = ap.parse_args()
    {"prepare": prepare, "run": run, "evaluate": evaluate}[args.action]()
