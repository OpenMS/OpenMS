"""Replace the SearchParameters block of ProSE TOPP references by the replayed one of a build.

Only valid where the base replay reproduces the reference exactly (checked here) and the
build's replay changes nothing but search-parameter UserParams (checked here too).
usage: update_refs.py <build> <openms checkout to edit> [<build the references currently match>, default base]
"""
import re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
build, checkout = sys.argv[1], Path(sys.argv[2])
from_build = sys.argv[3] if len(sys.argv) > 3 else "base"
block = re.compile(r'\t<SearchParameters .*?</SearchParameters>\n', re.S)
strip = lambda s: re.sub(r' db="[^"]*"', '', s)
for test in ["ProSE_1", "ProSE_2", "ProSE_4", "ProSE_10"]:
    ref_path = checkout / "src/tests/topp" / f"{test}_out.idXML"
    ref = ref_path.read_text()
    base = (ROOT / "topp-emulation" / from_build / test / "out.idXML").read_text()
    new = (ROOT / "topp-emulation" / build / test / "out.idXML").read_text()
    rb, bb, nb = block.search(ref), block.search(base), block.search(new)
    assert strip(rb.group(0)) == strip(bb.group(0)), test + ": base replay does not reproduce the reference"
    # everything outside the SearchParameters block must be unchanged by the build
    rest = lambda s, m: re.sub(r'date="[^"]*"', '', strip(s[:m.start()] + s[m.end():]))
    assert rest(base, bb) == rest(new, nb), test + ": build changes more than the search parameters"
    db = re.search(r' db="[^"]*"', rb.group(0)).group(0)
    replacement = re.sub(r' db="[^"]*"', db, nb.group(0), count=1)
    ref_path.write_text(ref[:rb.start()] + replacement + ref[rb.end():])
    print(test, "updated")
