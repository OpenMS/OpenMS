"""Paired, isolated PR benchmarks using the frozen 20-file input contract."""

import argparse
import concurrent.futures
import csv
import gzip
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent / "prose-andes-reproduction"
DATA = BUNDLE / "broad_benchmark/data"
sys.path.insert(0, str(BUNDLE / "broad_benchmark"))
from analyze import native

ENV = dict(
    os.environ,
    OMP_NUM_THREADS="4",
    OPENMS_DATA_PATH=str(BUNDLE / "nightly/pyopenms/share/OpenMS"),
    PYTHONPATH=str(BUNDLE / "nightly") + os.pathsep + str(BUNDLE / "deps"),
)
MANIFEST = json.loads((BUNDLE / "broad_benchmark/manifest.json").read_text())
INPUTS = json.loads((BUNDLE / "inputs.json").read_text())
DATABASES = json.loads((BUNDLE / "databases.json").read_text())
HISTORICAL = {j["id"]: j for j in json.loads((BUNDLE / "jobs.json").read_text())}
ARMS = {
    "base": ("base", {}),
    "pr65_auto": ("pr10365", {"calibration:enabled": "auto"}),
    "pr66_priors": ("pr10366", {"annotate:self_trained_ion_priors": "true"}),
    "pr68_cutoff": ("pr10368", {}),
    "pr68_current": ("pr10368_current", {}),
    "base_mass_cal": (
        "base",
        {"calibration:enabled": "true", "scoring:method": "mass_accuracy"},
    ),
    "pr65_mass_cal": (
        "pr10365",
        {"calibration:enabled": "true", "scoring:method": "mass_accuracy"},
    ),
}


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def command(cmd, out, name):
    started = time.monotonic()
    cmd = list(map(str, cmd))
    log_part = out / f"{name}.log.part"
    with log_part.open("w") as log:
        proc = subprocess.Popen(cmd, env=ENV, stdout=log, stderr=log, cwd=ROOT)
        _, status, usage = os.wait4(proc.pid, 0)
        proc.returncode = os.waitstatus_to_exitcode(status)
    log_part.replace(out / f"{name}.log")
    rec = dict(
        command=cmd,
        returncode=proc.returncode,
        seconds=time.monotonic() - started,
        max_rss_kib=usage.ru_maxrss,
        user_seconds=usage.ru_utime,
        system_seconds=usage.ru_stime,
    )
    (out / f"{name}.command.json").write_text(json.dumps(rec, indent=2))
    if proc.returncode:
        raise RuntimeError(
            f"{out}: {name} failed ({proc.returncode}): "
            + (out / f"{name}.log").read_text()[-2500:]
        )
    return rec


def rescore(out, seed, check):
    assert sha(out / "input.pin") == check["sha256"]
    folder = out / f"s{seed}"
    folder.mkdir()
    rec = command(
        [
            BUNDLE / "percolator/usr/bin/percolator",
            "-Y",
            "-U",
            "--seed",
            seed,
            "--results-psms",
            folder / "target.tsv",
            "--decoy-results-psms",
            folder / "decoy.tsv",
            out / "input.pin",
        ],
        folder,
        "percolator",
    )
    assert (
        f"Found {check['candidate_rows']} PSMs"
        in (folder / "percolator.log").read_text()
    )
    assert sha(out / "input.pin") == check["sha256"]
    with (folder / "target.tsv").open() as f:
        rows = [
            r for r in csv.DictReader(f, delimiter="\t") if float(r["q-value"]) <= 0.01
        ]
    assert len({r["PSMId"].rsplit("_", 2)[-2] for r in rows}) == len(rows)
    result = dict(
        seed=seed,
        accepted=len(rows),
        target_sha256=sha(folder / "target.tsv"),
        decoy_sha256=sha(folder / "decoy.tsv"),
        command=rec,
    )
    (folder / "result.json").write_text(json.dumps(result, indent=2))
    return result


def run(row, arm, output_root, resume):
    dataset = row["id"]
    out = output_root / dataset / arm
    if resume and (out / "summary.json").exists():
        saved = json.loads((out / "summary.json").read_text())
        assert sha(out / "input.pin") == saved["input_checks"]["sha256"]
        return saved
    if out.exists() and any(out.iterdir()):
        raise RuntimeError("Refusing to overwrite incomplete output: " + str(out))
    out.mkdir(parents=True, exist_ok=True)
    build, delta = ARMS[arm]
    build_record = json.loads((ROOT / "build_records.json").read_text())[build]
    binary = ROOT / "builds" / build / "prose"
    assert sha(binary) == build_record["binary_sha256"] and build_record["tests_passed"]
    assert sha(DATA / f"{dataset}.mzML") == INPUTS[dataset]["selected_sha256"]
    assert (
        sha(DATA / f"{row['database']}_td.fasta")
        == DATABASES[row["database"]]["sha256"]
    )
    previous = HISTORICAL[f"native_dedup:{dataset}:default"]
    params = dict(previous["parameters"])
    params.update(delta)
    (out / "params.json").write_text(json.dumps(params, indent=2))
    search = command(
        [
            binary,
            DATA / f"{dataset}.mzML",
            DATA / f"{row['database']}_td.fasta",
            out / "params.json",
            out / "native.tsv",
            out / "search.idXML",
        ],
        out,
        "search",
    )
    command(["python", ROOT / "export.py", dataset, arm, out], out, "export")
    check = json.loads((out / "input_checks.json").read_text())
    assert check["mzml_sha256"] == INPUTS[dataset]["selected_sha256"]
    assert check["database_sha256"] == DATABASES[row["database"]]["sha256"]
    seeds = [rescore(out, seed, check) for seed in [1, 42, 137]]
    result = dict(
        dataset=dataset,
        arm=arm,
        build=build_record,
        parameters=params,
        resolved=json.loads((out / "resolved.json").read_text()),
        input_checks=check,
        seed_results=seeds,
        seed_psms=[s["accepted"] for s in seeds],
        mean_psms=statistics.mean(s["accepted"] for s in seeds),
        native=native(out),
        search=search,
        native_tsv_sha256=sha(out / "native.tsv"),
        native_pin_sha256=sha(out / "native.pin"),
        historical_pin_identical=check["sha256"]
        == previous["expected_input_checks"]["sha256"],
        historical_seed_counts_identical=[s["accepted"] for s in seeds]
        == previous["expected_seed_psms"],
    )
    for filename in ["search.idXML", "native.pin", "native.tsv"]:
        source = out / filename
        with source.open("rb") as src, gzip.open(
            str(source) + ".gz.part", "wb", compresslevel=1
        ) as dst:
            shutil.copyfileobj(src, dst)
        Path(str(source) + ".gz.part").replace(Path(str(source) + ".gz"))
        source.unlink()
    (out / "summary.json.part").write_text(json.dumps(result, indent=2))
    (out / "summary.json.part").replace(out / "summary.json")
    print(
        json.dumps(
            dict(
                dataset=dataset,
                arm=arm,
                seed_psms=result["seed_psms"],
                native=result["native"],
                seconds=search["seconds"],
                rss_mib=search["max_rss_kib"] / 1024,
            )
        ),
        flush=True,
    )
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("datasets", nargs="*")
    ap.add_argument("--arms", nargs="+", choices=list(ARMS), default=list(ARMS))
    ap.add_argument("--output-root", type=Path, default=ROOT / "results")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--wait-for-builds", action="store_true")
    args = ap.parse_args()
    while args.wait_for_builds:
        try:
            records = json.loads((ROOT / "build_records.json").read_text())
            if all(ARMS[arm][0] in records for arm in args.arms):
                break
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        time.sleep(5)
    assert (
        sha(BUNDLE / "percolator/usr/bin/percolator")
        == "1f067b5d438a3a88be8a88f636844baea824e239fd2c5c053462ae56fd0e7c15"
    )
    order = [
        "eclipse_tmtpro_10855",
        "hfx_A2",
        "velos_125_R1",
        "astral_A2",
        "lumos_lfq_5192",
        "lumos_tmt_5058",
        "tims_plasma_30min",
    ]
    rows = sorted(
        MANIFEST,
        key=lambda r: (
            order.index(r["id"]) if r["id"] in order else 100 + MANIFEST.index(r)
        ),
    )
    jobs = [
        (r, arm)
        for r in rows
        for arm in args.arms
        if (not args.datasets or r["id"] in args.datasets)
        and ("mass_cal" not in arm or r["fragment_unit"] == "ppm")
    ]
    print("Planned searches:", len(jobs), flush=True)
    # Measured peaks of completed jobs are <= 2.92 GiB. Reserve headroom per
    # database and 1.2 GiB beyond the combined budget in the 8-GiB environment.
    memory_gib = {"human": 2.3, "hy": 3.1, "hye": 3.3}
    pending = list(jobs)
    active = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        while pending or active:
            used = sum(weight for weight in active.values())
            while len(active) < 2:
                idx = next(
                    (
                        i
                        for i, (r, _) in enumerate(pending)
                        if used + memory_gib[r["database"]] <= 6.8
                    ),
                    None,
                )
                if idx is None:
                    break
                r, arm = pending.pop(idx)
                weight = memory_gib[r["database"]]
                active[
                    pool.submit(run, r, arm, args.output_root.resolve(), args.resume)
                ] = weight
                used += weight
            done, _ = concurrent.futures.wait(
                active, return_when=concurrent.futures.FIRST_COMPLETED
            )
            for future in done:
                future.result()
                del active[future]
