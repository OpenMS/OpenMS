"""Build and test each isolated PR on the same pinned native-cid base."""

import hashlib
import argparse
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent / "prose-andes-reproduction"
ENV = dict(
    os.environ,
    OMP_NUM_THREADS="2",
    OPENMS_DATA_PATH=str(BUNDLE / "nightly/pyopenms/share/OpenMS"),
)
CMAKE = BUNDLE / "deps/cmake/data/bin/cmake"
CTEST = BUNDLE / "deps/cmake/data/bin/ctest"

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument(
    "arms",
    nargs="*",
    default=["base", "pr10365", "pr10366", "pr10368", "pr10368_current"],
)
parser.add_argument("--jobs", type=int, default=2)
args = parser.parse_args()
record_path = ROOT / "build_records.json"
records = json.loads(record_path.read_text()) if record_path.exists() else {}
for arm in args.arms:
    source = ROOT / "sources" / arm
    dest = ROOT / "builds" / arm
    dest.mkdir(parents=True, exist_ok=True)
    with (dest / "build.log").open("w") as log:
        for cmd in [
            [
                CMAKE,
                "-S",
                ROOT / "harness",
                "-B",
                dest,
                "-DCMAKE_BUILD_TYPE=Release",
                "-DCMAKE_CXX_COMPILER=g++-13",
                "-DOPENMS=" + str(source),
            ],
            [CMAKE, "--build", dest, f"-j{args.jobs}"],
            [CTEST, "--test-dir", dest, "--output-on-failure"],
        ]:
            print(arm, list(map(str, cmd)), flush=True)
            subprocess.run(
                list(map(str, cmd)), env=ENV, stdout=log, stderr=log, check=True
            )
    records[arm] = {
        "source_base": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=source, text=True
        ).strip(),
        "source_tree": subprocess.check_output(
            ["git", "write-tree"], cwd=source, text=True
        ).strip(),
        "binary_sha256": hashlib.sha256((dest / "prose").read_bytes()).hexdigest(),
        "tests_passed": True,
    }
    (ROOT / "build_records.json").write_text(json.dumps(records, indent=2))
    print("Build and tests passed:", arm, records[arm], flush=True)
