## Measured results

Mean accepted PSMs per file over seeds 1/42/137 at q <= 0.01. PRs are independent.

| Instrument / acquisition | n | Common base | #10365 auto | #10366 priors | #10368 latest |
| --- | --- | --- | --- | --- | --- |
| Velos CID | 3 | 2876.6 | 2876.6 | 2890.1 | 2876.6 |
| HF-X HCD | 3 | 4383.3 | 4231.7 | 4386.6 | 4383.3 |
| Astral HCD | 3 | 2162.1 | 2262.3 | 2276.3 | 2162.1 |
| Lumos HCD LFQ | 3 | 5479.4 | 5261.7 | 5481.3 | 5479.4 |
| Lumos CID TMT | 3 | 2398.9 | 2398.9 | 2415.6 | 2398.9 |
| Exploris 480 TMTpro | 3 | 2247.4 | 2285.7 | 2285.9 | 2247.4 |
| timsTOF HT | 2 | 1038.0 | 1011.8 | 1030.7 | 1038.0 |

Kernel isolation: both sides use calibration=true and mass-accuracy scoring.

| Group | Fixed kernel PSMs | Fitted kernel PSMs | Delta | Native TDC delta |
| --- | --- | --- | --- | --- |
| HF-X HCD | 4206.7 | 4217.0 | +0.25% | -566.3 |
| Astral HCD | 2296.6 | 2292.2 | -0.19% | -571.7 |
| Lumos HCD LFQ | 5294.6 | 5299.1 | +0.09% | -160.3 |
| Exploris 480 TMTpro | 2267.3 | 2270.4 | +0.14% | -137.0 |
| timsTOF HT | 1003.8 | 1000.3 | -0.35% | +41.0 |

Intensity-scaled controls (latest #10368):

| File | Arm | Unscaled seeds | Scaled seeds | Identical normalized PIN |
| --- | --- | --- | --- | --- |
| velos_125_R1 | base | [2927, 2848, 2946] | [2410, 2340, 2375] | False |
| velos_125_R1 | pr68_current | [2927, 2848, 2946] | [2927, 2848, 2946] | True |
| eclipse_tmtpro_10855 | base | [2342, 2387, 2363] | [2350, 2336, 2328] | False |
| eclipse_tmtpro_10855 | pr68_current | [2342, 2387, 2363] | [2342, 2387, 2363] | True |

TMTpro diagnostic: 3268/4393 (74.4%) of Sage's additional accepted assignments are already in ProSE's top ten, summed over the three files and three seeds. Assignments are not independent observations across seeds and are not validated true positives.
