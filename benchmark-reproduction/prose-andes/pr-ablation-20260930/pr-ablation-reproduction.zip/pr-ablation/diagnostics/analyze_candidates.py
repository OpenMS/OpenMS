"""Locate Sage-accepted TMTpro assignments in ProSE's reported candidate list."""

import collections
import csv
import functools
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT.parent / "prose-andes-reproduction"
sys.path[:0] = [str(BUNDLE / "nightly"), str(BUNDLE / "deps")]
import pyopenms as p


@functools.lru_cache(maxsize=None)
def peptide(text):
    inner = text.split(".", 1)[1].rsplit(".", 1)[0]
    # I/L cannot be separated by these fragment masses; retain all modification sites.
    return p.AASequence.fromString(inner).toUniModString().replace("L", "I")


def accepted(folder, seed):
    with (folder / f"s{seed}/target.tsv").open() as f:
        rows = [
            r for r in csv.DictReader(f, delimiter="\t") if float(r["q-value"]) <= 0.01
        ]
    out = {int(r["PSMId"].rsplit("_", 2)[-2]): peptide(r["peptide"]) for r in rows}
    assert len(out) == len(rows)
    return out


results = []
for dataset in ["eclipse_tmtpro_10855", "eclipse_tmtpro_10858", "eclipse_tmtpro_10863"]:
    prose = ROOT / "results" / dataset / "base"
    sage = ROOT.parent / "sage-benchmark/results" / dataset
    candidates = collections.defaultdict(set)
    ranks = {}
    with (prose / "input.pin").open() as f:
        for r in csv.DictReader(f, delimiter="\t"):
            if r["Label"] == "1":
                scan = int(r["ScanNr"])
                key = peptide(r["Peptide"])
                candidates[scan].add(key)
                ranks[(scan, key)] = min(
                    ranks.get((scan, key), 100), int(r["SpecId"].rsplit("_", 1)[1]) + 1
                )
    for seed in [1, 42, 137]:
        a, b = accepted(prose, seed), accepted(sage, seed)
        gained = {scan: seq for scan, seq in b.items() if a.get(scan) != seq}
        missing = {
            scan: seq for scan, seq in gained.items() if seq not in candidates[scan]
        }
        rank_histogram = collections.Counter(
            ranks[(scan, seq)] for scan, seq in gained.items() if (scan, seq) in ranks
        )
        row = {
            "dataset": dataset,
            "seed": seed,
            "prose_accepted": len(a),
            "sage_accepted": len(b),
            "same_assignment": sum(a.get(scan) == seq for scan, seq in b.items()),
            "conflicting_accepted_assignments": sum(
                scan in a and a[scan] != seq for scan, seq in b.items()
            ),
            "sage_additional_assignments": len(gained),
            "sage_additional_absent_prose_top10": len(missing),
            "sage_additional_present_prose_top10": len(gained) - len(missing),
            "prose_rank_of_sage_additional": dict(sorted(rank_histogram.items())),
        }
        results.append(row)
        print(json.dumps(row), flush=True)
(ROOT / "diagnostics/candidate_comparison.json").write_text(
    json.dumps(results, indent=2)
)
