"""Locate accepted baseline assignments lost by auto calibration in its top ten."""

import csv
import argparse
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT.parent / "prose-andes-reproduction"


def read_pin(folder):
    with (folder / "input.pin").open() as f:
        return {r["SpecId"]: r for r in csv.DictReader(f, delimiter="\t")}


def accepted(folder, seed, pin):
    with (folder / f"s{seed}/target.tsv").open() as f:
        return {
            (pin[r["PSMId"]]["ScanNr"], pin[r["PSMId"]]["Peptide"]): pin[r["PSMId"]]
            for r in csv.DictReader(f, delimiter="\t")
            if float(r["q-value"]) <= 0.01
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("datasets", nargs="*")
    args = parser.parse_args()
    results = []
    for d in json.loads((BUNDLE / "broad_benchmark/manifest.json").read_text()):
        if d["fragment_unit"] != "ppm":
            continue
        if args.datasets and d["id"] not in args.datasets:
            continue
        a, b = [ROOT / "results" / d["id"] / arm for arm in ["base", "pr65_auto"]]
        assert (b / "summary.json").exists()
        pin_a, pin_b = read_pin(a), read_pin(b)
        candidates = {
            (r["ScanNr"], r["Peptide"]) for r in pin_b.values() if r["Label"] == "1"
        }
        match = re.search(
            r"Calibration: shift=.*? -> window \[-([\d.]+), \+([\d.]+)\]",
            (b / "search.log").read_text(),
        )
        lower, upper = map(float, match.groups()) if match else (None, None)
        for seed in [1, 42, 137]:
            old, new = accepted(a, seed, pin_a), accepted(b, seed, pin_b)
            lost = old.keys() - new.keys()
            absent = lost - candidates
            # Diagnostic, not exact reimplementation of FragmentIndex's float
            # mass-window arithmetic. Use every isotope hypothesis and a 0.05-ppm
            # guard beyond the rounded log limits before calling an exclusion.
            outside = 0
            outside_isotopes = Counter()
            if match:
                for k in absent:
                    r = old[k]
                    obs = float(r["ExpMass"])
                    calc = float(r["CalcMass"])
                    errors = [
                        1e6 * (obs + iso * 1.0033548378 - calc) / calc
                        for iso in [-2, -1, 0, 1]
                    ]
                    excluded = all(
                        e < -upper - 0.05 or e > lower + 0.05 for e in errors
                    )
                    outside += excluded
                    if excluded:
                        outside_isotopes[r["isotope_error"]] += 1
            results.append(
                dict(
                    dataset=d["id"],
                    seed=seed,
                    baseline_accepted=len(old),
                    calibrated_accepted=len(new),
                    lost_baseline_assignments=len(lost),
                    gained_calibrated_assignments=len(new.keys() - old.keys()),
                    lost_absent_calibrated_top10=len(absent),
                    lost_still_in_calibrated_top10=len(lost & candidates),
                    absent_clearly_outside_rounded_precursor_window=outside,
                    logged_mass_window_lower_ppm=lower,
                    logged_mass_window_upper_ppm=upper,
                    baseline_isotope_counts=dict(
                        Counter(r["isotope_error"] for r in old.values())
                    ),
                    lost_isotope_counts=dict(
                        Counter(old[k]["isotope_error"] for k in lost)
                    ),
                    outside_window_isotope_counts=dict(outside_isotopes),
                )
            )
    (ROOT / "diagnostics/calibration_losses.json").write_text(
        json.dumps(results, indent=2)
    )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
