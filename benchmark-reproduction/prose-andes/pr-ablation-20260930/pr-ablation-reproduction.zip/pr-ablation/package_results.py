"""Package the complete, validated PR matrix as a metadata-only supplement."""

import csv
import json
import shutil
import statistics
import zipfile
from pathlib import Path

from evaluate import GROUPS, group, write_tsv
from run import BUNDLE, HISTORICAL, MANIFEST, ROOT, sha

PUBLIC = (
    ROOT.parent
    / "benchmark-repo/benchmark-reproduction/prose-andes/pr-ablation-20260930"
)
STAGING = ROOT.parent / "pr-ablation-public/pr-ablation"


def table(headers, rows):
    return (
        "| "
        + " | ".join(headers)
        + " |\n| "
        + " | ".join(["---"] * len(headers))
        + " |\n"
        + "\n".join("| " + " | ".join(map(str, r)) + " |" for r in rows)
        + "\n"
    )


def copy(source, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)


def records(source, dest):
    for name in [
        "summary.json",
        "params.json",
        "resolved.json",
        "input_checks.json",
        "search.log",
        "search.command.json",
        "export.command.json",
        "export.log",
    ]:
        if (source / name).exists():
            copy(source / name, dest / name)
    for seed in [1, 42, 137]:
        for name in ["result.json", "percolator.log", "percolator.command.json"]:
            copy(source / f"s{seed}" / name, dest / f"s{seed}" / name)


def main():
    report = json.loads((ROOT / "summary.json").read_text())
    assert report["completed"] == 128 and len(report["files"]) == 128
    builds = json.loads((ROOT / "build_records.json").read_text())
    assert len(builds) == 5 and all(x["tests_passed"] for x in builds.values())
    assert all(
        sha(ROOT / "builds" / arm / "prose") == rec["binary_sha256"]
        for arm, rec in builds.items()
    )
    controls = json.loads((ROOT / "intensity-control/summary.json").read_text())
    assert len(controls) == 4
    candidate = json.loads((ROOT / "diagnostics/candidate_comparison.json").read_text())
    losses = json.loads((ROOT / "diagnostics/calibration_losses.json").read_text())
    assert len(candidate) == 9 and len(losses) == 42
    jobs = [
        json.loads(p.read_text())
        for p in sorted((ROOT / "results").glob("*/*/summary.json"))
    ]
    assert len(jobs) == 128
    by_key = {(x["dataset"], x["arm"]): x for x in jobs}
    sage_path = ROOT.parent / "sage-benchmark/reference/jobs.json"
    sage = {x["dataset"]: x for x in json.loads(sage_path.read_text())}
    cross = []
    for d in MANIFEST:
        name = d["id"]
        row = dict(dataset=name, group=group(name))
        for arm in ["base", "pr65_auto", "pr66_priors", "pr68_current"]:
            row[arm] = by_key[name, arm]["mean_psms"]
        old = HISTORICAL[f"native_dedup:{name}:default"]
        row["historical_prose"] = statistics.mean(old["expected_seed_psms"])
        row["andes_auto"] = statistics.mean(
            HISTORICAL[f"broad_benchmark:{name}:andes"]["expected_seed_psms"]
        )
        high = HISTORICAL.get(f"broad_benchmark:{name}:andes_highres")
        row["andes_explicit_highres"] = (
            statistics.mean(high["expected_seed_psms"]) if high else ""
        )
        row["sage"] = sage[name]["mean_psms"]
        for other in [old["expected_input_checks"], sage[name]["input_checks"]]:
            for field in ["mzml_sha256", "database_sha256"]:
                assert other[field] == by_key[name, "base"]["input_checks"][field]
        cross.append(row)
    write_tsv(ROOT / "cross_engine.tsv", cross)
    PUBLIC.mkdir(parents=True, exist_ok=True)
    assert not STAGING.exists(), "Use a fresh staging directory to avoid obsolete files"
    STAGING.mkdir(parents=True)
    for p in ROOT.iterdir():
        if p.is_file() and p.suffix in [".py", ".json", ".patch", ".tsv", ".md"]:
            copy(p, STAGING / p.name)
    for sub in ["harness", "diagnostics", "interrupted-20260930T185441"]:
        for p in (ROOT / sub).rglob("*"):
            if p.is_file() and "__pycache__" not in p.parts:
                copy(p, STAGING / p.relative_to(ROOT))
    (STAGING / "reference").mkdir(exist_ok=True)
    (STAGING / "reference/jobs.json").write_text(json.dumps(jobs, indent=2))
    for name in ["inputs.json", "databases.json"]:
        copy(BUNDLE / name, STAGING / "reference" / name)
    copy(ROOT / "build_records.json", STAGING / "reference/build_records.json")
    for j in jobs:
        path = Path(j["dataset"]) / j["arm"]
        records(ROOT / "results" / path, STAGING / "reference/results" / path)
    for arm in builds:
        copy(
            ROOT / "builds" / arm / "build.log",
            STAGING / "reference/builds" / arm / "build.log",
        )
        copy(
            ROOT / "builds" / arm / "Testing/Temporary/LastTest.log",
            STAGING / "reference/builds" / arm / "LastTest.log",
        )
    for row in controls:
        path = Path(row["dataset"]) / row["arm"]
        records(
            ROOT / "intensity-control/results" / path,
            STAGING / "reference/intensity-control/results" / path,
        )
    recoveries = json.loads((ROOT / "log_recoveries.json").read_text())
    assert len(recoveries) == 1
    for rec in recoveries.values():
        assert (
            rec["identical_pin_and_seed_counts"]
            and rec["identical_native_outputs_and_resolved_settings"]
        )
        source = ROOT / rec["replay_directory"]
        records(source, STAGING / rec["replay_directory"])
    for p in (ROOT / "intensity-control").glob("*.json"):
        copy(p, STAGING / "reference/intensity-control" / p.name)
    historical_replays = []
    for dataset in [
        "eclipse_tmtpro_10855",
        "eclipse_tmtpro_10858",
        "eclipse_tmtpro_10863",
    ]:
        source = ROOT.parent / "tmtpro-gap/baselines/native_dedup" / dataset / "default"
        expected = HISTORICAL[f"native_dedup:{dataset}:default"]
        counts = [
            json.loads((source / f"s{s}/result.json").read_text())["accepted"]
            for s in [1, 42, 137]
        ]
        pin = sha(source / "input.pin")
        assert (
            counts == expected["expected_seed_psms"]
            and pin == expected["expected_input_checks"]["sha256"]
        )
        historical_replays.append(
            dict(
                dataset=dataset,
                seed_psms=counts,
                pin_sha256=pin,
                identical_historical_pin_and_counts=True,
            )
        )
        records(source, STAGING / "reference/historical-replays" / dataset)
    (STAGING / "reference/historical_replays.json").write_text(
        json.dumps(historical_replays, indent=2)
    )
    validation = dict(
        searches=132,
        unscaled_searches=128,
        intensity_control_searches=4,
        percolator_runs=396,
        historical_replay_searches=3,
        historical_replay_percolator_runs=9,
        log_recovery_replay_searches=1,
        log_recovery_replay_percolator_runs=3,
        ctest_executions=16,
        seeds=[1, 42, 137],
        q_threshold=0.01,
        historical_base_pin_identical_files=sum(
            by_key[d["id"], "base"]["historical_pin_identical"] for d in MANIFEST
        ),
        no_duplicate_accepted_scans=True,
        all_pin_rows_read=True,
        all_pin_and_output_hashes_verified=True,
        all_pr66_nonprior_features_identical=True,
        all_kernel_control_tolerances_identical=True,
        percolator_binary_sha256=sha(BUNDLE / "percolator/usr/bin/percolator"),
    )
    (STAGING / "validation.json").write_text(json.dumps(validation, indent=2))
    groups = {(r["group"], r["arm"]): r for r in report["groups"]}
    text = "\n## Measured results\n\nMean accepted PSMs per file over seeds 1/42/137 at q <= 0.01. PRs are independent.\n\n"
    text += table(
        [
            "Instrument / acquisition",
            "n",
            "Common base",
            "#10365 auto",
            "#10366 priors",
            "#10368 latest",
        ],
        [
            (g, groups[g, "base"]["n"])
            + tuple(
                f'{groups[g,a]["mean_psms"]:.1f}'
                for a in ["base", "pr65_auto", "pr66_priors", "pr68_current"]
            )
            for _, g in GROUPS
        ],
    )
    text += "\nKernel isolation: both sides use calibration=true and mass-accuracy scoring.\n\n"
    text += table(
        [
            "Group",
            "Fixed kernel PSMs",
            "Fitted kernel PSMs",
            "Delta",
            "Native TDC delta",
        ],
        [
            (
                g,
                f'{groups[g,"base_mass_cal"]["mean_psms"]:.1f}',
                f'{groups[g,"pr65_mass_cal"]["mean_psms"]:.1f}',
                f'{groups[g,"pr65_mass_cal"]["delta_pct"]:+.2f}%',
                f'{groups[g,"pr65_mass_cal"]["native_delta"]:+.1f}',
            )
            for _, g in GROUPS
            if (g, "base_mass_cal") in groups
        ],
    )
    text += "\nIntensity-scaled controls (latest #10368):\n\n"
    text += table(
        ["File", "Arm", "Unscaled seeds", "Scaled seeds", "Identical normalized PIN"],
        [
            (
                r["dataset"],
                r["arm"],
                r["unscaled_seed_psms"],
                r["seed_psms"],
                r["identical_to_unscaled_pin"],
            )
            for r in controls
        ],
    )
    present = sum(r["sage_additional_present_prose_top10"] for r in candidate)
    additional = sum(r["sage_additional_assignments"] for r in candidate)
    text += f"\nTMTpro diagnostic: {present}/{additional} ({100*present/additional:.1f}%) of Sage's additional accepted assignments are already in ProSE's top ten, summed over the three files and three seeds. Assignments are not independent observations across seeds and are not validated true positives.\n"
    (STAGING / "RESULTS.md").write_text(text.lstrip())
    hashes = [
        f"{sha(p)}  {p.relative_to(STAGING)}"
        for p in sorted(STAGING.rglob("*"))
        if p.is_file()
    ]
    (STAGING / "MANIFEST.sha256").write_text("\n".join(hashes) + "\n")
    archive = PUBLIC / "pr-ablation-reproduction.zip"
    with zipfile.ZipFile(
        archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as z:
        for p in sorted(STAGING.rglob("*")):
            if p.is_file():
                info = zipfile.ZipInfo(
                    "pr-ablation/" + str(p.relative_to(STAGING)),
                    date_time=(2026, 9, 30, 0, 0, 0),
                )
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, p.read_bytes())
    (PUBLIC / "pr-ablation-reproduction.zip.sha256").write_text(
        sha(archive) + "  pr-ablation-reproduction.zip\n"
    )
    (PUBLIC / "README.md").write_text(
        (ROOT / "README.md").read_text()
        + text
        + f"\nDownload [pr-ablation-reproduction.zip](pr-ablation-reproduction.zip), SHA256 `{sha(archive)}`.\n"
    )
    for name in ["per_file.tsv", "per_group.tsv", "cross_engine.tsv"]:
        copy(ROOT / name, PUBLIC / name)
    print(
        json.dumps(
            dict(
                archive=str(archive),
                bytes=archive.stat().st_size,
                sha256=sha(archive),
                manifest_files=len(hashes),
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
