"""Generate benchmark sections for the existing issue and three PR descriptions."""

import argparse
import json
import statistics

from evaluate import GROUPS
from package_results import table
from run import ROOT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("commit")
    args = parser.parse_args()
    summary = json.loads((ROOT / "summary.json").read_text())
    assert summary["completed"] == 128
    jobs = [
        json.loads(p.read_text()) for p in (ROOT / "results").glob("*/*/summary.json")
    ]
    baselines = [j for j in jobs if j["arm"] == "base"]
    assert len(baselines) == 20 and all(
        j["historical_pin_identical"] and j["historical_seed_counts_identical"]
        for j in baselines
    )
    current_cutoff = [x for x in summary["isolation"] if x["arm"] == "pr68_current"]
    assert len(current_cutoff) == 20 and all(
        x["same_pin"] and x["same_native_tsv"] for x in current_cutoff
    )
    groups = {(x["group"], x["arm"]): x for x in summary["groups"]}
    url = f"https://github.com/OpenMS/OpenMS/tree/{args.commit}/benchmark-reproduction/prose-andes/pr-ablation-20260930"
    raw = f"https://raw.githubusercontent.com/OpenMS/OpenMS/{args.commit}/benchmark-reproduction/prose-andes/pr-ablation-20260930"
    controls = json.loads((ROOT / "intensity-control/summary.json").read_text())
    digest = (
        (
            ROOT.parent
            / "benchmark-repo/benchmark-reproduction/prose-andes/pr-ablation-20260930/pr-ablation-reproduction.zip.sha256"
        )
        .read_text()
        .split()[0]
    )
    base = "`c1b2f202742270273a045ef4b56e7aa346e9871f`"
    intro = f"Independently benchmarked each PR patch on common base {base}, using all 20 frozen files (8,000 DDA MS2/file), the same FASTAs, and Percolator 3.09.0 seeds 1/42/137 at q ≤ 0.01. PRs are applied separately, not stacked. Sources, applied Git tree IDs, effective patches, exact requested/resolved parameters, commands, logs, output checksums and all seed counts are in the [reproduction supplement]({url}).\n\n"
    intro += "The original PR branches forked at `0af4cf62`; their patches were applied cleanly to the common base so intervening base fixes do not confound this comparison. All 20 baseline normalized PINs and seed counts reproduce the historical ProSE reference. Five isolated builds pass 16 CTest executions. The matrix contains 128 unscaled searches plus four intensity controls, each with three Percolator runs (396 rescoring runs).\n\n"
    results = table(
        [
            "Instrument / acquisition",
            "n",
            "Base",
            "#10365 auto",
            "#10366 priors",
            "#10368 latest",
        ],
        [
            (g, groups[g, "base"]["n"])
            + tuple(
                f'{groups[g,a]["mean_psms"]:.1f}'
                for a in ["base", "pr65_auto", "pr66_priors", "pr68_current"]
            )
            for _, g in GROUPS
        ],
    )
    kernel = table(
        [
            "Group",
            "Fixed kernel",
            "Fitted kernel",
            "Rescored delta",
            "Native TDC delta",
        ],
        [
            (
                g,
                f'{groups[g,"base_mass_cal"]["mean_psms"]:.1f}',
                f'{groups[g,"pr65_mass_cal"]["mean_psms"]:.1f}',
                f'{groups[g,"pr65_mass_cal"]["delta_pct"]:+.2f}%',
                f'{groups[g,"pr65_mass_cal"]["native_delta"]:+.1f}',
            )
            for _, g in GROUPS
            if (g, "base_mass_cal") in groups
        ],
    )
    scaled = table(
        ["File", "Arm", "Unscaled seeds", "Scaled seeds", "Identical PIN"],
        [
            (
                r["dataset"],
                r["arm"],
                r["unscaled_seed_psms"],
                r["seed_psms"],
                r["identical_to_unscaled_pin"],
            )
            for r in controls
        ],
    )
    caveat = "Counts are nominal-q yields, not independently validated true positives. Seeds are algorithmic repeats. The prior model trains within the same file before Percolator cross-validation; out-of-fold prior training / independent FDR validation remains untested. The native harness recompiles the affected algorithms against pinned pyOpenMS support; this is not a full TOPP/binding build. Timings under concurrent load are not a speed benchmark.\n"
    calibration = "`pr65_auto` still uses HyperScore on high-resolution files, so its changes measure auto calibration, not the new mass-accuracy kernel. The separate kernel comparison below sets calibration=true and mass_accuracy on both sides and verifies identical calibrated tolerances. Do not enable auto calibration universally on the strength of the labelled-data gains: the matrix includes substantial unlabelled HCD losses. On `lumos_lfq_5192`, the mass window tightens from ±20 ppm to approximately −3.50/+3.11 ppm; 1,726/1,919 lost baseline assignments across the three seeds lie clearly outside that window, considering every isotope offset and a 0.05-ppm guard beyond rounded log bounds. Most of these exclusions involve a nonzero isotope correction. The diagnostic and its limits are saved in `diagnostics/calibration_losses.json`.\n\n"
    priors = "For all 20 files, #10366 has identical native candidate/score TSVs and byte-identical normalized PINs after removing only its three added prior columns. The measured changes therefore come from rescoring features. Gains are modest and dataset-dependent; keep the existing opt-in scope pending stronger validation.\n\n"
    cutoff = "The latest #10368 preserves the raw-data results and fixes the intensity-scale dependence. Controls scale each spectrum by an exact power of two to a base peak in [1,2), preserving m/z, RT, precursors, scan IDs and float32 reversibility. These are derived controls of two existing measurements.\n\n"
    versions = "Measured heads: #10365 `160412c13122c1ae2205580eeec5b43018f7a006`, #10366 `5f66ab7ee2b7e3487081838964b9491e7696a4b8`, #10368 initial `9a3d57796d3ef685f66f9962e49e4c3c90e5ac58` and latest `d21f55b2575c523b4f8be13f407a62b276819496`. Follow-up heads #10365 `79e08f2948f6000787d4eef992bb6b33572f5419` / #10366 `6a29032936bb6e4d49c4fa40e712f4bbefd1cee0` differ only in CHANGELOG; runtime/test sources are identical. #10368's subnormal-intensity correction was rebuilt and rerun on all 20 files.\n\n"
    reproduction = f"Reproduce using the pinned ZIP [pr-ablation-reproduction.zip]({raw}/pr-ablation-reproduction.zip), SHA256 `{digest}`. Verify its manifest, then follow the README's commands (`prepare_sources.py`, `build.py`, `run.py`, `evaluate.py --require-complete --write`, and `intensity_control.py`). The original input bundle remains pinned at `a5705ec8e1cb19d40ebfa7bb16f6b5651aa1dc65`. [Per-file/seed results]({raw}/per_file.tsv), [per-group results]({raw}/per_group.tsv), [comparison with pinned ANDES/Sage]({raw}/cross_engine.tsv). No raw data or result table is silently substituted.\n\n"
    issue = (
        "<!-- pr-ablation:20260930:start -->\n## Independent PR benchmarks: #10365, #10366, #10368\n\n"
        + intro
        + results
        + "\n"
        + calibration
        + kernel
        + "\n"
        + priors
        + cutoff
        + scaled
        + "\n"
        + versions
        + reproduction
    )
    issue += (
        "The TMTpro gap diagnostic also finds 3,268/4,393 (74.4%) of Sage's additional accepted assignments already in ProSE's top ten, summed over three files/seeds. This includes conflicting accepted assignments and is not a true-positive oracle; it points primarily to scoring/features rather than only candidate retrieval. The saved helper compares modified peptides with I/L equivalence.\n\n"
        + caveat
        + "\n<!-- pr-ablation:20260930:end -->"
    )
    prs = {}
    for number, arm in [
        (10365, "pr65_auto"),
        (10366, "pr66_priors"),
        (10368, "pr68_current"),
    ]:
        rows = [
            (
                g,
                groups[g, "base"]["n"],
                f'{groups[g,"base"]["mean_psms"]:.1f}',
                f'{groups[g,arm]["mean_psms"]:.1f}',
                f'{groups[g,arm]["delta_pct"]:+.2f}%',
            )
            for _, g in GROUPS
        ]
        text = (
            "<!-- isolated-benchmark:20260930:start -->\n## Independent 20-file benchmark\n\n"
            + intro.split("The original PR")[0]
        )
        text += (
            table(["Instrument / acquisition", "n", "Base", "This PR", "Delta"], rows)
            + "\n"
        )
        if number == 10365:
            text += calibration + kernel + "\n"
        elif number == 10366:
            text += priors
        else:
            text += cutoff + scaled + "\n"
        text += (
            versions
            + reproduction
            + caveat
            + "\nFull comparison: #10364.\n<!-- isolated-benchmark:20260930:end -->"
        )
        prs[str(number)] = text
    (ROOT.parent / "pr-ablation-publication.json").write_text(
        json.dumps(dict(issue=issue, prs=prs), indent=2)
    )
    print(
        json.dumps(
            dict(issue_chars=len(issue), pr_chars={k: len(v) for k, v in prs.items()})
        )
    )


if __name__ == "__main__":
    main()
