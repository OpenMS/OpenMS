"""Materialize the exact common-base source trees used by the isolated PR runs."""

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent / "prose-andes-reproduction"
REPO = BUNDLE / "OpenMS"
FIXTURE_COMMIT = "e25ac614f495ce1e4933f46b41da18199eeba3ef"
SPARSE = [
    "src/openms/include",
    "src/openms/source",
    "src/openms/extern/nlohmann_json/include",
    "src/openswathalgo/include",
    "src/testframework",
    "src/tests/class_tests/source",
    "src/tests/class_tests/openms/source",
    "src/pyOpenMS/bindings",
    "src/pyOpenMS/tests/unittests",
    "src/topp",
]


def git(*args, cwd=REPO):
    return subprocess.check_output(["git", *map(str, args)], cwd=cwd, text=True).strip()


def main():
    versions = json.loads((ROOT / "versions.json").read_text())
    provenance = json.loads((ROOT / "source_provenance.json").read_text())
    if not REPO.exists():
        subprocess.run(
            [
                "git",
                "clone",
                "--filter=blob:none",
                "https://github.com/OpenMS/OpenMS.git",
                str(REPO),
            ],
            check=True,
        )
        git("checkout", "--detach", FIXTURE_COMMIT)
    # The fixture checkout is intentionally pinned, even though the benchmark
    # compiles algorithm code from the independent worktrees below.
    assert git("rev-parse", "HEAD") == FIXTURE_COMMIT, (
        "Fixture checkout must be at " + FIXTURE_COMMIT
    )
    assert not git("status", "--porcelain"), "Fixture checkout contains local changes"
    try:
        git("cat-file", "-e", versions["base"])
    except subprocess.CalledProcessError:
        git("fetch", "origin", versions["base"])
    (ROOT / "sources").mkdir(exist_ok=True)
    for arm in versions:
        source = ROOT / "sources" / arm
        expected = (
            provenance[arm]["applied_tree"]
            if arm != "base"
            else git("rev-parse", versions["base"] + "^{tree}")
        )
        if not source.exists():
            git(
                "worktree", "add", "--detach", "--no-checkout", source, versions["base"]
            )
            git("sparse-checkout", "set", *SPARSE, cwd=source)
            git("checkout", "--detach", versions["base"], cwd=source)
            if arm != "base":
                patch = ROOT / (arm + "-on-common-base.patch")
                assert (
                    hashlib.sha256(patch.read_bytes()).hexdigest()
                    == provenance[arm]["effective_patch_sha256"]
                )
                git("apply", "--index", patch, cwd=source)
        assert git("rev-parse", "HEAD", cwd=source) == versions["base"]
        assert git("write-tree", cwd=source) == expected, arm
        assert not git("diff", "--name-only", cwd=source), (
            "Unstaged source changes in " + arm
        )
        print(arm, expected)
    # This header was generated for the original workspace. Relocate only its
    # fixture path; all other bundled generated headers remain unchanged.
    header = ROOT / "harness/include/OpenMS/test_config.h"
    import re

    text = header.read_text()
    text = re.sub(
        r'(?<=std::string\(")[^"]*/src/tests/class_tests/openms/data/',
        str(REPO / "src/tests/class_tests/openms/data") + "/",
        text,
    )
    header.write_text(text)


if __name__ == "__main__":
    main()
