"""Recount primary outputs and measure each PR against its paired common base."""

import argparse
import csv
import gzip
import hashlib
import io
import json
import re
import statistics
from pathlib import Path

from run import ARMS, BUNDLE, HISTORICAL, INPUTS, MANIFEST, ROOT, native, sha

GROUPS = [
    ("velos", "Velos CID"),
    ("hfx", "HF-X HCD"),
    ("astral", "Astral HCD"),
    ("lumos_lfq", "Lumos HCD LFQ"),
    ("lumos_tmt", "Lumos CID TMT"),
    ("eclipse", "Exploris 480 TMTpro"),
    ("tims", "timsTOF HT"),
]


def group(dataset):
    return next(g for prefix, g in GROUPS if dataset.startswith(prefix))


def validate(folder):
    x = json.loads((folder / "summary.json").read_text())
    checks = x["input_checks"]
    assert sha(folder / "input.pin") == checks["sha256"]
    with (folder / "input.pin").open() as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    assert len(rows) == checks["candidate_rows"]
    assert len({r["ScanNr"] for r in rows}) == checks["spectra"]
    assert len({(r["ScanNr"], r["Label"], r["Peptide"]) for r in rows}) == len(rows)
    assert x["native"] == native(folder)
    for name in ["native.tsv", "native.pin"]:
        with gzip.open(folder / (name + ".gz"), "rb") as f:
            digest = hashlib.file_digest(f, "sha256").hexdigest()
        assert digest == x[name.replace(".", "_") + "_sha256"]
    counts = []
    for expected in x["seed_results"]:
        seed = expected["seed"]
        d = folder / f"s{seed}"
        assert json.loads((d / "result.json").read_text()) == expected
        for label in ["target", "decoy"]:
            assert sha(d / f"{label}.tsv") == expected[label + "_sha256"]
        assert f"Found {len(rows)} PSMs" in (d / "percolator.log").read_text()
        with (d / "target.tsv").open() as f:
            accepted = [
                r
                for r in csv.DictReader(f, delimiter="\t")
                if float(r["q-value"]) <= 0.01
            ]
        assert len({r["PSMId"].rsplit("_", 2)[-2] for r in accepted}) == len(accepted)
        assert len(accepted) == expected["accepted"]
        counts.append(len(accepted))
    assert counts == x["seed_psms"] and statistics.mean(counts) == x["mean_psms"]
    return x


def collect(root, require_complete=False):
    found = {}
    reference_path = ROOT / "reference/jobs.json"
    refs = (
        {(x["dataset"], x["arm"]): x for x in json.loads(reference_path.read_text())}
        if reference_path.exists()
        else {}
    )
    for d in MANIFEST:
        for arm in ARMS:
            if "mass_cal" in arm and d["fragment_unit"] != "ppm":
                continue
            folder = root / d["id"] / arm
            if not (folder / "summary.json").exists():
                continue
            x = validate(folder)
            assert (
                x["input_checks"]["mzml_sha256"] == INPUTS[d["id"]]["selected_sha256"]
            )
            old = HISTORICAL[f"native_dedup:{d['id']}:default"]
            assert (
                x["input_checks"]["database_sha256"]
                == old["expected_input_checks"]["database_sha256"]
            )
            key = (d["id"], arm)
            if key in refs:
                for field in ["seed_psms", "native", "native_tsv_sha256"]:
                    assert x[field] == refs[key][field], (key, field)
                assert (
                    x["input_checks"]["sha256"] == refs[key]["input_checks"]["sha256"]
                ), key
            found[key] = x
    if require_complete:
        assert len(found) == 128, len(found)
    rows, isolation = [], []
    for (dataset, arm), x in found.items():
        control_arm = "base_mass_cal" if arm == "pr65_mass_cal" else "base"
        if (dataset, control_arm) not in found:
            continue
        b = found[dataset, control_arm]
        deltas = [v - u for u, v in zip(b["seed_psms"], x["seed_psms"])]
        r = dict(
            dataset=dataset,
            group=group(dataset),
            arm=arm,
            control=control_arm,
            **{f"seed_{s}": v for s, v in zip([1, 42, 137], x["seed_psms"])},
            mean_psms=x["mean_psms"],
            delta_mean=statistics.mean(deltas),
            delta_pct=100 * (x["mean_psms"] / b["mean_psms"] - 1),
            native_psms=x["native"]["psms"],
            native_delta=x["native"]["psms"] - b["native"]["psms"],
            scored_spectra=x["native"]["scored_spectra"],
            ion_prior_training_psms=x["resolved"].get("ion_prior:training_psms", ""),
            fitted_sd=x["resolved"].get("scoring:mass_error_sd_resolved", ""),
            fitted_shift=x["resolved"].get("scoring:mass_error_shift_resolved", ""),
            kernel=x["resolved"].get("scoring:mass_error_kernel", ""),
            historical_pin_identical=x["historical_pin_identical"],
            pin_sha256=x["input_checks"]["sha256"],
        )
        rows.append(r)
        check = dict(
            dataset=dataset,
            arm=arm,
            same_native_tsv=x["native_tsv_sha256"] == b["native_tsv_sha256"],
            same_pin=x["input_checks"]["sha256"] == b["input_checks"]["sha256"],
        )
        if arm == "pr66_priors":
            # Confirm candidate list and every pre-existing feature are unchanged.
            with (root / dataset / arm / "input.pin").open(newline="") as f:
                reader = csv.DictReader(f, delimiter="\t")
                fields = [
                    k for k in reader.fieldnames if not k.startswith("ion_prior_")
                ]
                out = io.StringIO(newline="")
                w = csv.DictWriter(out, fields, delimiter="\t", extrasaction="ignore")
                w.writeheader()
                w.writerows(reader)
            digest = hashlib.sha256(out.getvalue().encode()).hexdigest()
            check["same_pin_without_added_features"] = (
                digest == b["input_checks"]["sha256"]
            )
            assert (
                check["same_pin_without_added_features"] and check["same_native_tsv"]
            ), check
        if arm == "pr65_mass_cal":
            check["same_calibrated_tolerances"] = all(
                x["resolved"][k] == b["resolved"][k]
                for k in ["fragment_mass_tolerance", "precursor_mass_tolerance"]
            )
            assert check["same_calibrated_tolerances"], check

            def logged_window(selected_arm):
                log = (root / dataset / selected_arm / "search.log").read_text()
                pattern = r"Calibration: shift=.*? -> window \[[^\]]+\]"
                windows = re.findall(pattern, log)
                recovery_path = ROOT / "log_recoveries.json"
                if not windows and recovery_path.exists():
                    recoveries = json.loads(recovery_path.read_text())
                    key = dataset + ":" + selected_arm
                    if key in recoveries:
                        rec = recoveries[key]
                        assert rec["identical_pin_and_seed_counts"]
                        assert (
                            rec["pin_sha256"]
                            == found[dataset, selected_arm]["input_checks"]["sha256"]
                        )
                        replay = ROOT / rec["replay_directory"]
                        windows = re.findall(
                            pattern, (replay / "search.log").read_text()
                        )
                return windows

            check["same_logged_precursor_window"] = logged_window(arm) == logged_window(
                control_arm
            )
            assert check["same_logged_precursor_window"], check
        isolation.append(check)
    groups = []
    for _, g in GROUPS:
        for arm in ARMS:
            part = [r for r in rows if r["group"] == g and r["arm"] == arm]
            if not part:
                continue
            mean = statistics.mean(r["mean_psms"] for r in part)
            delta = statistics.mean(r["delta_mean"] for r in part)
            groups.append(
                dict(
                    group=g,
                    arm=arm,
                    n=len(part),
                    mean_psms=mean,
                    delta_mean=delta,
                    delta_pct=100 * delta / (mean - delta),
                    native_mean=statistics.mean(r["native_psms"] for r in part),
                    native_delta=statistics.mean(r["native_delta"] for r in part),
                )
            )
    return dict(completed=len(found), files=rows, groups=groups, isolation=isolation)


def write_tsv(path, rows):
    with path.open("w") as f:
        w = csv.DictWriter(
            f, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n"
        )
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--require-complete", action="store_true")
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    result = collect(ROOT / "results", a.require_complete)
    print(
        json.dumps(
            {"completed": result["completed"], "groups": result["groups"]}, indent=2
        )
    )
    if a.write:
        (ROOT / "summary.json").write_text(json.dumps(result, indent=2))
        write_tsv(ROOT / "per_file.tsv", result["files"])
        write_tsv(ROOT / "per_group.tsv", result["groups"])
