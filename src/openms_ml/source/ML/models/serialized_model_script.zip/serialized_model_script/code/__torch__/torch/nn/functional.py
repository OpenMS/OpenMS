def dropout(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  _0 = "dropout probability has to be between 0 and 1, but got {}"
  if torch.lt(p, 0.):
    _1 = True
  else:
    _1 = torch.gt(p, 1.)
  if _1:
    ops.prim.RaiseException(torch.format(_0, p), "builtins.ValueError")
  else:
    pass
  if inplace:
    _2 = torch.dropout_(input, p, training)
  else:
    _2 = torch.dropout(input, p, training)
  return _2
def softmax(input: Tensor,
    dim: Optional[int]=None,
    _stacklevel: int=3,
    dtype: Optional[int]=None) -> Tensor:
  _3 = __torch__.torch.nn.functional._get_softmax_dim
  if torch.__is__(dim, None):
    dim1 = _3("softmax", torch.dim(input), _stacklevel, )
    dim0 = dim1
  else:
    dim0 = unchecked_cast(int, dim)
  if torch.__is__(dtype, None):
    ret = torch.softmax(input, dim0)
  else:
    dtype0 = unchecked_cast(int, dtype)
    ret = torch.softmax(input, dim0, dtype0)
  return ret
def _get_softmax_dim(name: str,
    ndim: int,
    stacklevel: int) -> int:
  _4 = "Implicit dimension choice for {} has been deprecated. Change the call to include dim=X as an argument."
  torch.warn(torch.format(_4, name), stacklevel)
  if torch.eq(ndim, 0):
    _5 = True
  else:
    _5 = torch.eq(ndim, 1)
  if _5:
    _6 = True
  else:
    _6 = torch.eq(ndim, 3)
  if _6:
    ret = 0
  else:
    ret = 1
  return ret
