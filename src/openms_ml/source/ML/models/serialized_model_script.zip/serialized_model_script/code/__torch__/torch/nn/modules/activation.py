class Softmax(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  dim : Final[int] = 1
  def forward(self: __torch__.torch.nn.modules.activation.Softmax,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.softmax
    return _0(input, 1, 5, None, )
class PReLU(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  _is_full_backward_hook : NoneType
  num_parameters : Final[int] = 1
  def forward(self: __torch__.torch.nn.modules.activation.PReLU,
    input: Tensor) -> Tensor:
    weight = self.weight
    return torch.prelu(input, weight)
