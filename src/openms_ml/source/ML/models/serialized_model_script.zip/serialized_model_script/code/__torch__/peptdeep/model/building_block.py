class Decoder_Linear(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  nn : __torch__.torch.nn.modules.container.___torch_mangle_5.Sequential
  def forward(self: __torch__.peptdeep.model.building_block.Decoder_Linear,
    x: Tensor) -> Tensor:
    nn = self.nn
    return (nn).forward(x, )
