class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  rt_encoder : __torch__.Encoder_26AA_Mod_CNN_LSTM_AttnSum
  rt_decoder : __torch__.peptdeep.model.building_block.Decoder_Linear
  def forward(self: __torch__.Model,
    aa_indices: Tensor,
    mod_x: Tensor) -> Tensor:
    rt_encoder = self.rt_encoder
    x = (rt_encoder).forward(aa_indices, mod_x, )
    dropout = self.dropout
    x0 = (dropout).forward(x, )
    rt_decoder = self.rt_decoder
    _0 = torch.squeeze((rt_decoder).forward(x0, ), 1)
    return _0
class Encoder_26AA_Mod_CNN_LSTM_AttnSum(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  mod_nn : __torch__.Mod_Embedding_FixFirstK
  input_cnn : __torch__.SeqCNN
  hidden_nn : __torch__.SeqLSTM
  attn_sum : __torch__.SeqAttentionSum
  def forward(self: __torch__.Encoder_26AA_Mod_CNN_LSTM_AttnSum,
    aa_indices: Tensor,
    mod_x: Tensor) -> Tensor:
    mod_nn = self.mod_nn
    mod_x0 = (mod_nn).forward(mod_x, )
    aa_x = torch.one_hot(aa_indices, 27)
    x = torch.cat([aa_x, mod_x0], 2)
    input_cnn = self.input_cnn
    x1 = (input_cnn).forward(x, )
    hidden_nn = self.hidden_nn
    x2 = (hidden_nn).forward(x1, )
    attn_sum = self.attn_sum
    return (attn_sum).forward(x2, )
class Mod_Embedding_FixFirstK(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  k : int
  nn : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.Mod_Embedding_FixFirstK,
    mod_x: Tensor) -> Tensor:
    _1 = torch.slice(torch.slice(mod_x), 1)
    k = self.k
    _2 = torch.slice(_1, 2, None, k)
    nn = self.nn
    _3 = torch.slice(torch.slice(mod_x), 1)
    k0 = self.k
    _4 = (nn).forward(torch.slice(_3, 2, k0), )
    return torch.cat([_2, _4], 2)
class SeqCNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cnn_short : __torch__.torch.nn.modules.conv.Conv1d
  cnn_medium : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  cnn_long : __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv1d
  def forward(self: __torch__.SeqCNN,
    x: Tensor) -> Tensor:
    x3 = torch.transpose(x, 1, 2)
    cnn_short = self.cnn_short
    x1 = (cnn_short).forward(x3, )
    cnn_medium = self.cnn_medium
    x2 = (cnn_medium).forward(x3, )
    cnn_long = self.cnn_long
    x30 = (cnn_long).forward(x3, )
    _5 = torch.transpose(torch.cat([x3, x1, x2, x30], 1), 1, 2)
    return _5
class SeqLSTM(Module):
  __parameters__ = ["rnn_h0", "rnn_c0", ]
  __buffers__ = []
  rnn_h0 : Tensor
  rnn_c0 : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  rnn : __torch__.torch.nn.modules.rnn.LSTM
  def forward(self: __torch__.SeqLSTM,
    x: Tensor) -> Tensor:
    rnn_h0 = self.rnn_h0
    h0 = torch.repeat(rnn_h0, [1, torch.size(x, 0), 1])
    rnn_c0 = self.rnn_c0
    c0 = torch.repeat(rnn_c0, [1, torch.size(x, 0), 1])
    rnn = self.rnn
    x4, _6, = (rnn).forward__0(x, (h0, c0), )
    return x4
class SeqAttentionSum(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attn : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.SeqAttentionSum,
    x: Tensor) -> Tensor:
    attn = self.attn
    attn0 = (attn).forward(x, )
    return torch.sum(torch.mul(x, attn0), [1])
